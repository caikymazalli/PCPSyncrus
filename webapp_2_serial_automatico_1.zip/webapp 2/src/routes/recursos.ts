import { Hono } from 'hono'
import { layout } from '../layout'
import { getCtxTenant, getCtxUserInfo, getCtxSession, getCtxDB, getCtxUserId, getCtxEmpresaId } from '../sessionHelper'
import { genId, dbInsert, dbUpdate, dbDelete, ok, err } from '../dbHelpers'
import { markTenantModified } from '../userStore'
import { requireModuleWriteAccess } from '../moduleAccess'

const app = new Hono()

app.use('*', async (c, next) => {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(c.req.method)) {
    const blocked = await requireModuleWriteAccess(c, 'recursos')
    if (blocked) return blocked
  }
  return next()
})

// ── Helpers ─────────────────────────────────────────────────────────────────
function statusBadgeMachine(s: string) {
  const map: Record<string, string>   = { operational: 'badge-success', maintenance: 'badge-warning', offline: 'badge-secondary' }
  const label: Record<string, string> = { operational: 'Operacional', maintenance: 'Manutenção', offline: 'Offline' }
  return `<span class="badge ${map[s] || 'badge-secondary'}">${label[s] || s}</span>`
}

// ── GET / ── render page ─────────────────────────────────────────────────────
app.get('/', (c) => {
  const tenant   = getCtxTenant(c)
  const userInfo = getCtxUserInfo(c)
  const { plants, machines, workbenches } = tenant

  // Plant options for machine modal
  const plantOptions = plants.length
    ? plants.map(p => `<option value="${p.id}">${p.name}</option>`).join('')
    : '<option value="">— Nenhuma planta cadastrada —</option>'

  // ── Plantas cards ────────────────────────────────────────────────────────
  const plantasHtml = plants.length === 0
    ? `<div style="grid-column:1/-1;text-align:center;padding:40px 0;">
        <i class="fas fa-building" style="font-size:40px;color:#d1d5db;"></i>
        <p style="margin-top:12px;color:#9ca3af;font-size:14px;">Nenhuma planta cadastrada.<br>Clique em <strong>+ Nova Planta</strong> para começar.</p>
      </div>`
    : plants.map((p: any) => `
      <div class="card" style="padding:20px;" id="plant-${p.id}">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:14px;">
          <div style="display:flex;align-items:center;gap:12px;">
            <div style="width:44px;height:44px;border-radius:10px;background:#e8f4fd;display:flex;align-items:center;justify-content:center;">
              <i class="fas fa-building" style="color:#1B4F72;font-size:20px;"></i>
            </div>
            <div>
              <div style="font-size:15px;font-weight:700;color:#1B4F72;">${p.name}</div>
              <div style="font-size:12px;color:#9ca3af;"><i class="fas fa-map-marker-alt" style="margin-right:4px;"></i>${p.location}</div>
            </div>
          </div>
          <span class="badge ${p.status === 'active' ? 'badge-success' : 'badge-secondary'}">${p.status === 'active' ? 'Ativa' : 'Inativa'}</span>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;">
          <div style="background:#f8f9fa;border-radius:8px;padding:10px;">
            <div style="font-size:10px;color:#9ca3af;font-weight:600;text-transform:uppercase;">Capacidade</div>
            <div style="font-size:17px;font-weight:800;color:#1B4F72;">${p.totalCapacity || 0}</div>
            <div style="font-size:10px;color:#9ca3af;">peças/turno</div>
          </div>
          <div style="background:#f8f9fa;border-radius:8px;padding:10px;">
            <div style="font-size:10px;color:#9ca3af;font-weight:600;text-transform:uppercase;">Contato</div>
            <div style="font-size:13px;font-weight:600;color:#374151;">${p.contact || '—'}</div>
          </div>
        </div>
        ${p.notes ? `<div style="font-size:12px;color:#6c757d;margin-bottom:12px;"><i class="fas fa-info-circle" style="color:#3498DB;margin-right:4px;"></i>${p.notes}</div>` : ''}
        <div style="display:flex;gap:8px;">
          <button class="btn btn-secondary btn-sm" style="flex:1;"
            onclick="editPlanta('${p.id}','${p.name.replace(/'/g,"\\'")}','${p.location.replace(/'/g,"\\'")}','${p.totalCapacity||0}','${p.contact||''}','${p.status}','${(p.notes||'').replace(/'/g,"\\'")}')">
            <i class="fas fa-edit"></i> Editar
          </button>
          <button class="btn btn-danger btn-sm" onclick="deletePlanta('${p.id}')"><i class="fas fa-trash"></i></button>
        </div>
      </div>`).join('')

  // ── Máquinas rows ────────────────────────────────────────────────────────
  const maquinasHtml = machines.length === 0
    ? `<tr><td colspan="7" style="text-align:center;padding:40px;color:#9ca3af;">
        <i class="fas fa-cog" style="font-size:32px;color:#d1d5db;display:block;margin-bottom:10px;"></i>
        Nenhuma máquina cadastrada. Clique em <strong>+ Nova Máquina</strong>.
      </td></tr>`
    : machines.map((m: any) => `
      <tr id="machine-${m.id}">
        <td>
          <div style="display:flex;align-items:center;gap:10px;">
            <div style="width:32px;height:32px;border-radius:8px;background:${m.status === 'operational' ? '#eafaf1' : m.status === 'maintenance' ? '#fff8e8' : '#f8f9fa'};display:flex;align-items:center;justify-content:center;">
              <i class="fas fa-cog" style="color:${m.status === 'operational' ? '#27AE60' : m.status === 'maintenance' ? '#F39C12' : '#9ca3af'};font-size:13px;"></i>
            </div>
            <div>
              <div style="font-weight:600;color:#1B4F72;">${m.name}</div>
              <div style="font-size:11px;color:#9ca3af;">ID: ${m.id}</div>
            </div>
          </div>
        </td>
        <td><span class="chip" style="background:#e8f4fd;color:#1B4F72;">${m.type}</span></td>
        <td style="font-size:12px;color:#6c757d;">${m.capacity || '—'}</td>
        <td style="font-size:12px;color:#6c757d;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${m.specs || '—'}</td>
        <td style="font-size:12px;color:#6c757d;">${m.plantName || '—'}</td>
        <td>${statusBadgeMachine(m.status)}</td>
        <td>
          <div style="display:flex;gap:4px;">
            <button class="btn btn-secondary btn-sm"
              onclick="editMaquina('${m.id}','${m.name.replace(/'/g,"\\'")}','${m.type}','${m.capacity||''}','${m.plantId||''}','${m.status}','${(m.specs||'').replace(/'/g,"\\'")}')">
              <i class="fas fa-edit"></i>
            </button>
            <button class="btn btn-danger btn-sm" onclick="deleteMaquina('${m.id}')"><i class="fas fa-trash"></i></button>
          </div>
        </td>
      </tr>`).join('')

  // ── Bancadas cards ───────────────────────────────────────────────────────
  const bancadasHtml = workbenches.length === 0
    ? `<div style="grid-column:1/-1;text-align:center;padding:40px 0;">
        <i class="fas fa-table" style="font-size:40px;color:#d1d5db;"></i>
        <p style="margin-top:12px;color:#9ca3af;font-size:14px;">Nenhuma bancada cadastrada.</p>
      </div>`
    : workbenches.map((wb: any) => {
        const statusColor = wb.status === 'available' ? '#27AE60' : wb.status === 'in_use' ? '#3498DB' : '#F39C12'
        const statusLabel = ({ available: 'Disponível', in_use: 'Em Uso', maintenance: 'Manutenção' } as any)[wb.status] || wb.status
        return `
        <div class="card" style="padding:18px;border-left:4px solid ${statusColor};" id="wb-${wb.id}">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
            <div style="font-size:15px;font-weight:700;color:#1B4F72;">${wb.name}</div>
            <span class="badge ${wb.status === 'available' ? 'badge-success' : wb.status === 'in_use' ? 'badge-info' : 'badge-warning'}">${statusLabel}</span>
          </div>
          <div style="font-size:12px;color:#6c757d;margin-bottom:6px;"><i class="fas fa-wrench" style="margin-right:6px;"></i>${wb.function || '—'}</div>
          <div style="font-size:12px;color:#6c757d;"><i class="fas fa-building" style="margin-right:6px;"></i>${wb.plantName || '—'}</div>
          <div style="display:flex;gap:8px;margin-top:12px;">
            <button class="btn btn-secondary btn-sm" style="flex:1;"
              onclick="editBancada('${wb.id}','${wb.name.replace(/'/g,"\\'")}','${(wb.function||'').replace(/'/g,"\\'")}','${wb.plantId||''}','${wb.status}')">
              <i class="fas fa-edit"></i> Editar
            </button>
            <button class="btn btn-danger btn-sm" onclick="deleteBancada('${wb.id}')"><i class="fas fa-trash"></i></button>
          </div>
        </div>`
      }).join('')

  const content = `
  <!-- Header -->
  <div class="section-header">
    <div style="font-size:14px;color:#6c757d;">Plantas, Máquinas, Bancadas e Equipamentos</div>
    <div style="display:flex;gap:8px;">
      <button class="btn btn-secondary" onclick="openModal('novaBancadaModal')"><i class="fas fa-table"></i> Nova Bancada</button>
      <button class="btn btn-secondary" onclick="openModal('novaMaquinaModal')"><i class="fas fa-cog"></i> Nova Máquina</button>
      <button class="btn btn-primary" onclick="openModal('novaPlantaModal')"><i class="fas fa-plus"></i> Nova Planta</button>
    </div>
  </div>

  <!-- Tab Navigation -->
  <div data-tab-group="recursos">
    <div class="tab-nav">
      <button class="tab-btn active" onclick="switchTab('tabPlantas','recursos')"><i class="fas fa-building" style="margin-right:6px;"></i>Plantas (${plants.length})</button>
      <button class="tab-btn" onclick="switchTab('tabMaquinas','recursos')"><i class="fas fa-cog" style="margin-right:6px;"></i>Máquinas (${machines.length})</button>
      <button class="tab-btn" onclick="switchTab('tabBancadas','recursos')"><i class="fas fa-table" style="margin-right:6px;"></i>Bancadas (${workbenches.length})</button>
    </div>

    <!-- Plantas Tab -->
    <div class="tab-content active" id="tabPlantas">
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px;" id="plantasGrid">
        ${plantasHtml}
        <!-- Add New Card -->
        <div class="card" style="padding:20px;border:2px dashed #d1d5db;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:200px;cursor:pointer;background:transparent;" onclick="openModal('novaPlantaModal')">
          <div style="width:48px;height:48px;border-radius:50%;background:#f1f5f9;display:flex;align-items:center;justify-content:center;margin-bottom:12px;">
            <i class="fas fa-plus" style="color:#9ca3af;font-size:20px;"></i>
          </div>
          <div style="font-size:14px;font-weight:600;color:#9ca3af;">Adicionar Planta</div>
        </div>
      </div>
    </div>

    <!-- Máquinas Tab -->
    <div class="tab-content" id="tabMaquinas">
      <div class="card" style="overflow:hidden;">
        <div style="padding:14px 20px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #f1f3f5;">
          <div class="search-box" style="flex:1;max-width:360px;">
            <i class="fas fa-search icon"></i>
            <input class="form-control" type="text" id="searchMaquina" placeholder="Buscar máquina..." oninput="filterMaquinas(this.value)">
          </div>
          <button class="btn btn-primary btn-sm" onclick="openModal('novaMaquinaModal')"><i class="fas fa-plus"></i> Nova Máquina</button>
        </div>
        <div class="table-wrapper">
          <table>
            <thead><tr>
              <th>Nome</th><th>Tipo</th><th>Capacidade</th><th>Especificações</th><th>Planta</th><th>Status</th><th>Ações</th>
            </tr></thead>
            <tbody id="maquinasBody">
              ${maquinasHtml}
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Bancadas Tab -->
    <div class="tab-content" id="tabBancadas">
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;" id="bancadasGrid">
        ${bancadasHtml}
      </div>
    </div>
  </div>

  <!-- ══ MODAL: Nova/Editar Planta ══ -->
  <div class="modal-overlay" id="novaPlantaModal">
    <div class="modal">
      <div style="padding:20px 24px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;">
        <h3 style="margin:0;font-size:17px;font-weight:700;color:#1B4F72;" id="modalPlantaTitulo"><i class="fas fa-building" style="margin-right:8px;"></i>Nova Planta Fabril</h3>
        <button onclick="closeModal('novaPlantaModal')" style="background:none;border:none;font-size:20px;cursor:pointer;color:#9ca3af;">×</button>
      </div>
      <div style="padding:20px 24px;">
        <input type="hidden" id="pId">
        <div class="form-group"><label class="form-label">Nome da Planta *</label><input class="form-control" id="pNome" type="text" placeholder="Ex: Planta Delta"></div>
        <div class="form-group"><label class="form-label">Localização *</label><input class="form-control" id="pLoc" type="text" placeholder="Cidade - UF"></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
          <div class="form-group"><label class="form-label">Capacidade Total (peças/turno)</label><input class="form-control" id="pCap" type="number" placeholder="0"></div>
          <div class="form-group"><label class="form-label">Contato Responsável</label><input class="form-control" id="pContact" type="text" placeholder="Nome"></div>
        </div>
        <div class="form-group"><label class="form-label">Status</label>
          <select class="form-control" id="pStatus"><option value="active">Ativa</option><option value="inactive">Inativa</option></select>
        </div>
        <div class="form-group"><label class="form-label">Observações</label><textarea class="form-control" id="pNotes" rows="3" placeholder="Informações adicionais..."></textarea></div>
      </div>
      <div style="padding:16px 24px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
        <button onclick="closeModal('novaPlantaModal')" class="btn btn-secondary">Cancelar</button>
        <button onclick="savePlanta()" class="btn btn-primary"><i class="fas fa-save"></i> Salvar</button>
      </div>
    </div>
  </div>

  <!-- ══ MODAL: Nova/Editar Máquina ══ -->
  <div class="modal-overlay" id="novaMaquinaModal">
    <div class="modal">
      <div style="padding:20px 24px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;">
        <h3 style="margin:0;font-size:17px;font-weight:700;color:#1B4F72;" id="modalMaqTitulo"><i class="fas fa-cog" style="margin-right:8px;"></i>Nova Máquina</h3>
        <button onclick="closeModal('novaMaquinaModal')" style="background:none;border:none;font-size:20px;cursor:pointer;color:#9ca3af;">×</button>
      </div>
      <div style="padding:20px 24px;">
        <input type="hidden" id="mId">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
          <div class="form-group" style="grid-column:span 2;"><label class="form-label">Nome da Máquina *</label><input class="form-control" id="mNome" type="text" placeholder="Ex: Torno CNC-03"></div>
          <div class="form-group"><label class="form-label">Tipo *</label>
            <select class="form-control" id="mTipo"><option value="CNC">CNC</option><option value="Fresadora">Fresadora</option><option value="Torno">Torno</option><option value="Prensa">Prensa</option><option value="Robótica">Robótica</option><option value="Injetora">Injetora</option><option value="Outro">Outro</option></select>
          </div>
          <div class="form-group"><label class="form-label">Capacidade</label><input class="form-control" id="mCap" type="text" placeholder="Ex: 200 peças/h"></div>
          <div class="form-group"><label class="form-label">Planta *</label>
            <select class="form-control" id="mPlanta"><option value="">Selecione...</option>${plantOptions}</select>
          </div>
          <div class="form-group"><label class="form-label">Status</label>
            <select class="form-control" id="mStatus"><option value="operational">Operacional</option><option value="maintenance">Manutenção</option><option value="offline">Offline</option></select>
          </div>
          <div class="form-group" style="grid-column:span 2;"><label class="form-label">Especificações Técnicas</label><textarea class="form-control" id="mSpecs" rows="2" placeholder="Modelo, fabricante, características..."></textarea></div>
        </div>
      </div>
      <div style="padding:16px 24px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
        <button onclick="closeModal('novaMaquinaModal')" class="btn btn-secondary">Cancelar</button>
        <button onclick="saveMaquina()" class="btn btn-primary"><i class="fas fa-save"></i> Salvar</button>
      </div>
    </div>
  </div>

  <!-- ══ MODAL: Nova/Editar Bancada ══ -->
  <div class="modal-overlay" id="novaBancadaModal">
    <div class="modal">
      <div style="padding:20px 24px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;">
        <h3 style="margin:0;font-size:17px;font-weight:700;color:#1B4F72;" id="modalBancadaTitulo"><i class="fas fa-table" style="margin-right:8px;"></i>Nova Bancada</h3>
        <button onclick="closeModal('novaBancadaModal')" style="background:none;border:none;font-size:20px;cursor:pointer;color:#9ca3af;">×</button>
      </div>
      <div style="padding:20px 24px;">
        <input type="hidden" id="wbId">
        <div class="form-group"><label class="form-label">Nome da Bancada *</label><input class="form-control" id="wbNome" type="text" placeholder="Ex: Bancada Montagem A1"></div>
        <div class="form-group"><label class="form-label">Função</label><input class="form-control" id="wbFunc" type="text" placeholder="Ex: Montagem Final, Inspeção, Solda..."></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
          <div class="form-group"><label class="form-label">Planta</label>
            <select class="form-control" id="wbPlanta"><option value="">Selecione...</option>${plantOptions}</select>
          </div>
          <div class="form-group"><label class="form-label">Status</label>
            <select class="form-control" id="wbStatus"><option value="available">Disponível</option><option value="in_use">Em Uso</option><option value="maintenance">Manutenção</option></select>
          </div>
        </div>
      </div>
      <div style="padding:16px 24px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
        <button onclick="closeModal('novaBancadaModal')" class="btn btn-secondary">Cancelar</button>
        <button onclick="saveBancada()" class="btn btn-primary"><i class="fas fa-save"></i> Salvar</button>
      </div>
    </div>
  </div>

  <script>
  // ── Toast ──────────────────────────────────────────────────────────────────
  function showToast(msg, type='success') {
    const d = document.createElement('div');
    d.style.cssText = 'position:fixed;bottom:24px;right:24px;padding:12px 20px;border-radius:10px;font-size:14px;font-weight:600;z-index:9999;box-shadow:0 4px 16px rgba(0,0,0,0.15);';
    d.style.background = type === 'success' ? '#27AE60' : '#E74C3C';
    d.style.color = 'white';
    d.textContent = msg;
    document.body.appendChild(d);
    setTimeout(() => d.remove(), 3000);
  }

  // ── Plantas CRUD ───────────────────────────────────────────────────────────
  function resetPlantaModal() {
    document.getElementById('pId').value = '';
    document.getElementById('pNome').value = '';
    document.getElementById('pLoc').value = '';
    document.getElementById('pCap').value = '';
    document.getElementById('pContact').value = '';
    document.getElementById('pStatus').value = 'active';
    document.getElementById('pNotes').value = '';
    document.getElementById('modalPlantaTitulo').innerHTML = '<i class="fas fa-building" style="margin-right:8px;"></i>Nova Planta Fabril';
    openModal('novaPlantaModal');
  }

  function editPlanta(id, nome, loc, cap, contact, status, notes) {
    document.getElementById('pId').value = id;
    document.getElementById('pNome').value = nome;
    document.getElementById('pLoc').value = loc;
    document.getElementById('pCap').value = cap;
    document.getElementById('pContact').value = contact;
    document.getElementById('pStatus').value = status;
    document.getElementById('pNotes').value = notes;
    document.getElementById('modalPlantaTitulo').innerHTML = '<i class="fas fa-edit" style="margin-right:8px;"></i>Editar Planta';
    openModal('novaPlantaModal');
  }

  async function savePlanta() {
    const id      = document.getElementById('pId').value;
    const nome    = document.getElementById('pNome').value.trim();
    const loc     = document.getElementById('pLoc').value.trim();
    const cap     = document.getElementById('pCap').value;
    const contact = document.getElementById('pContact').value.trim();
    const status  = document.getElementById('pStatus').value;
    const notes   = document.getElementById('pNotes').value.trim();
    if (!nome || !loc) { showToast('Preencha Nome e Localização.', 'error'); return; }
    const method = id ? 'PUT' : 'POST';
    const url    = id ? '/recursos/plantas/' + id : '/recursos/plantas';
    const res = await fetch(url, {
      method, headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ nome, loc, cap: parseInt(cap)||0, contact, status, notes })
    });
    const data = await res.json();
    if (data.ok) {
      showToast(id ? 'Planta atualizada!' : 'Planta cadastrada!');
      closeModal('novaPlantaModal');
      setTimeout(() => location.reload(), 600);
    } else { showToast(data.error || 'Erro ao salvar.', 'error'); }
  }

  async function deletePlanta(id) {
    if (!confirm('Deseja excluir esta planta?')) return;
    const res = await fetch('/recursos/plantas/' + id, { method: 'DELETE' });
    const data = await res.json();
    if (data.ok) { showToast('Planta excluída.'); setTimeout(() => location.reload(), 600); }
    else { showToast(data.error || 'Erro.', 'error'); }
  }

  // ── Máquinas CRUD ──────────────────────────────────────────────────────────
  function editMaquina(id, nome, tipo, cap, plantId, status, specs) {
    document.getElementById('mId').value = id;
    document.getElementById('mNome').value = nome;
    document.getElementById('mTipo').value = tipo;
    document.getElementById('mCap').value = cap;
    document.getElementById('mPlanta').value = plantId;
    document.getElementById('mStatus').value = status;
    document.getElementById('mSpecs').value = specs;
    document.getElementById('modalMaqTitulo').innerHTML = '<i class="fas fa-edit" style="margin-right:8px;"></i>Editar Máquina';
    openModal('novaMaquinaModal');
  }

  async function saveMaquina() {
    const id     = document.getElementById('mId').value;
    const nome   = document.getElementById('mNome').value.trim();
    const tipo   = document.getElementById('mTipo').value;
    const cap    = document.getElementById('mCap').value.trim();
    const planta = document.getElementById('mPlanta').value;
    const status = document.getElementById('mStatus').value;
    const specs  = document.getElementById('mSpecs').value.trim();
    if (!nome) { showToast('Preencha o nome da máquina.', 'error'); return; }
    const method = id ? 'PUT' : 'POST';
    const url    = id ? '/recursos/maquinas/' + id : '/recursos/maquinas';
    const res = await fetch(url, {
      method, headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ nome, tipo, cap, plantaId: planta, status, specs })
    });
    const data = await res.json();
    if (data.ok) {
      showToast(id ? 'Máquina atualizada!' : 'Máquina cadastrada!');
      closeModal('novaMaquinaModal');
      setTimeout(() => location.reload(), 600);
    } else { showToast(data.error || 'Erro.', 'error'); }
  }

  async function deleteMaquina(id) {
    if (!confirm('Deseja excluir esta máquina?')) return;
    const res = await fetch('/recursos/maquinas/' + id, { method: 'DELETE' });
    const data = await res.json();
    if (data.ok) { showToast('Máquina excluída.'); setTimeout(() => location.reload(), 600); }
    else { showToast(data.error || 'Erro.', 'error'); }
  }

  function filterMaquinas(q) {
    const rows = document.querySelectorAll('#maquinasBody tr');
    rows.forEach(r => {
      r.style.display = r.textContent.toLowerCase().includes(q.toLowerCase()) ? '' : 'none';
    });
  }

  // ── Bancadas CRUD ──────────────────────────────────────────────────────────
  function editBancada(id, nome, func_, plantId, status) {
    document.getElementById('wbId').value = id;
    document.getElementById('wbNome').value = nome;
    document.getElementById('wbFunc').value = func_;
    document.getElementById('wbPlanta').value = plantId;
    document.getElementById('wbStatus').value = status;
    document.getElementById('modalBancadaTitulo').innerHTML = '<i class="fas fa-edit" style="margin-right:8px;"></i>Editar Bancada';
    openModal('novaBancadaModal');
  }

  async function saveBancada() {
    const id     = document.getElementById('wbId').value;
    const nome   = document.getElementById('wbNome').value.trim();
    const func_  = document.getElementById('wbFunc').value.trim();
    const planta = document.getElementById('wbPlanta').value;
    const status = document.getElementById('wbStatus').value;
    if (!nome) { showToast('Preencha o nome da bancada.', 'error'); return; }
    const method = id ? 'PUT' : 'POST';
    const url    = id ? '/recursos/bancadas/' + id : '/recursos/bancadas';
    const res = await fetch(url, {
      method, headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ nome, func: func_, plantaId: planta, status })
    });
    const data = await res.json();
    if (data.ok) {
      showToast(id ? 'Bancada atualizada!' : 'Bancada cadastrada!');
      closeModal('novaBancadaModal');
      setTimeout(() => location.reload(), 600);
    } else { showToast(data.error || 'Erro.', 'error'); }
  }

  async function deleteBancada(id) {
    if (!confirm('Deseja excluir esta bancada?')) return;
    const res = await fetch('/recursos/bancadas/' + id, { method: 'DELETE' });
    const data = await res.json();
    if (data.ok) { showToast('Bancada excluída.'); setTimeout(() => location.reload(), 600); }
    else { showToast(data.error || 'Erro.', 'error'); }
  }
  </script>
  `
  return c.html(layout('Cadastros de Recursos', content, 'recursos', userInfo))
})

// ── API: Plantas ─────────────────────────────────────────────────────────────
app.post('/plantas', async (c) => {
  const tenant = getCtxTenant(c)
  const db     = getCtxDB(c)
  const userId = getCtxUserId(c)
  const empresaId = getCtxEmpresaId(c)
  const body   = await c.req.json().catch(() => null)
  if (!body) return err(c, 'Dados inválidos')
  if (!body.nome) return err(c, 'Nome é obrigatório')
  if (!body.loc) return err(c, 'Localização é obrigatória')

  console.log('[RECURSOS][POST /plantas]', { userId, empresaId, hasDB: !!db, body })

  const id = genId('p')
  const planta = {
    id, name: body.nome, location: body.loc,
    totalCapacity: body.cap || 0, contact: body.contact || '',
    status: body.status || 'active', notes: body.notes || ''
  }

  if (db && userId !== 'demo-tenant') {
    console.log('[RECURSOS] Inserindo planta em D1:', { id, empresaId, name: planta.name })
    const inserted = await dbInsert(db, 'plants', {
      id, user_id: userId, empresa_id: empresaId,
      name: planta.name, location: planta.location,
      total_capacity: planta.totalCapacity, contact: planta.contact,
      status: planta.status, notes: planta.notes,
      created_at: new Date().toISOString(),
    })
    if (!inserted) {
      console.error(`[CRÍTICO] Falha ao inserir planta ${id} em D1`)
      return err(c, 'Falha ao salvar em D1. Tente novamente.', 500)
    }
  }
  tenant.plants.push(planta)
  markTenantModified(userId)
  return ok(c, { id, plant: planta })
})

app.put('/plantas/:id', async (c) => {
  const tenant = getCtxTenant(c)
  const db     = getCtxDB(c)
  const userId = getCtxUserId(c)
  const id     = c.req.param('id')
  const body   = await c.req.json().catch(() => null)
  if (!body) return err(c, 'Dados inválidos')

  const idx = tenant.plants.findIndex((p: any) => p.id === id)
  if (idx === -1) return err(c, 'Planta não encontrada', 404)

  if (db && userId !== 'demo-tenant') {
    const updated = await dbUpdate(db, 'plants', id, userId, {
      name: body.nome, location: body.loc,
      total_capacity: body.cap || 0, contact: body.contact || '',
      status: body.status || 'active', notes: body.notes || '',
    })
    if (!updated) {
      console.error(`[CRÍTICO] Falha ao atualizar planta ${id} em D1`)
      return err(c, 'Falha ao salvar em D1. Tente novamente.', 500)
    }
  }
  tenant.plants[idx] = {
    ...tenant.plants[idx],
    name: body.nome, location: body.loc,
    totalCapacity: body.cap || 0, contact: body.contact || '',
    status: body.status || 'active', notes: body.notes || ''
  }
  markTenantModified(userId)
  return ok(c, { plant: tenant.plants[idx] })
})

app.delete('/plantas/:id', async (c) => {
  const tenant = getCtxTenant(c)
  const db     = getCtxDB(c)
  const userId = getCtxUserId(c)
  const id     = c.req.param('id')

  const idx = tenant.plants.findIndex((p: any) => p.id === id)
  if (idx === -1) return err(c, 'Planta não encontrada', 404)
  if (db && userId !== 'demo-tenant') {
    await dbDelete(db, 'plants', id, userId)
  }
  tenant.plants.splice(idx, 1)
  markTenantModified(userId)
  return ok(c)
})

// ── API: Máquinas ─────────────────────────────────────────────────────────────
app.post('/maquinas', async (c) => {
  const tenant = getCtxTenant(c)
  const db     = getCtxDB(c)
  const userId = getCtxUserId(c)
  const empresaId = getCtxEmpresaId(c)
  const body   = await c.req.json().catch(() => null)
  if (!body) return err(c, 'Dados inválidos')
  if (!body.nome) return err(c, 'Nome é obrigatório')
  if (db && userId !== 'demo-tenant' && !body.plantaId?.trim()) {
    return err(c, 'Planta é obrigatória', 400)
  }

  console.log('[RECURSOS][POST /maquinas]', { userId, empresaId, hasDB: !!db, body })

  const id = genId('m')
  const planta = tenant.plants.find((p: any) => p.id === body.plantaId)

  if (db && userId !== 'demo-tenant' && body.plantaId) {
    if (!planta) {
      console.warn('[RECURSOS][POST /maquinas] plant_id inválido:', { userId, empresaId, plantaId: body.plantaId })
      return err(c, 'plant_id inválido ou não encontrado', 400)
    }
  }

  const maquina = {
    id, name: body.nome, type: body.tipo,
    capacity: body.cap || '', plantId: body.plantaId || '',
    plantName: planta?.name || '',
    status: body.status || 'operational', specs: body.specs || ''
  }

  if (db && userId !== 'demo-tenant') {
    console.log('[RECURSOS] Inserindo maquina em D1:', { id, empresaId, name: maquina.name })
    try {
      const inserted = await dbInsert(db, 'machines', {
        id, user_id: userId, empresa_id: empresaId,
        name: maquina.name, type: maquina.type,
        capacity: maquina.capacity, plant_id: maquina.plantId,
        plant_name: maquina.plantName, status: maquina.status,
        specs: maquina.specs, created_at: new Date().toISOString(),
      })
      if (!inserted) {
        console.error(`[CRÍTICO] Falha ao inserir máquina ${id} em D1`)
        return c.json({
          ok: false,
          error: 'Falha ao salvar máquina em D1. Tente novamente.',
          errorCode: 'D1_INSERT_FAILED',
          details: 'Verifique se as migrations foram aplicadas e o schema está correto.',
        }, 500)
      }
    } catch (dbErr) {
      console.error(`[ERRO DB] Inserir máquina ${id}:`, dbErr instanceof Error ? dbErr.message : String(dbErr))
      return err(c, 'Erro ao conectar com banco de dados.', 500)
    }
  }
  tenant.machines.push(maquina)
  markTenantModified(userId)
  return ok(c, { id, machine: maquina })
})

app.put('/maquinas/:id', async (c) => {
  const tenant = getCtxTenant(c)
  const db     = getCtxDB(c)
  const userId = getCtxUserId(c)
  const id     = c.req.param('id')
  const body   = await c.req.json().catch(() => null)
  if (!body) return err(c, 'Dados inválidos')

  const idx = tenant.machines.findIndex((m: any) => m.id === id)
  if (idx === -1) return err(c, 'Máquina não encontrada', 404)

  const planta = tenant.plants.find((p: any) => p.id === body.plantaId)

  if (db && userId !== 'demo-tenant') {
    const updated = await dbUpdate(db, 'machines', id, userId, {
      name: body.nome, type: body.tipo,
      capacity: body.cap || '', plant_id: body.plantaId || '',
      plant_name: planta?.name || '',
      status: body.status || 'operational', specs: body.specs || '',
    })
    if (!updated) {
      console.error(`[CRÍTICO] Falha ao atualizar máquina ${id} em D1`)
      return err(c, 'Falha ao salvar em D1. Tente novamente.', 500)
    }
  }
  tenant.machines[idx] = {
    ...tenant.machines[idx],
    name: body.nome, type: body.tipo,
    capacity: body.cap || '', plantId: body.plantaId || '',
    plantName: planta?.name || '',
    status: body.status || 'operational', specs: body.specs || ''
  }
  markTenantModified(userId)
  return ok(c, { machine: tenant.machines[idx] })
})

app.delete('/maquinas/:id', async (c) => {
  const tenant = getCtxTenant(c)
  const db     = getCtxDB(c)
  const userId = getCtxUserId(c)
  const id     = c.req.param('id')

  const idx = tenant.machines.findIndex((m: any) => m.id === id)
  if (idx === -1) return err(c, 'Máquina não encontrada', 404)
  if (db && userId !== 'demo-tenant') {
    await dbDelete(db, 'machines', id, userId)
  }
  tenant.machines.splice(idx, 1)
  markTenantModified(userId)
  return ok(c)
})

// ── API: Bancadas ─────────────────────────────────────────────────────────────
app.post('/bancadas', async (c) => {
  const tenant = getCtxTenant(c)
  const db     = getCtxDB(c)
  const userId = getCtxUserId(c)
  const empresaId = getCtxEmpresaId(c)
  const body   = await c.req.json().catch(() => null)
  if (!body) return err(c, 'Dados inválidos')
  if (!body.nome) return err(c, 'Nome é obrigatório')
  if (db && userId !== 'demo-tenant' && !body.plantaId?.trim()) {
    return err(c, 'Planta é obrigatória', 400)
  }

  console.log('[RECURSOS][POST /bancadas]', { userId, empresaId, hasDB: !!db, body })

  const id = genId('wb')
  const planta = tenant.plants.find((p: any) => p.id === body.plantaId)

  if (db && userId !== 'demo-tenant' && body.plantaId) {
    if (!planta) {
      console.warn('[RECURSOS][POST /bancadas] plant_id inválido:', { userId, empresaId, plantaId: body.plantaId })
      return err(c, 'plant_id inválido ou não encontrado', 400)
    }
  }
  const bancada = {
    id, name: body.nome, function: body.func || '',
    plantId: body.plantaId || '', plantName: planta?.name || '',
    status: body.status || 'available'
  }

  if (db && userId !== 'demo-tenant') {
    console.log('[RECURSOS] Inserindo bancada em D1:', { id, empresaId, name: bancada.name })
    try {
      const result = await dbInsert(db, 'workbenches', {
        id, user_id: userId, empresa_id: empresaId || '',
        name: bancada.name, function: bancada.function || '',
        plant_id: bancada.plantId, plant_name: bancada.plantName || '',
        status: bancada.status, created_at: new Date().toISOString(),
      })
      if (!result) {
        console.error(`[CRÍTICO] Falha ao inserir bancada ${id} em D1`)
        return c.json({
          ok: false,
          error: 'Falha ao salvar bancada em D1. Tente novamente.',
          errorCode: 'D1_INSERT_FAILED',
          details: 'Verifique se as migrations foram aplicadas e o schema está correto.',
        }, 500)
      }
    } catch (dbErr) {
      console.error(`[ERRO DB] Inserir bancada ${id}:`, dbErr instanceof Error ? dbErr.message : String(dbErr))
      return err(c, 'Erro ao conectar com banco de dados.', 500)
    }
  }
  tenant.workbenches.push(bancada)
  markTenantModified(userId)
  return ok(c, { id, workbench: bancada })
})

app.get('/api/debug/workbenches-schema', async (c) => {
  const env = c.env as Record<string, string> | undefined
  if (env?.DEBUG !== '1') {
    return c.json({ ok: false, error: 'Not found' }, 404)
  }
  const db = getCtxDB(c)
  if (!db) {
    return c.json({ ok: false, error: 'D1 não disponível neste ambiente' }, 503)
  }
  try {
    const [tableInfo, masterRow] = await Promise.all([
      db.prepare('PRAGMA table_info(workbenches)').all(),
      db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='workbenches'").first(),
    ])
    return c.json({
      ok: true,
      columns: tableInfo.results,
      ddl: (masterRow as { sql: string | null } | null)?.sql ?? null,
    })
  } catch (e) {
    return c.json({ ok: false, error: 'Erro ao consultar schema', message: (e as any)?.message }, 500)
  }
})

app.put('/bancadas/:id', async (c) => {
  const tenant = getCtxTenant(c)
  const db     = getCtxDB(c)
  const userId = getCtxUserId(c)
  const id     = c.req.param('id')
  const body   = await c.req.json().catch(() => null)
  if (!body) return err(c, 'Dados inválidos')

  const idx = tenant.workbenches.findIndex((wb: any) => wb.id === id)
  if (idx === -1) return err(c, 'Bancada não encontrada', 404)

  const planta = tenant.plants.find((p: any) => p.id === body.plantaId)

  if (db && userId !== 'demo-tenant') {
    try {
      const updated = await dbUpdate(db, 'workbenches', id, userId, {
        name: body.nome, function: body.func || '',
        plant_id: body.plantaId || '', plant_name: planta?.name || '',
        status: body.status || 'available',
      })
      if (!updated) {
        console.error(`[CRÍTICO] Falha ao atualizar bancada ${id} em D1`)
        return err(c, 'Falha ao salvar bancada em D1. Tente novamente.', 500)
      }
    } catch (dbErr) {
      console.error(`[ERRO DB] Atualizar bancada ${id}:`, dbErr instanceof Error ? dbErr.message : String(dbErr))
      return err(c, 'Erro ao conectar com banco de dados.', 500)
    }
  }
  tenant.workbenches[idx] = {
    ...tenant.workbenches[idx],
    name: body.nome, function: body.func || '',
    plantId: body.plantaId || '', plantName: planta?.name || '',
    status: body.status || 'available'
  }
  markTenantModified(userId)
  return ok(c, { workbench: tenant.workbenches[idx] })
})

app.delete('/bancadas/:id', async (c) => {
  const tenant = getCtxTenant(c)
  const db     = getCtxDB(c)
  const userId = getCtxUserId(c)
  const id     = c.req.param('id')

  const idx = tenant.workbenches.findIndex((wb: any) => wb.id === id)
  if (idx === -1) return err(c, 'Bancada não encontrada', 404)
  if (db && userId !== 'demo-tenant') {
    await dbDelete(db, 'workbenches', id, userId)
  }
  tenant.workbenches.splice(idx, 1)
  markTenantModified(userId)
  return ok(c)
})

export default app
