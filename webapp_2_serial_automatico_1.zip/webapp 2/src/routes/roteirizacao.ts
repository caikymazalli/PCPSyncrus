import { Hono } from 'hono'
import { layout } from '../layout'
import { getCtxSession, getCtxDB, getCtxUserId, getCtxEmpresaId, getCtxUserInfo } from '../sessionHelper'
import { genId, dbInsert, dbUpdate, dbDelete } from '../dbHelpers'
function ok(data: any = {}) { return { ok: true, ...data } }
function err(msg: string) { return { ok: false, error: msg } }
import { requireModuleWriteAccess } from '../moduleAccess'

const app = new Hono()

// ── Write-guard middleware ────────────────────────────────────────────────────
app.use('*', async (c, next) => {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(c.req.method)) {
    const blocked = await requireModuleWriteAccess(c, 'roteirizacao')
    if (blocked) return blocked
  }
  return next()
})

// ── Helpers ──────────────────────────────────────────────────────────────────
function esc(s: any): string {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')
}
function fmtDate(d: string | null | undefined): string {
  if (!d) return '—'
  try { return new Date(d + 'T12:00:00').toLocaleDateString('pt-BR') } catch { return d }
}
function fmtDateTime(d: string | null | undefined): string {
  if (!d) return '—'
  try { return new Date(d).toLocaleString('pt-BR') } catch { return d }
}
/** Serializa JSON de forma segura para uso em bloco <script> */
function safeJson(obj: any): string {
  return JSON.stringify(obj)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026')
    .replace(/'/g, '\\u0027')
}

// ── Status configs ────────────────────────────────────────────────────────────
const ROTA_STATUS: Record<string, { label: string; color: string; bg: string; icon: string }> = {
  planejada:    { label: 'Planejada',    color: '#2980B9', bg: '#e8f4fd', icon: 'fa-clock' },
  em_andamento: { label: 'Em Andamento', color: '#d97706', bg: '#fef3c7', icon: 'fa-truck' },
  concluida:    { label: 'Concluída',    color: '#16a34a', bg: '#dcfce7', icon: 'fa-check-circle' },
  cancelada:    { label: 'Cancelada',    color: '#dc2626', bg: '#fee2e2', icon: 'fa-times-circle' },
  parcial:      { label: 'Parcial',      color: '#8e44ad', bg: '#f5eef8', icon: 'fa-exclamation-circle' },
}
const PARADA_STATUS: Record<string, { label: string; color: string; bg: string }> = {
  pendente:    { label: 'Pendente',    color: '#6c757d', bg: '#f1f3f5' },
  em_transito: { label: 'Em Trânsito', color: '#2980B9', bg: '#e8f4fd' },
  entregue:    { label: 'Entregue',    color: '#16a34a', bg: '#dcfce7' },
  tentativa:   { label: 'Tentativa',   color: '#d97706', bg: '#fef3c7' },
  reagendado:  { label: 'Reagendado',  color: '#8e44ad', bg: '#f5eef8' },
  devolvido:   { label: 'Devolvido',   color: '#dc2626', bg: '#fee2e2' },
  cancelado:   { label: 'Cancelado',   color: '#6c757d', bg: '#f1f3f5' },
}
const VEICULO_STATUS: Record<string, { label: string; color: string; bg: string }> = {
  disponivel:    { label: 'Disponível',   color: '#16a34a', bg: '#dcfce7' },
  em_rota:       { label: 'Em Rota',      color: '#2980B9', bg: '#e8f4fd' },
  manutencao:    { label: 'Manutenção',   color: '#d97706', bg: '#fef3c7' },
  indisponivel:  { label: 'Indisponível', color: '#dc2626', bg: '#fee2e2' },
}
const PRIORIDADE: Record<string, { label: string; color: string }> = {
  baixa:   { label: 'Baixa',   color: '#6c757d' },
  normal:  { label: 'Normal',  color: '#2980B9' },
  alta:    { label: 'Alta',    color: '#d97706' },
  urgente: { label: 'Urgente', color: '#dc2626' },
}

function badge(map: Record<string, any>, key: string): string {
  const m = map[key] || { label: key, color: '#6c757d', bg: '#f1f3f5' }
  return `<span class="badge" style="background:${m.bg};color:${m.color};">${esc(m.label)}</span>`
}

// ── Auto-migração defensiva ───────────────────────────────────────────────────
async function ensureTables(db: D1Database) {
  const ddls = [
    `CREATE TABLE IF NOT EXISTS rot_veiculos (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, empresa_id TEXT DEFAULT '1',
      placa TEXT NOT NULL, apelido TEXT, tipo TEXT NOT NULL DEFAULT 'truck',
      modelo TEXT, marca TEXT, ano INTEGER,
      capacidade_kg REAL DEFAULT 0, capacidade_vol REAL DEFAULT 0, capacidade_pal INTEGER DEFAULT 0,
      motorista_nome TEXT, motorista_cnh TEXT, motorista_tel TEXT,
      lat_atual REAL, lon_atual REAL, ultima_atualizacao TEXT,
      status TEXT NOT NULL DEFAULT 'disponivel', cor TEXT DEFAULT '#2980B9',
      observacoes TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS rot_rotas (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, empresa_id TEXT DEFAULT '1',
      codigo TEXT NOT NULL, descricao TEXT, veiculo_id TEXT,
      motorista_nome TEXT, motorista_tel TEXT,
      data_saida_prev TEXT NOT NULL, data_saida_real TEXT,
      data_retorno_prev TEXT, data_retorno_real TEXT,
      origem_nome TEXT NOT NULL DEFAULT 'Matriz', origem_endereco TEXT,
      origem_cidade TEXT, origem_estado TEXT DEFAULT 'SP',
      origem_lat REAL DEFAULT -23.5505, origem_lon REAL DEFAULT -46.6333,
      total_paradas INTEGER DEFAULT 0, total_entregas INTEGER DEFAULT 0,
      total_peso_kg REAL DEFAULT 0, distancia_km REAL DEFAULT 0,
      tempo_est_min INTEGER DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'planejada',
      prioridade TEXT DEFAULT 'normal', observacoes TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS rot_paradas (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, empresa_id TEXT DEFAULT '1',
      rota_id TEXT NOT NULL, ordem INTEGER NOT NULL DEFAULT 1,
      cliente_nome TEXT NOT NULL, cliente_id TEXT, documento TEXT,
      endereco TEXT NOT NULL, numero TEXT, complemento TEXT, bairro TEXT,
      cidade TEXT NOT NULL, estado TEXT NOT NULL DEFAULT 'SP', cep TEXT,
      lat REAL, lon REAL,
      pedido_ref TEXT, nf_numero TEXT, nf_chave TEXT,
      volumes INTEGER DEFAULT 1, peso_kg REAL DEFAULT 0, valor_nf REAL DEFAULT 0,
      horario_prev TEXT, horario_real TEXT, janela_ini TEXT, janela_fim TEXT,
      status TEXT NOT NULL DEFAULT 'pendente',
      motivo_ocorrencia TEXT, assinatura_nome TEXT, foto_comprovante TEXT,
      observacoes TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS rot_ocorrencias (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, empresa_id TEXT DEFAULT '1',
      rota_id TEXT NOT NULL, parada_id TEXT, tipo TEXT NOT NULL,
      descricao TEXT, lat REAL, lon REAL, created_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS rot_cotacoes_frete (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, empresa_id TEXT DEFAULT '1',
      numero TEXT NOT NULL,
      remetente_nome TEXT NOT NULL, remetente_endereco TEXT, remetente_cidade TEXT,
      remetente_estado TEXT DEFAULT 'SP', remetente_cep TEXT, remetente_cnpj TEXT,
      destinatario_nome TEXT NOT NULL, destinatario_endereco TEXT, destinatario_cidade TEXT,
      destinatario_estado TEXT, destinatario_cep TEXT, destinatario_cnpj TEXT,
      modal TEXT DEFAULT 'rodoviario', tipo_servico TEXT DEFAULT 'normal',
      total_volumes INTEGER DEFAULT 1, peso_total_kg REAL DEFAULT 0,
      valor_nf REAL DEFAULT 0, incoterm TEXT DEFAULT 'CIF',
      volumes_detalhe TEXT DEFAULT '[]',
      data_coleta TEXT, data_entrega_prev TEXT,
      obs TEXT, transportadoras TEXT DEFAULT '[]',
      status TEXT DEFAULT 'aberta', vencimento TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    )`,
  ]
  for (const ddl of ddls) {
    try { await db.prepare(ddl).run() } catch {}
  }
  const idxs = [
    'CREATE INDEX IF NOT EXISTS idx_rot_veiculos_user ON rot_veiculos(user_id)',
    'CREATE INDEX IF NOT EXISTS idx_rot_rotas_user ON rot_rotas(user_id)',
    'CREATE INDEX IF NOT EXISTS idx_rot_rotas_status ON rot_rotas(status)',
    'CREATE INDEX IF NOT EXISTS idx_rot_paradas_rota ON rot_paradas(rota_id)',
    'CREATE INDEX IF NOT EXISTS idx_rot_paradas_status ON rot_paradas(status)',
    'CREATE INDEX IF NOT EXISTS idx_rot_ocorr_rota ON rot_ocorrencias(rota_id)',
    'CREATE INDEX IF NOT EXISTS idx_rot_cotfrete_user ON rot_cotacoes_frete(user_id)',
  ]
  for (const idx of idxs) { try { await db.prepare(idx).run() } catch {} }
}

// ── Loader D1-first ───────────────────────────────────────────────────────────
async function loadData(db: D1Database | null, userId: string) {
  if (!db) return { veiculos: [], rotas: [], paradas: [], ocorrencias: [], cotacoesFrete: [] }
  try {
    await ensureTables(db)
    const [veiculos, rotas, paradas, ocorrencias, cotacoesFrete] = await Promise.all([
      db.prepare('SELECT * FROM rot_veiculos WHERE user_id=? ORDER BY placa ASC').bind(userId).all(),
      db.prepare('SELECT * FROM rot_rotas WHERE user_id=? ORDER BY data_saida_prev DESC').bind(userId).all(),
      db.prepare('SELECT * FROM rot_paradas WHERE user_id=? ORDER BY rota_id, ordem ASC').bind(userId).all(),
      db.prepare('SELECT * FROM rot_ocorrencias WHERE user_id=? ORDER BY created_at DESC LIMIT 200').bind(userId).all(),
      db.prepare('SELECT * FROM rot_cotacoes_frete WHERE user_id=? ORDER BY created_at DESC').bind(userId).all(),
    ])
    return {
      veiculos: veiculos.results || [],
      rotas: rotas.results || [],
      paradas: paradas.results || [],
      ocorrencias: ocorrencias.results || [],
      cotacoesFrete: cotacoesFrete.results || [],
    }
  } catch (e) {
    console.error('[ROTEIRIZACAO] loadData error:', e)
    return { veiculos: [], rotas: [], paradas: [], ocorrencias: [], cotacoesFrete: [] }
  }
}

// ── Estados brasileiros ───────────────────────────────────────────────────────
const ESTADOS_BR = [
  'AC','AL','AM','AP','BA','CE','DF','ES','GO','MA','MG','MS','MT',
  'PA','PB','PE','PI','PR','RJ','RN','RO','RR','RS','SC','SE','SP','TO'
]

// ── Página principal GET / ────────────────────────────────────────────────────
app.get('/', async (c) => {
  const session = getCtxSession(c)
  if (!session) return c.redirect('/')
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  const userInfo = getCtxUserInfo(c)
  const { veiculos, rotas, paradas, cotacoesFrete } = await loadData(db, userId)

  // KPIs
  const totalRotas = rotas.length
  const rotasAtivas = (rotas as any[]).filter(r => r.status === 'em_andamento').length
  const rotasPlanejadas = (rotas as any[]).filter(r => r.status === 'planejada').length
  const totalEntregas = (paradas as any[]).length
  const entreguesOk = (paradas as any[]).filter(p => p.status === 'entregue').length
  const taxaEntrega = totalEntregas > 0 ? Math.round((entreguesOk / totalEntregas) * 100) : 0
  const veiculosDisp = (veiculos as any[]).filter(v => v.status === 'disponivel').length
  const veiculosEmRota = (veiculos as any[]).filter(v => v.status === 'em_rota').length
  const totalPesoKg = (rotas as any[]).reduce((s: number, r: any) => s + (r.total_peso_kg || 0), 0)

  // Monta HTML das paradas por rota (para o mapa)
  const rotasComParadas = (rotas as any[]).map(r => {
    const ps = (paradas as any[]).filter(p => p.rota_id === r.id)
    return { ...r, paradas_list: ps }
  })

  // ── Pré-computa HTML dinâmico fora do template literal ──────────────────────
  // IMPORTANTE: Usar data-* attributes em vez de onclick com parâmetros.
  // O esbuild otimiza strings como '\'' + id + '\'' para template literals com
  // backticks, o que quebra o parser HTML quando está dentro do HTML do servidor.
  // Com data-attributes, não há aspas nos handlers e o problema desaparece.

  // HTML das linhas de rotas
  let htmlRotasTbody: string
  if ((rotas as any[]).length === 0) {
    htmlRotasTbody = '<tr><td colspan="8" style="text-align:center;padding:32px;color:#9ca3af;"><i class="fas fa-route" style="font-size:32px;display:block;margin-bottom:8px;opacity:0.3;"></i>Nenhuma rota cadastrada.</td></tr>'
  } else {
    htmlRotasTbody = (rotas as any[]).map((r: any) => {
      const rs = ROTA_STATUS[r.status] || ROTA_STATUS.planejada
      const pr = PRIORIDADE[r.prioridade] || PRIORIDADE.normal
      const veiculo = (veiculos as any[]).find((v: any) => v.id === r.veiculo_id)
      const numParadas = (paradas as any[]).filter((p: any) => p.rota_id === r.id).length
      const veiculoTxt = veiculo ? esc(veiculo.placa) + (veiculo.apelido ? ' &middot; ' + esc(veiculo.apelido) : '') : '&mdash;'
      const pesoTxt = r.total_peso_kg ? (r.total_peso_kg >= 1000 ? (r.total_peso_kg/1000).toFixed(1)+'t' : r.total_peso_kg.toFixed(0)+'kg') : '&mdash;'
      const rid = esc(r.id)
      const rcod = esc(r.codigo)
      return '<tr class="rota-row" data-id="' + rid + '" data-status="' + esc(r.status) + '" data-search="' + esc(r.codigo.toLowerCase()) + ' ' + esc((r.motorista_nome||'').toLowerCase()) + '" style="border-bottom:1px solid #f1f3f5;cursor:pointer;" onclick="openRotaDetail(this.dataset.id)">' +
        '<td style="padding:10px 14px;"><div style="font-weight:700;color:#1B4F72;">' + esc(r.codigo) + '</div><div style="font-size:11px;color:#9ca3af;">' + esc(r.descricao || '') + '</div></td>' +
        '<td style="padding:10px 14px;"><div style="font-weight:600;color:#374151;">' + veiculoTxt + '</div><div style="font-size:11px;color:#9ca3af;">' + esc(r.motorista_nome || '&mdash;') + '</div></td>' +
        '<td style="padding:10px 14px;color:#374151;">' + fmtDate(r.data_saida_prev) + '</td>' +
        '<td style="padding:10px 14px;"><span style="font-weight:700;color:#1B4F72;">' + numParadas + '</span><span style="font-size:11px;color:#9ca3af;"> paradas</span></td>' +
        '<td style="padding:10px 14px;color:#374151;">' + pesoTxt + '</td>' +
        '<td style="padding:10px 14px;text-align:center;"><span style="font-size:12px;font-weight:700;color:' + pr.color + ';">' + esc(pr.label) + '</span></td>' +
        '<td style="padding:10px 14px;text-align:center;"><span class="badge" style="background:' + rs.bg + ';color:' + rs.color + ';"><i class="fas ' + rs.icon + '" style="margin-right:4px;"></i>' + esc(rs.label) + '</span></td>' +
        '<td style="padding:10px 14px;text-align:center;" onclick="event.stopPropagation()">' +
          '<div style="display:flex;gap:4px;justify-content:center;">' +
            '<button class="btn btn-sm btn-secondary" data-id="' + rid + '" onclick="openRotaModal(this.dataset.id)" title="Editar"><i class="fas fa-pencil-alt"></i></button>' +
            '<button class="btn btn-sm" style="background:#fee2e2;color:#dc2626;" data-id="' + rid + '" data-cod="' + rcod + '" onclick="deleteRota(this.dataset.id,this.dataset.cod)" title="Excluir"><i class="fas fa-trash"></i></button>' +
          '</div>' +
        '</td>' +
        '</tr>'
    }).join('')
  }

  // HTML das options de rota para selects do mapa e entregas
  const htmlOptRotasMapa = (rotas as any[]).filter((r: any) => r.status !== 'cancelada').map((r: any) =>
    '<option value="' + esc(r.id) + '">' + esc(r.codigo) + ' &mdash; ' + esc(r.motorista_nome || 'sem motorista') + '</option>'
  ).join('')

  const htmlOptRotasEntregas = (rotas as any[]).map((r: any) =>
    '<option value="' + esc(r.id) + '">' + esc(r.codigo) + '</option>'
  ).join('')

  // HTML das options de veículos para modal de rota
  const htmlOptVeiculos = (veiculos as any[]).map((v: any) =>
    '<option value="' + esc(v.id) + '">' + esc(v.placa) + (v.apelido ? ' &mdash; ' + esc(v.apelido) : '') + '</option>'
  ).join('')

  // HTML das options de estado BR (para modais)
  const htmlOptEstados1 = ESTADOS_BR.map(uf =>
    '<option value="' + uf + '"' + (uf === 'SP' ? ' selected' : '') + '>' + uf + '</option>'
  ).join('')
  const htmlOptEstados2 = ESTADOS_BR.map(uf =>
    '<option value="' + uf + '"' + (uf === 'SP' ? ' selected' : '') + '>' + uf + '</option>'
  ).join('')

  // HTML do grid de frota (veículos) — usa data-id em vez de onclick com parâmetros
  let htmlFrotaGrid: string
  if ((veiculos as any[]).length === 0) {
    htmlFrotaGrid = '<div style="grid-column:1/-1;text-align:center;padding:32px;color:#9ca3af;"><i class="fas fa-truck" style="font-size:32px;display:block;margin-bottom:8px;opacity:0.3;"></i>Nenhum ve&iacute;culo cadastrado.</div>'
  } else {
    htmlFrotaGrid = (veiculos as any[]).map((v: any) => {
      const vs = VEICULO_STATUS[v.status] || VEICULO_STATUS.disponivel
      const tipoIcon = v.tipo === 'carreta' ? 'fa-truck-moving' : v.tipo === 'van' ? 'fa-shuttle-van' : v.tipo === 'moto' ? 'fa-motorcycle' : 'fa-truck'
      const cor = esc(v.cor || '#2980B9')
      const vid = esc(v.id)
      const vplaca = esc(v.placa)
      let infoGrid = ''
      if (v.motorista_nome) infoGrid += '<div><i class="fas fa-user" style="color:#9ca3af;margin-right:4px;"></i>' + esc(v.motorista_nome) + '</div>'
      if (v.capacidade_kg)  infoGrid += '<div><i class="fas fa-weight" style="color:#9ca3af;margin-right:4px;"></i>' + v.capacidade_kg + 'kg</div>'
      if (v.motorista_tel)  infoGrid += '<div><i class="fas fa-phone" style="color:#9ca3af;margin-right:4px;"></i>' + esc(v.motorista_tel) + '</div>'
      if (v.capacidade_vol) infoGrid += '<div><i class="fas fa-box" style="color:#9ca3af;margin-right:4px;"></i>' + v.capacidade_vol + 'm&sup3;</div>'
      return '<div class="card" style="padding:16px;border-left:4px solid ' + cor + ';">' +
        '<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">' +
          '<div style="width:40px;height:40px;border-radius:10px;background:' + cor + '22;display:flex;align-items:center;justify-content:center;font-size:18px;color:' + cor + ';">' +
            '<i class="fas ' + tipoIcon + '"></i>' +
          '</div>' +
          '<div style="flex:1;"><div style="font-weight:700;font-size:15px;color:#1B4F72;">' + vplaca + '</div>' +
          '<div style="font-size:12px;color:#6c757d;">' + esc(v.apelido || v.modelo || v.tipo) + '</div></div>' +
          '<span class="badge" style="background:' + vs.bg + ';color:' + vs.color + ';">' + esc(vs.label) + '</span>' +
        '</div>' +
        '<div style="font-size:12px;color:#374151;display:grid;grid-template-columns:1fr 1fr;gap:4px;">' + infoGrid + '</div>' +
        '<div style="display:flex;gap:6px;margin-top:12px;">' +
          '<button class="btn btn-sm btn-secondary" data-id="' + vid + '" onclick="openVeiculoModal(this.dataset.id)" style="flex:1;"><i class="fas fa-pencil-alt"></i> Editar</button>' +
          '<button class="btn btn-sm" style="background:#fee2e2;color:#dc2626;" data-id="' + vid + '" data-placa="' + vplaca + '" onclick="deleteVeiculo(this.dataset.id,this.dataset.placa)"><i class="fas fa-trash"></i></button>' +
        '</div>' +
        '</div>'
    }).join('')
  }

  // HTML da tabela de entregas — usa data-id em vez de onclick com parâmetros
  let htmlEntregasTbody: string
  if ((paradas as any[]).length === 0) {
    htmlEntregasTbody = '<tr><td colspan="8" style="text-align:center;padding:32px;color:#9ca3af;"><i class="fas fa-map-marker-alt" style="font-size:32px;display:block;margin-bottom:8px;opacity:0.3;"></i>Nenhuma entrega cadastrada.</td></tr>'
  } else {
    htmlEntregasTbody = (paradas as any[]).map((p: any) => {
      const rota = (rotas as any[]).find((r: any) => r.id === p.rota_id)
      const ps = PARADA_STATUS[p.status] || PARADA_STATUS.pendente
      const docHtml = p.documento ? '<div style="font-size:11px;color:#9ca3af;">' + esc(p.documento) + '</div>' : ''
      const nfHtml  = p.nf_numero  ? 'NF: ' + esc(p.nf_numero) + '<br>' : ''
      const pedHtml = p.pedido_ref ? 'Ped: ' + esc(p.pedido_ref) : '&mdash;'
      const hrRealHtml = p.horario_real ? '<br><span style="color:#16a34a;font-size:11px;">Real: ' + esc(p.horario_real) + '</span>' : ''
      const pid = esc(p.id)
      return '<tr class="entrega-row" data-rota="' + esc(p.rota_id) + '" data-status="' + esc(p.status) + '" style="border-bottom:1px solid #f1f3f5;">' +
        '<td style="padding:10px 14px;"><span style="width:24px;height:24px;border-radius:50%;background:#e67e22;color:white;display:inline-flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;">' + (p.ordem||'') + '</span></td>' +
        '<td style="padding:10px 14px;color:#374151;font-weight:600;">' + esc(rota ? rota.codigo : '&mdash;') + '</td>' +
        '<td style="padding:10px 14px;"><div style="font-weight:600;color:#374151;">' + esc(p.cliente_nome) + '</div>' + docHtml + '</td>' +
        '<td style="padding:10px 14px;color:#374151;">' + esc(p.cidade) + ' / <strong>' + esc(p.estado) + '</strong></td>' +
        '<td style="padding:10px 14px;color:#374151;font-size:12px;">' + nfHtml + pedHtml + '</td>' +
        '<td style="padding:10px 14px;color:#374151;">' + (p.horario_prev || '&mdash;') + hrRealHtml + '</td>' +
        '<td style="padding:10px 14px;text-align:center;"><span class="badge" style="background:' + ps.bg + ';color:' + ps.color + ';">' + esc(ps.label) + '</span></td>' +
        '<td style="padding:10px 14px;text-align:center;"><button class="btn btn-sm btn-secondary" data-id="' + pid + '" onclick="openEntregaModal(this.dataset.id)" title="Atualizar status"><i class="fas fa-edit"></i></button></td>' +
        '</tr>'
    }).join('')
  }

  // HTML dos cards de estado do mapa Brasil — usa data-uf em vez de onclick com parâmetros
  const htmlEstadosGrid = ESTADOS_BR.map(uf => {
    const paradasUf = (paradas as any[]).filter((p: any) => p.estado === uf)
    const entregues = paradasUf.filter((p: any) => p.status === 'entregue').length
    const pendentes = paradasUf.filter((p: any) => ['pendente','em_transito'].includes(p.status)).length
    const problemas = paradasUf.filter((p: any) => ['tentativa','devolvido'].includes(p.status)).length
    const temEntrega = paradasUf.length > 0
    const temPendente = pendentes > 0 || problemas > 0
    const cardClass = 'estado-card' + (temEntrega && !temPendente ? ' tem-entrega' : '') + (temPendente ? ' tem-pendente' : '')
    const cardStyle = temEntrega ? (temPendente ? 'border-color:#d97706;background:#fef3c7;' : 'border-color:#2980B9;background:#e8f4fd;') : ''
    const titleAttr = uf + ': ' + paradasUf.length + ' entregas (' + entregues + ' ok, ' + pendentes + ' pendentes, ' + problemas + ' problemas)'
    let inner = '<div style="font-size:14px;font-weight:800;color:#1B4F72;">' + uf + '</div>'
    if (temEntrega) {
      inner += '<div style="font-size:10px;color:#6c757d;margin-top:2px;">' + paradasUf.length + ' entregas</div>'
      inner += '<div style="display:flex;gap:3px;justify-content:center;margin-top:4px;">'
      if (entregues > 0) inner += '<span style="width:8px;height:8px;border-radius:50%;background:#16a34a;display:inline-block;" title="' + entregues + ' entregue(s)"></span>'
      if (pendentes > 0) inner += '<span style="width:8px;height:8px;border-radius:50%;background:#d97706;display:inline-block;" title="' + pendentes + ' pendente(s)"></span>'
      if (problemas > 0) inner += '<span style="width:8px;height:8px;border-radius:50%;background:#dc2626;display:inline-block;" title="' + problemas + ' problema(s)"></span>'
      inner += '</div>'
    } else {
      inner += '<div style="font-size:10px;color:#d1d5db;margin-top:2px;">sem entrega</div>'
    }
    return '<div class="' + cardClass + '" data-uf="' + uf + '" onclick="openEstadoDetail(this.dataset.uf)" title="' + titleAttr + '" style="' + cardStyle + '">' + inner + '</div>'
  }).join('')

  const content = `
<style>
.rot-tab { padding:10px 18px;font-size:13px;font-weight:600;border:none;background:none;cursor:pointer;color:#6c757d;border-bottom:3px solid transparent;white-space:nowrap;transition:all 0.2s; }
.rot-tab.active { color:#e67e22;border-bottom:3px solid #e67e22; }
.rot-panel { display:none; }
.rot-panel.active { display:block; }
.map-container { background:#f0f4f8;border-radius:12px;overflow:hidden;position:relative; }
.brasil-map { width:100%;height:520px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#e8f4fd 0%,#dbeafe 100%); }
.estado-card { background:white;border-radius:8px;padding:10px 14px;text-align:center;cursor:pointer;border:2px solid transparent;transition:all 0.2s;font-size:12px;font-weight:700; }
.estado-card:hover { border-color:#e67e22;transform:translateY(-2px);box-shadow:0 4px 12px rgba(230,126,34,0.2); }
.estado-card.tem-entrega { border-color:#2980B9;background:#e8f4fd; }
.estado-card.tem-pendente { border-color:#d97706;background:#fef3c7; }
.parada-item { display:flex;align-items:flex-start;gap:10px;padding:10px 14px;border-bottom:1px solid #f1f3f5;font-size:13px; }
.parada-num { width:28px;height:28px;border-radius:50%;background:#e67e22;color:white;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0; }
.parada-item.entregue .parada-num { background:#16a34a; }
.parada-item.tentativa .parada-num { background:#d97706; }
.parada-item.devolvido .parada-num { background:#dc2626; }
.timeline-line { width:2px;background:#e9ecef;margin:0 auto; }
@keyframes fadeInUp { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
</style>

<div style="padding:24px;">

  <!-- KPIs -->
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;margin-bottom:24px;">
    <div class="kpi-card" style="border-left:4px solid #e67e22;">
      <div class="kpi-label"><i class="fas fa-route" style="color:#e67e22;margin-right:6px;"></i>Rotas</div>
      <div class="kpi-value">${totalRotas}</div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px;">${rotasAtivas} em andamento · ${rotasPlanejadas} planejadas</div>
    </div>
    <div class="kpi-card" style="border-left:4px solid #2980B9;">
      <div class="kpi-label"><i class="fas fa-map-marker-alt" style="color:#2980B9;margin-right:6px;"></i>Entregas</div>
      <div class="kpi-value">${totalEntregas}</div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px;">${entreguesOk} entregues · ${taxaEntrega}% taxa</div>
    </div>
    <div class="kpi-card" style="border-left:4px solid #16a34a;">
      <div class="kpi-label"><i class="fas fa-truck" style="color:#16a34a;margin-right:6px;"></i>Frota</div>
      <div class="kpi-value">${veiculos.length}</div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px;">${veiculosDisp} disponíveis · ${veiculosEmRota} em rota</div>
    </div>
    <div class="kpi-card" style="border-left:4px solid #7c3aed;">
      <div class="kpi-label"><i class="fas fa-weight-hanging" style="color:#7c3aed;margin-right:6px;"></i>Peso Total</div>
      <div class="kpi-value" style="font-size:20px;">${totalPesoKg >= 1000 ? (totalPesoKg/1000).toFixed(1)+'t' : totalPesoKg.toFixed(0)+'kg'}</div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px;">em todas as rotas</div>
    </div>
  </div>

  <!-- Abas -->
  <div style="display:flex;border-bottom:2px solid #e9ecef;margin-bottom:20px;overflow-x:auto;background:white;border-radius:12px 12px 0 0;padding:0 8px;">
    <button class="rot-tab active" data-tab="rotas"><i class="fas fa-route" style="margin-right:6px;"></i>Rotas</button>
    <button class="rot-tab" data-tab="mapa"><i class="fas fa-map-marked-alt" style="margin-right:6px;"></i>Mapa Brasil</button>
    <button class="rot-tab" data-tab="frota"><i class="fas fa-truck" style="margin-right:6px;"></i>Frota</button>
    <button class="rot-tab" data-tab="entregas"><i class="fas fa-box-open" style="margin-right:6px;"></i>Entregas</button>
    <button class="rot-tab" data-tab="cotacoes"><i class="fas fa-tags" style="margin-right:6px;"></i>Cotação de Frete</button>
  </div>

  <!-- ── ABA ROTAS ── -->
  <div id="tab-rotas" class="rot-panel active">
    <div class="card" style="overflow:hidden;">
      <div style="padding:14px 18px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span style="font-size:14px;font-weight:700;color:#1B4F72;"><i class="fas fa-route" style="color:#e67e22;margin-right:8px;"></i>Rotas de Entrega</span>
        <input type="text" id="searchRotas" class="form-control" placeholder="🔍 Buscar rota..." style="width:200px;margin-left:auto;" oninput="filterRotas()">
        <select class="form-control" id="filterRotaStatus" style="width:150px;" onchange="filterRotas()">
          <option value="">Todos status</option>
          <option value="planejada">Planejada</option>
          <option value="em_andamento">Em Andamento</option>
          <option value="concluida">Concluída</option>
          <option value="parcial">Parcial</option>
          <option value="cancelada">Cancelada</option>
        </select>
        <button class="btn btn-primary" onclick="openRotaModal()"><i class="fas fa-plus"></i> Nova Rota</button>
      </div>
      <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:13px;" id="rotasTable">
          <thead><tr style="background:#f8f9fa;border-bottom:2px solid #e9ecef;">
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Código</th>
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Veículo / Motorista</th>
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Saída Prevista</th>
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Paradas</th>
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Peso</th>
            <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Prioridade</th>
            <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Status</th>
            <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Ações</th>
          </tr></thead>
          <tbody id="rotasTbody">
            ${htmlRotasTbody}
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- ── ABA MAPA BRASIL ── -->
  <div id="tab-mapa" class="rot-panel">
    <div class="card" style="overflow:hidden;">
      <div style="padding:14px 18px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span style="font-size:14px;font-weight:700;color:#1B4F72;"><i class="fas fa-map-marked-alt" style="color:#e67e22;margin-right:8px;"></i>Mapa de Entregas — Brasil</span>
        <select class="form-control" id="mapaFiltroRota" style="width:200px;margin-left:auto;" onchange="renderMapa()">
          <option value="">Todas as rotas</option>
          ${htmlOptRotasMapa}
        </select>
      </div>
      <div style="padding:20px;">
        <!-- Legenda -->
        <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px;font-size:12px;">
          <span><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:#16a34a;margin-right:4px;"></span>Entregue</span>
          <span><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:#d97706;margin-right:4px;"></span>Pendente</span>
          <span><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:#dc2626;margin-right:4px;"></span>Problema</span>
          <span><span style="display:inline-block;width:12px;height:12px;border-radius:2px;background:#e8f4fd;border:2px solid #2980B9;margin-right:4px;"></span>Com entrega</span>
        </div>

        <!-- Grid de estados estilizado -->
        <div id="mapaGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(80px,1fr));gap:8px;max-width:900px;margin:0 auto;">
          ${htmlEstadosGrid}
        </div>

        <!-- Detalhe do estado selecionado -->
        <div id="estadoDetail" style="display:none;margin-top:20px;background:#f8f9fa;border-radius:10px;padding:18px;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
            <span id="estadoDetailTitle" style="font-size:15px;font-weight:700;color:#1B4F72;"></span>
            <button onclick="document.getElementById('estadoDetail').style.display='none'" style="background:none;border:none;cursor:pointer;color:#9ca3af;font-size:18px;">&times;</button>
          </div>
          <div id="estadoDetailContent"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── ABA FROTA ── -->
  <div id="tab-frota" class="rot-panel">
    <div class="card" style="overflow:hidden;">
      <div style="padding:14px 18px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span style="font-size:14px;font-weight:700;color:#1B4F72;"><i class="fas fa-truck" style="color:#16a34a;margin-right:8px;"></i>Gestão de Frota</span>
        <button class="btn btn-primary" style="margin-left:auto;" onclick="openVeiculoModal()"><i class="fas fa-plus"></i> Novo Veículo</button>
      </div>
      <div style="padding:16px;display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;" id="frotaGrid">
        ${htmlFrotaGrid}
      </div>
    </div>
  </div>

  <!-- ── ABA ENTREGAS ── -->
  <div id="tab-entregas" class="rot-panel">
    <div class="card" style="overflow:hidden;">
      <div style="padding:14px 18px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span style="font-size:14px;font-weight:700;color:#1B4F72;"><i class="fas fa-box-open" style="color:#2980B9;margin-right:8px;"></i>Monitoramento de Entregas</span>
        <select class="form-control" id="filterEntregaRota" style="width:200px;margin-left:auto;" onchange="filterEntregas()">
          <option value="">Todas as rotas</option>
          ${htmlOptRotasEntregas}
        </select>
        <select class="form-control" id="filterEntregaStatus" style="width:140px;" onchange="filterEntregas()">
          <option value="">Todos status</option>
          <option value="pendente">Pendente</option>
          <option value="em_transito">Em Trânsito</option>
          <option value="entregue">Entregue</option>
          <option value="tentativa">Tentativa</option>
          <option value="reagendado">Reagendado</option>
          <option value="devolvido">Devolvido</option>
        </select>
      </div>
      <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:13px;" id="entregasTable">
          <thead><tr style="background:#f8f9fa;border-bottom:2px solid #e9ecef;">
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">#</th>
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Rota</th>
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Destinatário</th>
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Cidade / UF</th>
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">NF / Pedido</th>
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Previsão</th>
            <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Status</th>
            <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Ações</th>
          </tr></thead>
          <tbody id="entregasTbody">
            ${htmlEntregasTbody}
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- ── ABA COTAÇÃO DE FRETE ── -->
  <div id="tab-cotacoes" class="rot-panel">
    <div class="card" style="overflow:hidden;">
      <div style="padding:14px 18px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
        <span style="font-size:14px;font-weight:700;color:#1B4F72;"><i class="fas fa-tags" style="color:#e67e22;margin-right:8px;"></i>Cotações de Frete</span>
        <input type="text" id="searchCotacoes" class="form-control" placeholder="🔍 Buscar cotação..." style="width:200px;margin-left:auto;" oninput="filterCotacoes()">
        <select class="form-control" id="filterCotStatus" style="width:140px;" onchange="filterCotacoes()">
          <option value="">Todos status</option>
          <option value="aberta">Aberta</option>
          <option value="aguardando">Aguardando</option>
          <option value="respondida">Respondida</option>
          <option value="aprovada">Aprovada</option>
          <option value="cancelada">Cancelada</option>
        </select>
        <button class="btn btn-primary" onclick="openCotFreteModal()"><i class="fas fa-plus"></i> Nova Cotação</button>
      </div>

      <!-- KPIs rápidos cotação -->
      <div style="padding:10px 18px;background:#f8fafc;border-bottom:1px solid #f1f3f5;display:flex;gap:12px;flex-wrap:wrap;">
        <div style="background:white;border-radius:8px;padding:8px 14px;border-left:3px solid #e67e22;min-width:110px;">
          <div style="font-size:18px;font-weight:800;color:#e67e22;">${(cotacoesFrete as any[]).length}</div>
          <div style="font-size:10px;color:#6c757d;">Total cotações</div>
        </div>
        <div style="background:white;border-radius:8px;padding:8px 14px;border-left:3px solid #2980B9;min-width:110px;">
          <div style="font-size:18px;font-weight:800;color:#2980B9;">${(cotacoesFrete as any[]).filter((c: any) => c.status === 'aberta').length}</div>
          <div style="font-size:10px;color:#6c757d;">Em aberto</div>
        </div>
        <div style="background:white;border-radius:8px;padding:8px 14px;border-left:3px solid #16a34a;min-width:110px;">
          <div style="font-size:18px;font-weight:800;color:#16a34a;">${(cotacoesFrete as any[]).filter((c: any) => c.status === 'aprovada').length}</div>
          <div style="font-size:10px;color:#6c757d;">Aprovadas</div>
        </div>
        <div style="background:white;border-radius:8px;padding:8px 14px;border-left:3px solid #d97706;min-width:110px;">
          <div style="font-size:18px;font-weight:800;color:#d97706;">${(cotacoesFrete as any[]).filter((c: any) => c.status === 'respondida').length}</div>
          <div style="font-size:10px;color:#6c757d;">Respondidas</div>
        </div>
      </div>

      <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:13px;" id="cotacoesTable">
          <thead><tr style="background:#f8f9fa;border-bottom:2px solid #e9ecef;">
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Nº / Data</th>
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Remetente</th>
            <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Destinatário</th>
            <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Modal</th>
            <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Volumes</th>
            <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Peso Total</th>
            <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Transp.</th>
            <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Status</th>
            <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Ações</th>
          </tr></thead>
          <tbody id="cotacoesTbody">
            ${(cotacoesFrete as any[]).length === 0
              ? `<tr><td colspan="9" style="text-align:center;padding:32px;color:#9ca3af;"><i class="fas fa-tags" style="font-size:32px;display:block;margin-bottom:8px;opacity:0.3;"></i>Nenhuma cotação de frete. Clique em "Nova Cotação" para começar.</td></tr>`
              : (cotacoesFrete as any[]).map((cot: any) => {
                  const transp = (() => { try { return JSON.parse(cot.transportadoras || '[]') } catch { return [] } })()
                  const statusMap: Record<string, { c: string; bg: string; l: string }> = {
                    aberta: { c: '#2980B9', bg: '#e8f4fd', l: 'Aberta' },
                    aguardando: { c: '#d97706', bg: '#fef9c3', l: 'Aguardando' },
                    respondida: { c: '#7c3aed', bg: '#f5eef8', l: 'Respondida' },
                    aprovada: { c: '#16a34a', bg: '#dcfce7', l: 'Aprovada' },
                    cancelada: { c: '#6c757d', bg: '#f1f3f5', l: 'Cancelada' },
                  }
                  const st = statusMap[cot.status] || statusMap.aberta
                  const modalIcon: Record<string, string> = { rodoviario: 'fa-truck', aereo: 'fa-plane', maritimo: 'fa-ship', ferroviario: 'fa-train' }
                  const mIcon = modalIcon[cot.modal] || 'fa-truck'
                  return `<tr class="cot-row" data-status="${esc(cot.status)}" data-search="${esc((cot.numero||'').toLowerCase())} ${esc((cot.remetente_nome||'').toLowerCase())} ${esc((cot.destinatario_nome||'').toLowerCase())}" style="border-bottom:1px solid #f1f3f5;">
                    <td style="padding:10px 14px;">
                      <div style="font-weight:700;color:#1B4F72;font-family:monospace;">${esc(cot.numero)}</div>
                      <div style="font-size:11px;color:#9ca3af;">${new Date(cot.created_at).toLocaleDateString('pt-BR')}</div>
                    </td>
                    <td style="padding:10px 14px;">
                      <div style="font-weight:600;color:#374151;">${esc(cot.remetente_nome)}</div>
                      <div style="font-size:11px;color:#9ca3af;">${esc(cot.remetente_cidade||'')}${cot.remetente_estado ? '/'+cot.remetente_estado : ''}</div>
                    </td>
                    <td style="padding:10px 14px;">
                      <div style="font-weight:600;color:#374151;">${esc(cot.destinatario_nome)}</div>
                      <div style="font-size:11px;color:#9ca3af;">${esc(cot.destinatario_cidade||'')}${cot.destinatario_estado ? '/'+cot.destinatario_estado : ''}</div>
                    </td>
                    <td style="padding:10px 14px;text-align:center;"><i class="fas ${mIcon}" style="color:#e67e22;"></i><div style="font-size:11px;color:#6c757d;text-transform:capitalize;">${esc(cot.modal)}</div></td>
                    <td style="padding:10px 14px;text-align:center;font-weight:700;">${cot.total_volumes}</td>
                    <td style="padding:10px 14px;text-align:center;">${(cot.peso_total_kg||0).toFixed(1)} kg</td>
                    <td style="padding:10px 14px;text-align:center;font-size:11px;color:#374151;">${transp.length > 0 ? transp.length + ' transp.' : '<span style="color:#9ca3af;">—</span>'}</td>
                    <td style="padding:10px 14px;text-align:center;"><span class="badge" style="background:${st.bg};color:${st.c};">${st.l}</span></td>
                    <td style="padding:10px 14px;text-align:center;">
                      <div style="display:flex;gap:4px;justify-content:center;">
                        <button class="btn btn-sm btn-secondary" data-cot-id="${esc(cot.id)}" onclick="openCotFreteDetalhe(this.dataset.cotId)" title="Ver detalhes"><i class="fas fa-eye"></i></button>
                        <button class="btn btn-sm btn-secondary" data-cot-id="${esc(cot.id)}" onclick="openCotFreteModal(this.dataset.cotId)" title="Editar"><i class="fas fa-pencil-alt"></i></button>
                        <button class="btn btn-sm" style="background:#fee2e2;color:#dc2626;" data-cot-id="${esc(cot.id)}" data-cot-num="${esc(cot.numero)}" onclick="deleteCotFrete(this.dataset.cotId,this.dataset.cotNum)" title="Excluir"><i class="fas fa-trash"></i></button>
                      </div>
                    </td>
                  </tr>`
                }).join('')
            }
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- ── Modal Cotação de Frete ── -->
<div class="modal-overlay" id="cotFreteModal">
  <div class="modal" style="max-width:800px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:white;z-index:1;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;" id="cotFreteModalTitle"><i class="fas fa-tags" style="color:#e67e22;margin-right:8px;"></i>Nova Cotação de Frete</h3>
      <button onclick="closeModal('cotFreteModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div style="padding:22px;overflow-y:auto;max-height:78vh;">
      <input type="hidden" id="cot_id">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px;">
        <div><label class="form-label">Nº da Cotação *</label><input class="form-control" id="cot_numero" placeholder="COT-2025-001"></div>
        <div><label class="form-label">Vencimento</label><input class="form-control" type="date" id="cot_vencimento"></div>
      </div>

      <!-- Remetente -->
      <div style="font-size:12px;font-weight:700;color:#e67e22;text-transform:uppercase;margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid #fde8cc;">
        <i class="fas fa-map-marker-alt" style="margin-right:6px;"></i>Remetente (Origem)
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:18px;">
        <div style="grid-column:span 2;"><label class="form-label">Nome / Razão Social *</label><input class="form-control" id="cot_rem_nome" placeholder="Nome da empresa remetente"></div>
        <div style="grid-column:span 2;"><label class="form-label">Endereço</label><input class="form-control" id="cot_rem_endereco" placeholder="Rua, Nº, Bairro"></div>
        <div><label class="form-label">Cidade</label><input class="form-control" id="cot_rem_cidade" placeholder="São Paulo"></div>
        <div><label class="form-label">Estado</label>
          <select class="form-control" id="cot_rem_estado">
            ${ESTADOS_BR.map((e: string) => `<option value="${e}"${e==='SP'?' selected':''}>${e}</option>`).join('')}
          </select>
        </div>
        <div><label class="form-label">CEP</label><input class="form-control" id="cot_rem_cep" placeholder="00000-000" maxlength="9"></div>
        <div><label class="form-label">CNPJ / CPF</label><input class="form-control" id="cot_rem_cnpj" placeholder="00.000.000/0001-00"></div>
      </div>

      <!-- Destinatário -->
      <div style="font-size:12px;font-weight:700;color:#2980B9;text-transform:uppercase;margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid #bee3f8;">
        <i class="fas fa-map-pin" style="margin-right:6px;"></i>Destinatário (Destino)
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:18px;">
        <div style="grid-column:span 2;"><label class="form-label">Nome / Razão Social *</label><input class="form-control" id="cot_dest_nome" placeholder="Nome da empresa destinatária"></div>
        <div style="grid-column:span 2;"><label class="form-label">Endereço</label><input class="form-control" id="cot_dest_endereco" placeholder="Rua, Nº, Bairro"></div>
        <div><label class="form-label">Cidade</label><input class="form-control" id="cot_dest_cidade" placeholder="Rio de Janeiro"></div>
        <div><label class="form-label">Estado</label>
          <select class="form-control" id="cot_dest_estado">
            ${ESTADOS_BR.map((e: string) => `<option value="${e}">${e}</option>`).join('')}
          </select>
        </div>
        <div><label class="form-label">CEP</label><input class="form-control" id="cot_dest_cep" placeholder="00000-000" maxlength="9"></div>
        <div><label class="form-label">CNPJ / CPF</label><input class="form-control" id="cot_dest_cnpj" placeholder="00.000.000/0001-00"></div>
      </div>

      <!-- Dados do Frete -->
      <div style="font-size:12px;font-weight:700;color:#7c3aed;text-transform:uppercase;margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid #ede9fe;">
        <i class="fas fa-truck" style="margin-right:6px;"></i>Dados do Frete
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:18px;">
        <div><label class="form-label">Modal *</label>
          <select class="form-control" id="cot_modal">
            <option value="rodoviario">🚛 Rodoviário</option>
            <option value="aereo">✈️ Aéreo</option>
            <option value="maritimo">🚢 Marítimo</option>
            <option value="ferroviario">🚂 Ferroviário</option>
          </select>
        </div>
        <div><label class="form-label">Tipo de Serviço</label>
          <select class="form-control" id="cot_tipo_servico">
            <option value="normal">Normal / Padrão</option>
            <option value="expresso">Expresso</option>
            <option value="dedicado">Carga Dedicada</option>
            <option value="fracionado">Fracionado (LTL)</option>
            <option value="lotacao">Lotação (FTL)</option>
          </select>
        </div>
        <div><label class="form-label">Incoterm</label>
          <select class="form-control" id="cot_incoterm">
            <option value="CIF">CIF — Custo+Seguro+Frete</option>
            <option value="FOB">FOB — A partir da origem</option>
            <option value="DAP">DAP — Entregue no local</option>
            <option value="DDP">DDP — Entregue + impostos</option>
          </select>
        </div>
        <div><label class="form-label">Data de Coleta</label><input class="form-control" type="date" id="cot_data_coleta"></div>
        <div><label class="form-label">Entrega Prevista</label><input class="form-control" type="date" id="cot_data_entrega"></div>
        <div><label class="form-label">Valor da NF (R$)</label><input class="form-control" type="number" step="0.01" id="cot_valor_nf" placeholder="0.00"></div>
      </div>

      <!-- Volumes -->
      <div style="font-size:12px;font-weight:700;color:#7c3aed;text-transform:uppercase;margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid #ede9fe;display:flex;align-items:center;justify-content:space-between;">
        <span><i class="fas fa-boxes" style="margin-right:6px;"></i>Volumes / Cargas</span>
        <button type="button" class="btn btn-secondary" style="font-size:11px;padding:3px 10px;" onclick="addCotVolume()"><i class="fas fa-plus"></i> Add Volume</button>
      </div>
      <div style="background:#f8fafc;border-radius:8px;padding:12px;margin-bottom:18px;">
        <div style="font-size:11px;color:#6c757d;margin-bottom:8px;">Informe as medidas de cada volume para cálculo de frete e cubagem.</div>
        <div style="display:grid;grid-template-columns:repeat(5,1fr) auto;gap:8px;align-items:center;font-size:11px;font-weight:700;color:#374151;margin-bottom:6px;">
          <div>Qtd Volumes</div><div>Comp. (cm)</div><div>Larg. (cm)</div><div>Alt. (cm)</div><div>Peso Unit. (kg)</div><div></div>
        </div>
        <div id="cotVolumesList">
          <div class="cot-vol-row" style="display:grid;grid-template-columns:repeat(5,1fr) auto;gap:8px;align-items:center;margin-bottom:6px;">
            <input type="number" class="form-control" placeholder="1" value="1" min="1" style="font-size:12px;" oninput="calcCotTotais()">
            <input type="number" class="form-control" placeholder="0" step="0.1" min="0" style="font-size:12px;" oninput="calcCotTotais()">
            <input type="number" class="form-control" placeholder="0" step="0.1" min="0" style="font-size:12px;" oninput="calcCotTotais()">
            <input type="number" class="form-control" placeholder="0" step="0.1" min="0" style="font-size:12px;" oninput="calcCotTotais()">
            <input type="number" class="form-control" placeholder="0" step="0.001" min="0" style="font-size:12px;" oninput="calcCotTotais()">
            <button type="button" style="background:none;border:none;color:#9ca3af;cursor:pointer;" onclick="removeCotVolume(this)"><i class="fas fa-times"></i></button>
          </div>
        </div>
        <!-- Totais calculados -->
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:10px;background:white;border-radius:6px;padding:10px;">
          <div><div style="font-size:10px;color:#6c757d;text-transform:uppercase;font-weight:700;">Total Volumes</div><div id="cotTotalVol" style="font-size:16px;font-weight:800;color:#e67e22;">0</div></div>
          <div><div style="font-size:10px;color:#6c757d;text-transform:uppercase;font-weight:700;">Peso Total</div><div id="cotTotalPeso" style="font-size:16px;font-weight:800;color:#2980B9;">0 kg</div></div>
          <div><div style="font-size:10px;color:#6c757d;text-transform:uppercase;font-weight:700;">Volume Total (m³)</div><div id="cotTotalCBM" style="font-size:16px;font-weight:800;color:#7c3aed;">0 m³</div></div>
        </div>
      </div>

      <!-- Transportadoras -->
      <div style="font-size:12px;font-weight:700;color:#7c3aed;text-transform:uppercase;margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid #ede9fe;">
        <i class="fas fa-truck-loading" style="margin-right:6px;"></i>Transportadoras para Cotar
      </div>
      <div id="cotTranspList" style="margin-bottom:8px;"></div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr auto;gap:8px;align-items:end;margin-bottom:18px;">
        <div><label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px;">Nome</label><input class="form-control" id="cotTranspNome" style="font-size:12px;" placeholder="Transportadora ABC"></div>
        <div><label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px;">Contato</label><input class="form-control" id="cotTranspContato" style="font-size:12px;" placeholder="contato@transp.com / WhatsApp"></div>
        <div><label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px;">Valor Cotado (R$)</label><input class="form-control" id="cotTranspValor" type="number" step="0.01" style="font-size:12px;" placeholder="0.00"></div>
        <button type="button" class="btn btn-secondary" style="padding:8px 12px;" onclick="addCotTransp()"><i class="fas fa-plus"></i></button>
      </div>

      <!-- Status e OBS -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div><label class="form-label">Status</label>
          <select class="form-control" id="cot_status">
            <option value="aberta">Aberta</option>
            <option value="aguardando">Aguardando Resposta</option>
            <option value="respondida">Respondida</option>
            <option value="aprovada">Aprovada</option>
            <option value="cancelada">Cancelada</option>
          </select>
        </div>
        <div style="grid-column:span 1;"></div>
        <div style="grid-column:span 2;"><label class="form-label">Observações</label><textarea class="form-control" id="cot_obs" rows="2" placeholder="Observações sobre a carga, restrições, instruções especiais..."></textarea></div>
      </div>
    </div>
    <div style="padding:14px 22px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;position:sticky;bottom:0;background:white;">
      <button class="btn btn-secondary" onclick="closeModal('cotFreteModal')">Cancelar</button>
      <button class="btn btn-primary" onclick="saveCotFrete()"><i class="fas fa-save"></i> Salvar Cotação</button>
    </div>
  </div>
</div>

<!-- ── Modal Detalhe Cotação de Frete ── -->
<div class="modal-overlay" id="cotFreteDetalheModal">
  <div class="modal" style="max-width:760px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:white;z-index:1;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;"><i class="fas fa-tags" style="color:#e67e22;margin-right:8px;"></i>Detalhe da Cotação — <span id="cotDetNumero"></span></h3>
      <button onclick="closeModal('cotFreteDetalheModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div id="cotFreteDetalheContent" style="padding:24px;overflow-y:auto;max-height:78vh;"></div>
  </div>
</div>
<div class="modal-overlay" id="rotaModal">
  <div class="modal" style="max-width:700px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:white;z-index:1;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;" id="rotaModalTitle"><i class="fas fa-route" style="color:#e67e22;margin-right:8px;"></i>Nova Rota</h3>
      <button onclick="closeModal('rotaModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div style="padding:22px;display:grid;grid-template-columns:1fr 1fr;gap:14px;">
      <input type="hidden" id="rota_id">
      <div><label class="form-label">Código da Rota *</label><input class="form-control" id="rota_codigo" placeholder="RT-001"></div>
      <div><label class="form-label">Veículo</label>
        <select class="form-control" id="rota_veiculo">
          <option value="">Sem veículo</option>
          ${htmlOptVeiculos}
        </select>
      </div>
      <div style="grid-column:span 2;"><label class="form-label">Descrição</label><input class="form-control" id="rota_descricao" placeholder="Ex: Rota Sul — Grande SP"></div>
      <div><label class="form-label">Motorista</label><input class="form-control" id="rota_motorista" placeholder="Nome do motorista"></div>
      <div><label class="form-label">Telefone Motorista</label><input class="form-control" id="rota_motorista_tel" placeholder="(11) 99999-9999"></div>
      <div><label class="form-label">Data de Saída Prevista *</label><input class="form-control" type="date" id="rota_data_saida"></div>
      <div><label class="form-label">Data de Retorno Prevista</label><input class="form-control" type="date" id="rota_data_retorno"></div>
      <div><label class="form-label">Origem — Nome</label><input class="form-control" id="rota_origem_nome" placeholder="Matriz" value="Matriz"></div>
      <div><label class="form-label">Origem — Cidade</label><input class="form-control" id="rota_origem_cidade" placeholder="São Paulo"></div>
      <div><label class="form-label">Origem — Estado</label>
        <select class="form-control" id="rota_origem_estado">
          ${htmlOptEstados1}
        </select>
      </div>
      <div><label class="form-label">Distância Estimada (km)</label><input class="form-control" type="number" id="rota_distancia" placeholder="0"></div>
      <div><label class="form-label">Tempo Estimado (min)</label><input class="form-control" type="number" id="rota_tempo" placeholder="0"></div>
      <div><label class="form-label">Prioridade</label>
        <select class="form-control" id="rota_prioridade">
          <option value="baixa">Baixa</option>
          <option value="normal" selected>Normal</option>
          <option value="alta">Alta</option>
          <option value="urgente">Urgente</option>
        </select>
      </div>
      <div><label class="form-label">Status</label>
        <select class="form-control" id="rota_status">
          <option value="planejada" selected>Planejada</option>
          <option value="em_andamento">Em Andamento</option>
          <option value="concluida">Concluída</option>
          <option value="parcial">Parcial</option>
          <option value="cancelada">Cancelada</option>
        </select>
      </div>
      <div style="grid-column:span 2;"><label class="form-label">Observações</label><textarea class="form-control" id="rota_obs" rows="2"></textarea></div>
    </div>
    <div style="padding:14px 22px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
      <button class="btn btn-secondary" onclick="closeModal('rotaModal')">Cancelar</button>
      <button class="btn btn-primary" onclick="saveRota()"><i class="fas fa-save"></i> Salvar Rota</button>
    </div>
  </div>
</div>

<!-- ── Modal Detalhe da Rota (com paradas) ── -->
<div class="modal-overlay" id="rotaDetailModal">
  <div class="modal" style="max-width:750px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:white;z-index:1;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;" id="rotaDetailTitle"><i class="fas fa-route" style="color:#e67e22;margin-right:8px;"></i>Detalhes da Rota</h3>
      <button onclick="closeModal('rotaDetailModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div id="rotaDetailBody" style="padding:22px;"></div>
    <div style="padding:14px 22px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
      <button class="btn btn-secondary" onclick="closeModal('rotaDetailModal')">Fechar</button>
      <button class="btn btn-primary" id="btnAddParada" onclick="openParadaModal()"><i class="fas fa-map-marker-alt"></i> Adicionar Parada</button>
    </div>
  </div>
</div>

<!-- ── Modal Nova Parada ── -->
<div class="modal-overlay" id="paradaModal">
  <div class="modal" style="max-width:640px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:white;z-index:1;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;" id="paradaModalTitle"><i class="fas fa-map-marker-alt" style="color:#e67e22;margin-right:8px;"></i>Nova Parada</h3>
      <button onclick="closeModal('paradaModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div style="padding:22px;display:grid;grid-template-columns:1fr 1fr;gap:14px;">
      <input type="hidden" id="parada_id">
      <input type="hidden" id="parada_rota_id">
      <div><label class="form-label">Ordem *</label><input class="form-control" type="number" id="parada_ordem" value="1" min="1"></div>
      <div style="grid-column:span 1;"><label class="form-label">Nome do Cliente / Destinatário *</label><input class="form-control" id="parada_cliente_nome" placeholder="Empresa XYZ Ltda"></div>
      <div><label class="form-label">CPF / CNPJ</label><input class="form-control" id="parada_documento" placeholder="00.000.000/0001-00"></div>
      <div style="grid-column:span 2;"><label class="form-label">Endereço *</label><input class="form-control" id="parada_endereco" placeholder="Rua das Flores, 123"></div>
      <div><label class="form-label">Número</label><input class="form-control" id="parada_numero" placeholder="123"></div>
      <div><label class="form-label">Bairro</label><input class="form-control" id="parada_bairro" placeholder="Centro"></div>
      <div><label class="form-label">Cidade *</label><input class="form-control" id="parada_cidade" placeholder="São Paulo"></div>
      <div><label class="form-label">Estado *</label>
        <select class="form-control" id="parada_estado">
          ${htmlOptEstados2}
        </select>
      </div>
      <div><label class="form-label">CEP</label><input class="form-control" id="parada_cep" placeholder="00000-000"></div>
      <div><label class="form-label">Nº Pedido / Ref.</label><input class="form-control" id="parada_pedido" placeholder="PV-001"></div>
      <div><label class="form-label">Nº Nota Fiscal</label><input class="form-control" id="parada_nf" placeholder="000001"></div>
      <div><label class="form-label">Volumes</label><input class="form-control" type="number" id="parada_volumes" value="1" min="1"></div>
      <div><label class="form-label">Peso (kg)</label><input class="form-control" type="number" step="0.1" id="parada_peso" value="0"></div>
      <div><label class="form-label">Valor NF (R$)</label><input class="form-control" type="number" step="0.01" id="parada_valor_nf" value="0"></div>
      <div><label class="form-label">Horário Previsto</label><input class="form-control" type="time" id="parada_horario_prev"></div>
      <div><label class="form-label">Janela Início</label><input class="form-control" type="time" id="parada_janela_ini"></div>
      <div><label class="form-label">Janela Fim</label><input class="form-control" type="time" id="parada_janela_fim"></div>
      <div><label class="form-label">Status</label>
        <select class="form-control" id="parada_status">
          <option value="pendente" selected>Pendente</option>
          <option value="em_transito">Em Trânsito</option>
          <option value="entregue">Entregue</option>
          <option value="tentativa">Tentativa</option>
          <option value="reagendado">Reagendado</option>
          <option value="devolvido">Devolvido</option>
          <option value="cancelado">Cancelado</option>
        </select>
      </div>
      <div style="grid-column:span 2;"><label class="form-label">Observações</label><textarea class="form-control" id="parada_obs" rows="2"></textarea></div>
    </div>
    <div style="padding:14px 22px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
      <button class="btn btn-secondary" onclick="closeModal('paradaModal')">Cancelar</button>
      <button class="btn btn-primary" onclick="saveParada()"><i class="fas fa-save"></i> Salvar Parada</button>
    </div>
  </div>
</div>

<!-- ── Modal Atualizar Entrega ── -->
<div class="modal-overlay" id="entregaModal">
  <div class="modal" style="max-width:460px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;"><i class="fas fa-edit" style="color:#2980B9;margin-right:8px;"></i>Atualizar Entrega</h3>
      <button onclick="closeModal('entregaModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div style="padding:22px;display:grid;gap:14px;">
      <input type="hidden" id="ent_id">
      <div id="entregaInfo" style="background:#f8f9fa;padding:12px;border-radius:8px;font-size:13px;"></div>
      <div><label class="form-label">Status da Entrega</label>
        <select class="form-control" id="ent_status">
          <option value="pendente">Pendente</option>
          <option value="em_transito">Em Trânsito</option>
          <option value="entregue">Entregue</option>
          <option value="tentativa">Tentativa de Entrega</option>
          <option value="reagendado">Reagendado</option>
          <option value="devolvido">Devolvido</option>
          <option value="cancelado">Cancelado</option>
        </select>
      </div>
      <div><label class="form-label">Horário Real de Entrega</label><input class="form-control" type="time" id="ent_horario_real"></div>
      <div><label class="form-label">Recebido por (assinatura)</label><input class="form-control" id="ent_assinatura" placeholder="Nome de quem recebeu"></div>
      <div><label class="form-label">Motivo / Ocorrência</label><textarea class="form-control" id="ent_motivo" rows="2" placeholder="Descreva o motivo em caso de problema..."></textarea></div>
    </div>
    <div style="padding:14px 22px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
      <button class="btn btn-secondary" onclick="closeModal('entregaModal')">Cancelar</button>
      <button class="btn btn-primary" onclick="saveEntrega()"><i class="fas fa-save"></i> Atualizar</button>
    </div>
  </div>
</div>

<!-- ── Modal Veículo ── -->
<div class="modal-overlay" id="veiculoModal">
  <div class="modal" style="max-width:580px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:white;z-index:1;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;" id="veiculoModalTitle"><i class="fas fa-truck" style="color:#16a34a;margin-right:8px;"></i>Novo Veículo</h3>
      <button onclick="closeModal('veiculoModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div style="padding:22px;display:grid;grid-template-columns:1fr 1fr;gap:14px;">
      <input type="hidden" id="vei_id">
      <div><label class="form-label">Placa *</label><input class="form-control" id="vei_placa" placeholder="ABC-1234" style="text-transform:uppercase;"></div>
      <div><label class="form-label">Apelido</label><input class="form-control" id="vei_apelido" placeholder="Truck 01"></div>
      <div><label class="form-label">Tipo</label>
        <select class="form-control" id="vei_tipo">
          <option value="truck">Caminhão</option>
          <option value="van">Van</option>
          <option value="utilitario">Utilitário</option>
          <option value="carreta">Carreta</option>
          <option value="pickup">Pickup</option>
          <option value="moto">Moto</option>
        </select>
      </div>
      <div><label class="form-label">Modelo</label><input class="form-control" id="vei_modelo" placeholder="Volkswagen Delivery"></div>
      <div><label class="form-label">Marca</label><input class="form-control" id="vei_marca" placeholder="Volkswagen"></div>
      <div><label class="form-label">Ano</label><input class="form-control" type="number" id="vei_ano" placeholder="2020"></div>
      <div><label class="form-label">Capacidade (kg)</label><input class="form-control" type="number" id="vei_cap_kg" value="0"></div>
      <div><label class="form-label">Capacidade (m³)</label><input class="form-control" type="number" step="0.1" id="vei_cap_vol" value="0"></div>
      <div><label class="form-label">Motorista Padrão</label><input class="form-control" id="vei_motorista" placeholder="Nome do motorista"></div>
      <div><label class="form-label">CNH</label><input class="form-control" id="vei_cnh" placeholder="00000000000"></div>
      <div><label class="form-label">Telefone</label><input class="form-control" id="vei_tel" placeholder="(11) 99999-9999"></div>
      <div><label class="form-label">Status</label>
        <select class="form-control" id="vei_status">
          <option value="disponivel">Disponível</option>
          <option value="em_rota">Em Rota</option>
          <option value="manutencao">Manutenção</option>
          <option value="indisponivel">Indisponível</option>
        </select>
      </div>
      <div><label class="form-label">Cor (identificação)</label><input class="form-control" type="color" id="vei_cor" value="#2980B9" style="height:38px;padding:4px;"></div>
      <div style="grid-column:span 2;"><label class="form-label">Observações</label><textarea class="form-control" id="vei_obs" rows="2"></textarea></div>
    </div>
    <div style="padding:14px 22px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
      <button class="btn btn-secondary" onclick="closeModal('veiculoModal')">Cancelar</button>
      <button class="btn btn-primary" onclick="saveVeiculo()"><i class="fas fa-save"></i> Salvar Veículo</button>
    </div>
  </div>
</div>

<!-- Toast -->
<div id="rotToast" style="position:fixed;bottom:24px;right:24px;z-index:9999;pointer-events:none;"></div>

<!-- Dados serializados em atributos data para evitar conflito com parser HTML -->
<div id="__rot_rotas__" hidden data-json="${safeJson(rotas).replace(/"/g, '&quot;')}"></div>
<div id="__rot_paradas__" hidden data-json="${safeJson(paradas).replace(/"/g, '&quot;')}"></div>
<div id="__rot_veiculos__" hidden data-json="${safeJson(veiculos).replace(/"/g, '&quot;')}"></div>

<script>
const ROT_ROTAS = JSON.parse(document.getElementById('__rot_rotas__').dataset.json || '[]');
const ROT_PARADAS = JSON.parse(document.getElementById('__rot_paradas__').dataset.json || '[]');
const ROT_VEICULOS = JSON.parse(document.getElementById('__rot_veiculos__').dataset.json || '[]');

let _currentRotaId = null;

function showToast(msg, type='success') {
  const c = document.getElementById('rotToast');
  const t = document.createElement('div');
  const col = type==='success'?'#16a34a':type==='info'?'#2980B9':'#dc2626';
  const ico = type==='success'?'fa-check-circle':type==='info'?'fa-info-circle':'fa-exclamation-circle';
  t.style.cssText = 'padding:12px 20px;border-radius:10px;font-size:13px;font-weight:700;color:white;background:'+col+';box-shadow:0 4px 20px rgba(0,0,0,0.2);margin-bottom:8px;display:flex;align-items:center;gap:8px;pointer-events:auto;animation:fadeInUp 0.3s ease;';
  t.innerHTML = '<i class="fas '+ico+'"></i> ' + msg;
  c.appendChild(t);
  setTimeout(()=>t.remove(), 3500);
}
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
function openModal(id) { document.getElementById(id).classList.add('open'); }

// ── Abas ──────────────────────────────────────────────────────────────────────
document.querySelectorAll('.rot-tab').forEach(btn => {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.rot-tab').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.rot-panel').forEach(p => p.classList.remove('active'));
    this.classList.add('active');
    document.getElementById('tab-' + this.dataset.tab).classList.add('active');
  });
});

// ── Filtros ───────────────────────────────────────────────────────────────────
function filterRotas() {
  const s = (document.getElementById('searchRotas').value||'').toLowerCase();
  const st = document.getElementById('filterRotaStatus').value;
  document.querySelectorAll('#rotasTbody .rota-row').forEach(row => {
    const match = (!s || row.dataset.search.includes(s)) && (!st || row.dataset.status === st);
    row.style.display = match ? '' : 'none';
  });
}
function filterEntregas() {
  const rota = document.getElementById('filterEntregaRota').value;
  const st = document.getElementById('filterEntregaStatus').value;
  document.querySelectorAll('#entregasTbody .entrega-row').forEach(row => {
    const match = (!rota || row.dataset.rota === rota) && (!st || row.dataset.status === st);
    row.style.display = match ? '' : 'none';
  });
}

// ── Mapa Brasil ───────────────────────────────────────────────────────────────
function openEstadoDetail(uf) {
  const filtroRotaId = document.getElementById('mapaFiltroRota').value;
  let paradas = ROT_PARADAS.filter(p => p.estado === uf);
  if (filtroRotaId) paradas = paradas.filter(p => p.rota_id === filtroRotaId);

  const statusLabels = { pendente:'Pendente', em_transito:'Em Trânsito', entregue:'Entregue', tentativa:'Tentativa', reagendado:'Reagendado', devolvido:'Devolvido', cancelado:'Cancelado' };
  const statusColors = { pendente:'#6c757d', em_transito:'#2980B9', entregue:'#16a34a', tentativa:'#d97706', reagendado:'#8e44ad', devolvido:'#dc2626', cancelado:'#6c757d' };

  document.getElementById('estadoDetailTitle').textContent = 'Entregas no estado: ' + uf + ' (' + paradas.length + ')';
  if (paradas.length === 0) {
    document.getElementById('estadoDetailContent').innerHTML = '<p style="color:#9ca3af;text-align:center;">Nenhuma entrega neste estado.</p>';
  } else {
    document.getElementById('estadoDetailContent').innerHTML = paradas.map(p => {
      const rota = ROT_ROTAS.find(r => r.id === p.rota_id);
      const col = statusColors[p.status] || '#6c757d';
      const lbl = statusLabels[p.status] || p.status;
      return '<div style="display:flex;gap:10px;padding:8px 0;border-bottom:1px solid #e9ecef;font-size:13px;">' +
        '<div style="width:8px;height:8px;border-radius:50%;background:'+col+';flex-shrink:0;margin-top:5px;"></div>' +
        '<div><b>' + (p.cliente_nome||'—') + '</b> — ' + (p.cidade||'') +
        '<br><span style="color:#6c757d;">Rota: ' + ((rota&&rota.codigo)||'—') + (p.nf_numero?' · NF: '+p.nf_numero:'') + '</span>' +
        '<br><span style="color:'+col+';font-weight:600;">' + lbl + '</span></div></div>';
    }).join('');
  }
  document.getElementById('estadoDetail').style.display = 'block';
}
function renderMapa() {
  // Recarrega a página com filtro (simplificado) — ou podemos fazer client-side
  const rotaId = document.getElementById('mapaFiltroRota').value;
  document.querySelectorAll('.estado-card').forEach(card => {
    const uf = card.dataset.uf;
    let ps = ROT_PARADAS.filter(p => p.estado === uf);
    if (rotaId) ps = ps.filter(p => p.rota_id === rotaId);
    const temEntrega = ps.length > 0;
    const temPendente = ps.some(p => ['pendente','em_transito','tentativa','devolvido'].includes(p.status));
    card.style.borderColor = temEntrega ? (temPendente ? '#d97706' : '#2980B9') : '';
    card.style.background = temEntrega ? (temPendente ? '#fef3c7' : '#e8f4fd') : '';
    const info = card.querySelector('div:nth-child(2)');
    if (info) info.textContent = temEntrega ? ps.length + ' entregas' : 'sem entrega';
  });
}

// ── Rota Modal ────────────────────────────────────────────────────────────────
function openRotaModal(id) {
  const fields = ['rota_id','rota_codigo','rota_descricao','rota_veiculo','rota_motorista','rota_motorista_tel',
    'rota_data_saida','rota_data_retorno','rota_origem_nome','rota_origem_cidade','rota_origem_estado',
    'rota_distancia','rota_tempo','rota_prioridade','rota_status','rota_obs'];
  fields.forEach(f => { const el=document.getElementById(f); if(el) el.value=''; });
  document.getElementById('rota_origem_nome').value = 'Matriz';
  document.getElementById('rota_prioridade').value = 'normal';
  document.getElementById('rota_status').value = 'planejada';
  document.getElementById('rota_data_saida').value = new Date().toISOString().split('T')[0];
  document.getElementById('rota_origem_estado').value = 'SP';
  document.getElementById('rotaModalTitle').innerHTML = '<i class="fas fa-route" style="color:#e67e22;margin-right:8px;"></i>' + (id ? 'Editar Rota' : 'Nova Rota');

  if (id) {
    const r = ROT_ROTAS.find(x => x.id === id);
    if (r) {
      document.getElementById('rota_id').value = r.id||'';
      document.getElementById('rota_codigo').value = r.codigo||'';
      document.getElementById('rota_descricao').value = r.descricao||'';
      document.getElementById('rota_veiculo').value = r.veiculo_id||'';
      document.getElementById('rota_motorista').value = r.motorista_nome||'';
      document.getElementById('rota_motorista_tel').value = r.motorista_tel||'';
      document.getElementById('rota_data_saida').value = r.data_saida_prev||'';
      document.getElementById('rota_data_retorno').value = r.data_retorno_prev||'';
      document.getElementById('rota_origem_nome').value = r.origem_nome||'Matriz';
      document.getElementById('rota_origem_cidade').value = r.origem_cidade||'';
      document.getElementById('rota_origem_estado').value = r.origem_estado||'SP';
      document.getElementById('rota_distancia').value = r.distancia_km||0;
      document.getElementById('rota_tempo').value = r.tempo_est_min||0;
      document.getElementById('rota_prioridade').value = r.prioridade||'normal';
      document.getElementById('rota_status').value = r.status||'planejada';
      document.getElementById('rota_obs').value = r.observacoes||'';
    }
  }
  openModal('rotaModal');
}

async function saveRota() {
  const id = document.getElementById('rota_id').value;
  const codigo = document.getElementById('rota_codigo').value.trim();
  const data = document.getElementById('rota_data_saida').value;
  if (!codigo || !data) { showToast('Preencha Código e Data de Saída.', 'error'); return; }
  const payload = {
    codigo, data_saida_prev: data,
    descricao: document.getElementById('rota_descricao').value,
    veiculo_id: document.getElementById('rota_veiculo').value||null,
    motorista_nome: document.getElementById('rota_motorista').value,
    motorista_tel: document.getElementById('rota_motorista_tel').value,
    data_retorno_prev: document.getElementById('rota_data_retorno').value||null,
    origem_nome: document.getElementById('rota_origem_nome').value||'Matriz',
    origem_cidade: document.getElementById('rota_origem_cidade').value,
    origem_estado: document.getElementById('rota_origem_estado').value,
    distancia_km: parseFloat(document.getElementById('rota_distancia').value)||0,
    tempo_est_min: parseInt(document.getElementById('rota_tempo').value)||0,
    prioridade: document.getElementById('rota_prioridade').value,
    status: document.getElementById('rota_status').value,
    observacoes: document.getElementById('rota_obs').value,
  };
  try {
    const url = id ? '/roteirizacao/api/rotas/' + id : '/roteirizacao/api/rotas';
    const method = id ? 'PUT' : 'POST';
    const res = await fetch(url, {method, headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
    const d = await res.json();
    if (d.ok) { showToast(id ? 'Rota atualizada!' : 'Rota criada!', 'success'); closeModal('rotaModal'); setTimeout(()=>location.reload(), 800); }
    else showToast('Erro: ' + (d.error||'Falha'), 'error');
  } catch { showToast('Erro de conexão.', 'error'); }
}

async function deleteRota(id, cod) {
  if (!confirm('Excluir rota ' + cod + ' e todas as suas paradas?')) return;
  const res = await fetch('/roteirizacao/api/rotas/' + id, {method:'DELETE'});
  const d = await res.json();
  if (d.ok) { showToast('Rota excluída.', 'info'); setTimeout(()=>location.reload(), 600); }
  else showToast('Erro ao excluir.', 'error');
}

// ── Detalhe da Rota + Paradas ─────────────────────────────────────────────────
const PARADA_STATUS_LABELS = {pendente:'Pendente',em_transito:'Em Trânsito',entregue:'Entregue',tentativa:'Tentativa',reagendado:'Reagendado',devolvido:'Devolvido',cancelado:'Cancelado'};
const PARADA_STATUS_COLORS = {pendente:'#6c757d',em_transito:'#2980B9',entregue:'#16a34a',tentativa:'#d97706',reagendado:'#8e44ad',devolvido:'#dc2626',cancelado:'#9ca3af'};
const PARADA_STATUS_BG = {pendente:'#f1f3f5',em_transito:'#e8f4fd',entregue:'#dcfce7',tentativa:'#fef3c7',reagendado:'#f5eef8',devolvido:'#fee2e2',cancelado:'#f1f3f5'};

function openRotaDetail(id) {
  _currentRotaId = id;
  const r = ROT_ROTAS.find(x => x.id === id);
  if (!r) return;
  const paradas = ROT_PARADAS.filter(p => p.rota_id === id).sort((a,b) => (a.ordem||0)-(b.ordem||0));
  const rs = { planejada:{label:'Planejada',color:'#2980B9'}, em_andamento:{label:'Em Andamento',color:'#d97706'}, concluida:{label:'Concluída',color:'#16a34a'}, cancelada:{label:'Cancelada',color:'#dc2626'}, parcial:{label:'Parcial',color:'#8e44ad'} };
  const s = rs[r.status] || rs.planejada;
  const veiculo = ROT_VEICULOS.find(v => v.id === r.veiculo_id);

  let html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;font-size:13px;margin-bottom:18px;">' +
    '<div><b>Status:</b> <span style="color:'+s.color+';font-weight:700;">'+s.label+'</span></div>' +
    '<div><b>Prioridade:</b> ' + (r.prioridade||'normal') + '</div>' +
    '<div><b>Saída:</b> ' + fmtDateClient(r.data_saida_prev) + '</div>' +
    '<div><b>Retorno:</b> ' + fmtDateClient(r.data_retorno_prev) + '</div>' +
    '<div><b>Veículo:</b> ' + (veiculo ? veiculo.placa + (veiculo.apelido?' — '+veiculo.apelido:'') : '—') + '</div>' +
    '<div><b>Motorista:</b> ' + (r.motorista_nome||'—') + '</div>' +
    '<div><b>Origem:</b> ' + (r.origem_nome||'') + ' — ' + (r.origem_cidade||'') + '/' + (r.origem_estado||'') + '</div>' +
    '<div><b>Distância est.:</b> ' + (r.distancia_km ? r.distancia_km+'km' : '—') + '</div>' +
    '</div>';

  html += '<div style="font-weight:700;font-size:14px;color:#1B4F72;margin-bottom:10px;"><i class="fas fa-map-marker-alt" style="color:#e67e22;margin-right:6px;"></i>Paradas (' + paradas.length + ')</div>';

  if (paradas.length === 0) {
    html += '<div style="text-align:center;padding:20px;color:#9ca3af;">Nenhuma parada adicionada. Clique em "Adicionar Parada".</div>';
  } else {
    html += '<div>';
    paradas.forEach((p, i) => {
      const col = PARADA_STATUS_COLORS[p.status]||'#6c757d';
      const bg = PARADA_STATUS_BG[p.status]||'#f1f3f5';
      const lbl = PARADA_STATUS_LABELS[p.status]||p.status;
      html += '<div class="parada-item ' + (p.status||'') + '" style="display:flex;gap:10px;padding:10px 0;border-bottom:1px solid #f1f3f5;">' +
        '<div style="width:28px;height:28px;border-radius:50%;background:'+(p.status==='entregue'?'#16a34a':p.status==='tentativa'?'#d97706':p.status==='devolvido'?'#dc2626':'#e67e22')+';color:white;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0;">' + (p.ordem||i+1) + '</div>' +
        '<div style="flex:1;font-size:13px;">' +
          '<div style="font-weight:700;color:#1B4F72;">' + (p.cliente_nome||'') + '</div>' +
          '<div style="color:#6c757d;">' + (p.endereco||'') + (p.numero?', '+p.numero:'') + ' — ' + (p.cidade||'') + '/' + (p.estado||'') + '</div>' +
          '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:4px;">' +
            (p.nf_numero ? '<span style="font-size:11px;color:#374151;">NF: '+p.nf_numero+'</span>' : '') +
            (p.pedido_ref ? '<span style="font-size:11px;color:#374151;">Ped: '+p.pedido_ref+'</span>' : '') +
            (p.horario_prev ? '<span style="font-size:11px;color:#374151;">Prev: '+p.horario_prev+'</span>' : '') +
          '</div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px;">' +
          '<span style="font-size:11px;padding:2px 8px;border-radius:8px;background:'+bg+';color:'+col+';font-weight:700;">'+lbl+'</span>' +
          '<div style="display:flex;gap:4px;">' +
            '<button class="btn btn-sm btn-secondary" data-id="'+p.id+'" onclick="openEntregaModal(this.dataset.id)" title="Atualizar"><i class="fas fa-edit"></i></button>' +
            '<button class="btn btn-sm" style="background:#fee2e2;color:#dc2626;" data-id="'+p.id+'" onclick="deleteParada(this.dataset.id)" title="Excluir"><i class="fas fa-trash"></i></button>' +
          '</div>' +
        '</div>' +
        '</div>';
    });
    html += '</div>';
  }

  document.getElementById('rotaDetailTitle').innerHTML = '<i class="fas fa-route" style="color:#e67e22;margin-right:8px;"></i>' + r.codigo + ' — ' + (r.descricao||'');
  document.getElementById('rotaDetailBody').innerHTML = html;
  openModal('rotaDetailModal');
}

function fmtDateClient(d) {
  if (!d) return '—';
  try { return new Date(d + 'T12:00:00').toLocaleDateString('pt-BR'); } catch { return d; }
}

// ── Parada Modal ──────────────────────────────────────────────────────────────
function openParadaModal(id) {
  document.getElementById('paradaModalTitle').innerHTML = '<i class="fas fa-map-marker-alt" style="color:#e67e22;margin-right:8px;"></i>' + (id ? 'Editar Parada' : 'Nova Parada');
  ['parada_id','parada_rota_id','parada_cliente_nome','parada_documento','parada_endereco','parada_numero',
   'parada_bairro','parada_cidade','parada_cep','parada_pedido','parada_nf','parada_obs',
   'parada_horario_prev','parada_janela_ini','parada_janela_fim'].forEach(f => {
    const el=document.getElementById(f); if(el) el.value='';
  });
  document.getElementById('parada_ordem').value = ROT_PARADAS.filter(p => p.rota_id === _currentRotaId).length + 1;
  document.getElementById('parada_volumes').value = 1;
  document.getElementById('parada_peso').value = 0;
  document.getElementById('parada_valor_nf').value = 0;
  document.getElementById('parada_estado').value = 'SP';
  document.getElementById('parada_status').value = 'pendente';
  document.getElementById('parada_rota_id').value = _currentRotaId || '';

  if (id) {
    const p = ROT_PARADAS.find(x => x.id === id);
    if (p) {
      document.getElementById('parada_id').value = p.id||'';
      document.getElementById('parada_rota_id').value = p.rota_id||'';
      document.getElementById('parada_ordem').value = p.ordem||1;
      document.getElementById('parada_cliente_nome').value = p.cliente_nome||'';
      document.getElementById('parada_documento').value = p.documento||'';
      document.getElementById('parada_endereco').value = p.endereco||'';
      document.getElementById('parada_numero').value = p.numero||'';
      document.getElementById('parada_bairro').value = p.bairro||'';
      document.getElementById('parada_cidade').value = p.cidade||'';
      document.getElementById('parada_estado').value = p.estado||'SP';
      document.getElementById('parada_cep').value = p.cep||'';
      document.getElementById('parada_pedido').value = p.pedido_ref||'';
      document.getElementById('parada_nf').value = p.nf_numero||'';
      document.getElementById('parada_volumes').value = p.volumes||1;
      document.getElementById('parada_peso').value = p.peso_kg||0;
      document.getElementById('parada_valor_nf').value = p.valor_nf||0;
      document.getElementById('parada_horario_prev').value = p.horario_prev||'';
      document.getElementById('parada_janela_ini').value = p.janela_ini||'';
      document.getElementById('parada_janela_fim').value = p.janela_fim||'';
      document.getElementById('parada_status').value = p.status||'pendente';
      document.getElementById('parada_obs').value = p.observacoes||'';
    }
  }
  openModal('paradaModal');
}

async function saveParada() {
  const nome = document.getElementById('parada_cliente_nome').value.trim();
  const end = document.getElementById('parada_endereco').value.trim();
  const cidade = document.getElementById('parada_cidade').value.trim();
  if (!nome || !end || !cidade) { showToast('Preencha Nome, Endereço e Cidade.', 'error'); return; }
  const id = document.getElementById('parada_id').value;
  const rotaId = document.getElementById('parada_rota_id').value || _currentRotaId;
  const payload = {
    rota_id: rotaId,
    ordem: parseInt(document.getElementById('parada_ordem').value)||1,
    cliente_nome: nome, documento: document.getElementById('parada_documento').value,
    endereco: end, numero: document.getElementById('parada_numero').value,
    bairro: document.getElementById('parada_bairro').value,
    cidade, estado: document.getElementById('parada_estado').value,
    cep: document.getElementById('parada_cep').value,
    pedido_ref: document.getElementById('parada_pedido').value,
    nf_numero: document.getElementById('parada_nf').value,
    volumes: parseInt(document.getElementById('parada_volumes').value)||1,
    peso_kg: parseFloat(document.getElementById('parada_peso').value)||0,
    valor_nf: parseFloat(document.getElementById('parada_valor_nf').value)||0,
    horario_prev: document.getElementById('parada_horario_prev').value||null,
    janela_ini: document.getElementById('parada_janela_ini').value||null,
    janela_fim: document.getElementById('parada_janela_fim').value||null,
    status: document.getElementById('parada_status').value,
    observacoes: document.getElementById('parada_obs').value,
  };
  try {
    const url = id ? '/roteirizacao/api/paradas/' + id : '/roteirizacao/api/paradas';
    const method = id ? 'PUT' : 'POST';
    const res = await fetch(url, {method, headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
    const d = await res.json();
    if (d.ok) { showToast(id ? 'Parada atualizada!' : 'Parada adicionada!', 'success'); closeModal('paradaModal'); setTimeout(()=>location.reload(), 800); }
    else showToast('Erro: ' + (d.error||''), 'error');
  } catch { showToast('Erro de conexão.', 'error'); }
}

async function deleteParada(id) {
  if (!confirm('Excluir esta parada?')) return;
  const res = await fetch('/roteirizacao/api/paradas/' + id, {method:'DELETE'});
  const d = await res.json();
  if (d.ok) { showToast('Parada excluída.', 'info'); setTimeout(()=>location.reload(), 600); }
  else showToast('Erro ao excluir.', 'error');
}

// ── Entrega Modal (atualizar status) ─────────────────────────────────────────
function openEntregaModal(id) {
  const p = ROT_PARADAS.find(x => x.id === id);
  if (!p) return;
  document.getElementById('ent_id').value = p.id||'';
  document.getElementById('ent_status').value = p.status||'pendente';
  document.getElementById('ent_horario_real').value = p.horario_real||'';
  document.getElementById('ent_assinatura').value = p.assinatura_nome||'';
  document.getElementById('ent_motivo').value = p.motivo_ocorrencia||'';
  const rota = ROT_ROTAS.find(r => r.id === p.rota_id);
  document.getElementById('entregaInfo').innerHTML =
    '<b>' + (p.cliente_nome||'') + '</b> — ' + (p.cidade||'') + '/' + (p.estado||'') +
    '<br><span style="color:#6c757d;">Rota: ' + (rota ? rota.codigo : '—') + (p.nf_numero ? ' · NF: '+p.nf_numero : '') + '</span>';
  openModal('entregaModal');
}

async function saveEntrega() {
  const id = document.getElementById('ent_id').value;
  if (!id) return;
  const payload = {
    status: document.getElementById('ent_status').value,
    horario_real: document.getElementById('ent_horario_real').value||null,
    assinatura_nome: document.getElementById('ent_assinatura').value,
    motivo_ocorrencia: document.getElementById('ent_motivo').value,
  };
  try {
    const res = await fetch('/roteirizacao/api/paradas/' + id, {method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
    const d = await res.json();
    if (d.ok) { showToast('Entrega atualizada!', 'success'); closeModal('entregaModal'); setTimeout(()=>location.reload(), 800); }
    else showToast('Erro: ' + (d.error||''), 'error');
  } catch { showToast('Erro de conexão.', 'error'); }
}

// ── Veículo Modal ─────────────────────────────────────────────────────────────
function openVeiculoModal(id) {
  document.getElementById('veiculoModalTitle').innerHTML = '<i class="fas fa-truck" style="color:#16a34a;margin-right:8px;"></i>' + (id ? 'Editar Veículo' : 'Novo Veículo');
  ['vei_id','vei_placa','vei_apelido','vei_modelo','vei_marca','vei_cnh','vei_motorista','vei_tel','vei_obs'].forEach(f => {
    const el=document.getElementById(f); if(el) el.value='';
  });
  document.getElementById('vei_tipo').value = 'truck';
  document.getElementById('vei_status').value = 'disponivel';
  document.getElementById('vei_cor').value = '#2980B9';
  document.getElementById('vei_cap_kg').value = 0;
  document.getElementById('vei_cap_vol').value = 0;
  document.getElementById('vei_ano').value = '';

  if (id) {
    const v = ROT_VEICULOS.find(x => x.id === id);
    if (v) {
      document.getElementById('vei_id').value = v.id||'';
      document.getElementById('vei_placa').value = v.placa||'';
      document.getElementById('vei_apelido').value = v.apelido||'';
      document.getElementById('vei_tipo').value = v.tipo||'truck';
      document.getElementById('vei_modelo').value = v.modelo||'';
      document.getElementById('vei_marca').value = v.marca||'';
      document.getElementById('vei_ano').value = v.ano||'';
      document.getElementById('vei_cap_kg').value = v.capacidade_kg||0;
      document.getElementById('vei_cap_vol').value = v.capacidade_vol||0;
      document.getElementById('vei_motorista').value = v.motorista_nome||'';
      document.getElementById('vei_cnh').value = v.motorista_cnh||'';
      document.getElementById('vei_tel').value = v.motorista_tel||'';
      document.getElementById('vei_status').value = v.status||'disponivel';
      document.getElementById('vei_cor').value = v.cor||'#2980B9';
      document.getElementById('vei_obs').value = v.observacoes||'';
    }
  }
  openModal('veiculoModal');
}

async function saveVeiculo() {
  const placa = document.getElementById('vei_placa').value.trim().toUpperCase();
  if (!placa) { showToast('Informe a placa do veículo.', 'error'); return; }
  const id = document.getElementById('vei_id').value;
  const payload = {
    placa, apelido: document.getElementById('vei_apelido').value,
    tipo: document.getElementById('vei_tipo').value,
    modelo: document.getElementById('vei_modelo').value,
    marca: document.getElementById('vei_marca').value,
    ano: parseInt(document.getElementById('vei_ano').value)||null,
    capacidade_kg: parseFloat(document.getElementById('vei_cap_kg').value)||0,
    capacidade_vol: parseFloat(document.getElementById('vei_cap_vol').value)||0,
    motorista_nome: document.getElementById('vei_motorista').value,
    motorista_cnh: document.getElementById('vei_cnh').value,
    motorista_tel: document.getElementById('vei_tel').value,
    status: document.getElementById('vei_status').value,
    cor: document.getElementById('vei_cor').value,
    observacoes: document.getElementById('vei_obs').value,
  };
  try {
    const url = id ? '/roteirizacao/api/veiculos/' + id : '/roteirizacao/api/veiculos';
    const method = id ? 'PUT' : 'POST';
    const res = await fetch(url, {method, headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
    const d = await res.json();
    if (d.ok) { showToast(id ? 'Veículo atualizado!' : 'Veículo cadastrado!', 'success'); closeModal('veiculoModal'); setTimeout(()=>location.reload(), 800); }
    else showToast('Erro: ' + (d.error||''), 'error');
  } catch { showToast('Erro de conexão.', 'error'); }
}

async function deleteVeiculo(id, placa) {
  if (!confirm('Excluir veículo ' + placa + '?')) return;
  const res = await fetch('/roteirizacao/api/veiculos/' + id, {method:'DELETE'});
  const d = await res.json();
  if (d.ok) { showToast('Veículo excluído.', 'info'); setTimeout(()=>location.reload(), 600); }
  else showToast('Erro ao excluir.', 'error');
}

// Fechar modais ao clicar fora
document.querySelectorAll('.modal-overlay').forEach(el => {
  el.addEventListener('click', function(e) {
    if (e.target === this) this.classList.remove('open');
  });
});

// ── Cotação de Frete ──────────────────────────────────────────────────────────
const ROT_COTACOES = ${safeJson(cotacoesFrete)};

function filterCotacoes() {
  var s = document.getElementById('searchCotacoes').value.toLowerCase();
  var st = document.getElementById('filterCotStatus').value;
  document.querySelectorAll('#cotacoesTbody .cot-row').forEach(function(row) {
    var match = (!s || row.dataset.search.includes(s)) && (!st || row.dataset.status === st);
    row.style.display = match ? '' : 'none';
  });
}

var _cotTranspList = [];
var _cotVolsList = [];

function openCotFreteModal(id) {
  _cotTranspList = [];
  document.getElementById('cot_id').value = '';
  ['cot_numero','cot_vencimento','cot_rem_nome','cot_rem_endereco','cot_rem_cidade','cot_rem_cep','cot_rem_cnpj',
   'cot_dest_nome','cot_dest_endereco','cot_dest_cidade','cot_dest_cep','cot_dest_cnpj',
   'cot_data_coleta','cot_data_entrega','cot_valor_nf','cot_obs'].forEach(function(f) {
    var el = document.getElementById(f); if (el) el.value = '';
  });
  document.getElementById('cot_modal').value = 'rodoviario';
  document.getElementById('cot_tipo_servico').value = 'normal';
  document.getElementById('cot_incoterm').value = 'CIF';
  document.getElementById('cot_status').value = 'aberta';
  document.getElementById('cot_rem_estado').value = 'SP';
  document.getElementById('cotFreteModalTitle').innerHTML = '<i class="fas fa-tags" style="color:#e67e22;margin-right:8px;"></i>Nova Cotação de Frete';
  // Resetar volumes
  document.getElementById('cotVolumesList').innerHTML = '<div class="cot-vol-row" style="display:grid;grid-template-columns:repeat(5,1fr) auto;gap:8px;align-items:center;margin-bottom:6px;">' +
    '<input type="number" class="form-control" placeholder="1" value="1" min="1" style="font-size:12px;" oninput="calcCotTotais()">' +
    '<input type="number" class="form-control" placeholder="0" step="0.1" min="0" style="font-size:12px;" oninput="calcCotTotais()">' +
    '<input type="number" class="form-control" placeholder="0" step="0.1" min="0" style="font-size:12px;" oninput="calcCotTotais()">' +
    '<input type="number" class="form-control" placeholder="0" step="0.1" min="0" style="font-size:12px;" oninput="calcCotTotais()">' +
    '<input type="number" class="form-control" placeholder="0" step="0.001" min="0" style="font-size:12px;" oninput="calcCotTotais()">' +
    '<button type="button" style="background:none;border:none;color:#9ca3af;cursor:pointer;" onclick="removeCotVolume(this)"><i class="fas fa-times"></i></button>' +
    '</div>';
  renderCotTransp();
  calcCotTotais();

  if (id) {
    var cot = ROT_COTACOES.find(function(c) { return c.id === id; });
    if (cot) {
      document.getElementById('cot_id').value = cot.id || '';
      document.getElementById('cot_numero').value = cot.numero || '';
      document.getElementById('cot_vencimento').value = cot.vencimento || '';
      document.getElementById('cot_rem_nome').value = cot.remetente_nome || '';
      document.getElementById('cot_rem_endereco').value = cot.remetente_endereco || '';
      document.getElementById('cot_rem_cidade').value = cot.remetente_cidade || '';
      document.getElementById('cot_rem_estado').value = cot.remetente_estado || 'SP';
      document.getElementById('cot_rem_cep').value = cot.remetente_cep || '';
      document.getElementById('cot_rem_cnpj').value = cot.remetente_cnpj || '';
      document.getElementById('cot_dest_nome').value = cot.destinatario_nome || '';
      document.getElementById('cot_dest_endereco').value = cot.destinatario_endereco || '';
      document.getElementById('cot_dest_cidade').value = cot.destinatario_cidade || '';
      document.getElementById('cot_dest_estado').value = cot.destinatario_estado || '';
      document.getElementById('cot_dest_cep').value = cot.destinatario_cep || '';
      document.getElementById('cot_dest_cnpj').value = cot.destinatario_cnpj || '';
      document.getElementById('cot_modal').value = cot.modal || 'rodoviario';
      document.getElementById('cot_tipo_servico').value = cot.tipo_servico || 'normal';
      document.getElementById('cot_incoterm').value = cot.incoterm || 'CIF';
      document.getElementById('cot_data_coleta').value = cot.data_coleta || '';
      document.getElementById('cot_data_entrega').value = cot.data_entrega_prev || '';
      document.getElementById('cot_valor_nf').value = cot.valor_nf || '';
      document.getElementById('cot_obs').value = cot.obs || '';
      document.getElementById('cot_status').value = cot.status || 'aberta';
      // Volumes
      try {
        var vols = JSON.parse(cot.volumes_detalhe || '[]');
        if (vols.length > 0) {
          var list = document.getElementById('cotVolumesList');
          list.innerHTML = '';
          vols.forEach(function(v) { list.innerHTML += buildVolRow(v.qtd||1, v.comp||0, v.larg||0, v.alt||0, v.peso||0); });
          calcCotTotais();
        }
      } catch {}
      // Transportadoras
      try { _cotTranspList = JSON.parse(cot.transportadoras || '[]'); } catch { _cotTranspList = []; }
      renderCotTransp();
      document.getElementById('cotFreteModalTitle').innerHTML = '<i class="fas fa-tags" style="color:#e67e22;margin-right:8px;"></i>Editar Cotação';
    }
  }
  openModal('cotFreteModal');
}

function buildVolRow(qtd, comp, larg, alt, peso) {
  return '<div class="cot-vol-row" style="display:grid;grid-template-columns:repeat(5,1fr) auto;gap:8px;align-items:center;margin-bottom:6px;">' +
    '<input type="number" class="form-control" placeholder="1" value="' + (qtd||1) + '" min="1" style="font-size:12px;" oninput="calcCotTotais()">' +
    '<input type="number" class="form-control" placeholder="0" step="0.1" min="0" value="' + (comp||0) + '" style="font-size:12px;" oninput="calcCotTotais()">' +
    '<input type="number" class="form-control" placeholder="0" step="0.1" min="0" value="' + (larg||0) + '" style="font-size:12px;" oninput="calcCotTotais()">' +
    '<input type="number" class="form-control" placeholder="0" step="0.1" min="0" value="' + (alt||0) + '" style="font-size:12px;" oninput="calcCotTotais()">' +
    '<input type="number" class="form-control" placeholder="0" step="0.001" min="0" value="' + (peso||0) + '" style="font-size:12px;" oninput="calcCotTotais()">' +
    '<button type="button" style="background:none;border:none;color:#9ca3af;cursor:pointer;" onclick="removeCotVolume(this)"><i class="fas fa-times"></i></button>' +
    '</div>';
}

function addCotVolume() {
  document.getElementById('cotVolumesList').innerHTML += buildVolRow(1,0,0,0,0);
  calcCotTotais();
}
function removeCotVolume(btn) {
  var row = btn.closest('.cot-vol-row');
  if (row) row.remove();
  calcCotTotais();
}

function calcCotTotais() {
  var rows = document.querySelectorAll('.cot-vol-row');
  var totalVol = 0, totalPeso = 0, totalCBM = 0;
  rows.forEach(function(row) {
    var inputs = row.querySelectorAll('input');
    var qtd = parseFloat(inputs[0].value)||0;
    var comp = parseFloat(inputs[1].value)||0;
    var larg = parseFloat(inputs[2].value)||0;
    var alt = parseFloat(inputs[3].value)||0;
    var peso = parseFloat(inputs[4].value)||0;
    totalVol += qtd;
    totalPeso += qtd * peso;
    totalCBM += qtd * (comp * larg * alt / 1000000);
  });
  document.getElementById('cotTotalVol').textContent = totalVol;
  document.getElementById('cotTotalPeso').textContent = totalPeso.toFixed(3) + ' kg';
  document.getElementById('cotTotalCBM').textContent = totalCBM.toFixed(4) + ' m³';
}

function addCotTransp() {
  var nome = document.getElementById('cotTranspNome').value.trim();
  if (!nome) { showToast('Informe o nome da transportadora.', 'error'); return; }
  var contato = document.getElementById('cotTranspContato').value.trim();
  var valor = parseFloat(document.getElementById('cotTranspValor').value)||0;
  _cotTranspList.push({ nome, contato, valor, status: 'pendente' });
  document.getElementById('cotTranspNome').value = '';
  document.getElementById('cotTranspContato').value = '';
  document.getElementById('cotTranspValor').value = '';
  renderCotTransp();
}

function removeCotTransp(idx) { _cotTranspList.splice(idx,1); renderCotTransp(); }

function renderCotTransp() {
  var el = document.getElementById('cotTranspList');
  if (_cotTranspList.length === 0) { el.innerHTML = '<div style="color:#9ca3af;font-size:12px;padding:8px 0;">Nenhuma transportadora adicionada.</div>'; return; }
  el.innerHTML = _cotTranspList.map(function(t,i) {
    return '<div style="display:flex;align-items:center;gap:10px;padding:8px 10px;background:white;border-radius:6px;margin-bottom:6px;border:1px solid #e9ecef;">' +
      '<i class="fas fa-truck" style="color:#e67e22;"></i>' +
      '<div style="flex:1;"><strong style="font-size:13px;">' + t.nome + '</strong>' +
      (t.contato ? '<span style="color:#6c757d;font-size:11px;margin-left:8px;">' + t.contato + '</span>' : '') +
      (t.valor > 0 ? '<span style="font-size:12px;color:#16a34a;font-weight:700;margin-left:8px;">R$ ' + t.valor.toFixed(2) + '</span>' : '') +
      '</div>' +
      '<button type="button" style="background:none;border:none;color:#dc2626;cursor:pointer;" onclick="removeCotTransp(' + i + ')"><i class="fas fa-times"></i></button>' +
    '</div>';
  }).join('');
}

function _collectCotVolumes() {
  var rows = document.querySelectorAll('.cot-vol-row');
  var vols = [];
  rows.forEach(function(row) {
    var inputs = row.querySelectorAll('input');
    vols.push({ qtd: parseFloat(inputs[0].value)||0, comp: parseFloat(inputs[1].value)||0, larg: parseFloat(inputs[2].value)||0, alt: parseFloat(inputs[3].value)||0, peso: parseFloat(inputs[4].value)||0 });
  });
  return vols;
}

async function saveCotFrete() {
  var num = document.getElementById('cot_numero').value.trim();
  var remNome = document.getElementById('cot_rem_nome').value.trim();
  var destNome = document.getElementById('cot_dest_nome').value.trim();
  if (!num) { showToast('Informe o número da cotação.', 'error'); return; }
  if (!remNome) { showToast('Informe o remetente.', 'error'); return; }
  if (!destNome) { showToast('Informe o destinatário.', 'error'); return; }
  var vols = _collectCotVolumes();
  var totalVol = vols.reduce(function(s,v) { return s+v.qtd; }, 0);
  var totalPeso = vols.reduce(function(s,v) { return s+(v.qtd*v.peso); }, 0);
  var payload = {
    numero: num,
    remetente_nome: remNome,
    remetente_endereco: document.getElementById('cot_rem_endereco').value,
    remetente_cidade: document.getElementById('cot_rem_cidade').value,
    remetente_estado: document.getElementById('cot_rem_estado').value,
    remetente_cep: document.getElementById('cot_rem_cep').value,
    remetente_cnpj: document.getElementById('cot_rem_cnpj').value,
    destinatario_nome: destNome,
    destinatario_endereco: document.getElementById('cot_dest_endereco').value,
    destinatario_cidade: document.getElementById('cot_dest_cidade').value,
    destinatario_estado: document.getElementById('cot_dest_estado').value,
    destinatario_cep: document.getElementById('cot_dest_cep').value,
    destinatario_cnpj: document.getElementById('cot_dest_cnpj').value,
    modal: document.getElementById('cot_modal').value,
    tipo_servico: document.getElementById('cot_tipo_servico').value,
    incoterm: document.getElementById('cot_incoterm').value,
    total_volumes: totalVol,
    peso_total_kg: totalPeso,
    valor_nf: parseFloat(document.getElementById('cot_valor_nf').value)||0,
    volumes_detalhe: JSON.stringify(vols),
    data_coleta: document.getElementById('cot_data_coleta').value||null,
    data_entrega_prev: document.getElementById('cot_data_entrega').value||null,
    obs: document.getElementById('cot_obs').value,
    transportadoras: JSON.stringify(_cotTranspList),
    status: document.getElementById('cot_status').value,
    vencimento: document.getElementById('cot_vencimento').value||null,
  };
  var id = document.getElementById('cot_id').value;
  try {
    var url = id ? '/roteirizacao/api/cotacoes-frete/' + id : '/roteirizacao/api/cotacoes-frete';
    var method = id ? 'PUT' : 'POST';
    var res = await fetch(url, { method, headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    var d = await res.json();
    if (d.ok) { showToast(id ? 'Cotação atualizada!' : 'Cotação criada!', 'success'); closeModal('cotFreteModal'); setTimeout(()=>location.reload(), 800); }
    else showToast('Erro: ' + (d.error||''), 'error');
  } catch { showToast('Erro de conexão.', 'error'); }
}

async function deleteCotFrete(id, num) {
  if (!confirm('Excluir a cotação "' + num + '"?')) return;
  try {
    var res = await fetch('/roteirizacao/api/cotacoes-frete/' + id, {method:'DELETE'});
    var d = await res.json();
    if (d.ok) { showToast('Cotação excluída.', 'info'); setTimeout(()=>location.reload(), 600); }
    else showToast('Erro: ' + (d.error||''), 'error');
  } catch { showToast('Erro de conexão.', 'error'); }
}

function openCotFreteDetalhe(id) {
  var cot = ROT_COTACOES.find(function(c) { return c.id === id; });
  if (!cot) return;
  document.getElementById('cotDetNumero').textContent = cot.numero || '';
  var transp = [];
  try { transp = JSON.parse(cot.transportadoras || '[]'); } catch {}
  var vols = [];
  try { vols = JSON.parse(cot.volumes_detalhe || '[]'); } catch {}
  var totalVol = vols.reduce(function(s,v){return s+v.qtd;},0);
  var totalPeso = vols.reduce(function(s,v){return s+(v.qtd*v.peso);},0);
  var totalCBM = vols.reduce(function(s,v){return s+(v.qtd*v.comp*v.larg*v.alt/1000000);},0);
  var melhorTransp = transp.filter(function(t){return t.valor>0;}).sort(function(a,b){return a.valor-b.valor;})[0];
  var html = '<div style="font-size:13px;">' +
    // Resumo remetente/destinatário
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;">' +
      '<div style="background:#fff7ed;border-radius:8px;padding:14px;border-left:4px solid #e67e22;">' +
        '<div style="font-size:11px;font-weight:700;color:#9a3412;text-transform:uppercase;margin-bottom:6px;">Remetente</div>' +
        '<div style="font-weight:700;color:#1B4F72;">' + (cot.remetente_nome||'—') + '</div>' +
        '<div style="color:#374151;">' + (cot.remetente_endereco||'') + '</div>' +
        '<div style="color:#374151;">' + (cot.remetente_cidade||'') + (cot.remetente_estado ? ' / '+cot.remetente_estado : '') + (cot.remetente_cep ? ' — '+cot.remetente_cep : '') + '</div>' +
        (cot.remetente_cnpj ? '<div style="font-size:11px;color:#6c757d;">CNPJ: '+cot.remetente_cnpj+'</div>' : '') +
      '</div>' +
      '<div style="background:#eff6ff;border-radius:8px;padding:14px;border-left:4px solid #2980B9;">' +
        '<div style="font-size:11px;font-weight:700;color:#1e40af;text-transform:uppercase;margin-bottom:6px;">Destinatário</div>' +
        '<div style="font-weight:700;color:#1B4F72;">' + (cot.destinatario_nome||'—') + '</div>' +
        '<div style="color:#374151;">' + (cot.destinatario_endereco||'') + '</div>' +
        '<div style="color:#374151;">' + (cot.destinatario_cidade||'') + (cot.destinatario_estado ? ' / '+cot.destinatario_estado : '') + (cot.destinatario_cep ? ' — '+cot.destinatario_cep : '') + '</div>' +
        (cot.destinatario_cnpj ? '<div style="font-size:11px;color:#6c757d;">CNPJ: '+cot.destinatario_cnpj+'</div>' : '') +
      '</div>' +
    '</div>' +
    // Info frete
    '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;background:#f8f9fa;border-radius:8px;padding:12px;margin-bottom:16px;">' +
      '<div><div style="font-size:10px;color:#6c757d;font-weight:700;text-transform:uppercase;">Modal</div><div style="font-weight:700;text-transform:capitalize;">' + (cot.modal||'—') + '</div></div>' +
      '<div><div style="font-size:10px;color:#6c757d;font-weight:700;text-transform:uppercase;">Serviço</div><div style="text-transform:capitalize;">' + (cot.tipo_servico||'—') + '</div></div>' +
      '<div><div style="font-size:10px;color:#6c757d;font-weight:700;text-transform:uppercase;">Incoterm</div><div style="font-weight:700;">' + (cot.incoterm||'—') + '</div></div>' +
      '<div><div style="font-size:10px;color:#6c757d;font-weight:700;text-transform:uppercase;">Coleta</div><div>' + (cot.data_coleta||'—') + '</div></div>' +
    '</div>' +
    // Totais de volume
    '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px;">' +
      '<div style="background:#fff7ed;border-radius:8px;padding:10px;text-align:center;"><div style="font-size:22px;font-weight:800;color:#e67e22;">' + totalVol + '</div><div style="font-size:11px;color:#6c757d;">Total de Volumes</div></div>' +
      '<div style="background:#eff6ff;border-radius:8px;padding:10px;text-align:center;"><div style="font-size:22px;font-weight:800;color:#2980B9;">' + totalPeso.toFixed(3) + ' kg</div><div style="font-size:11px;color:#6c757d;">Peso Total</div></div>' +
      '<div style="background:#f5f3ff;border-radius:8px;padding:10px;text-align:center;"><div style="font-size:22px;font-weight:800;color:#7c3aed;">' + totalCBM.toFixed(4) + ' m³</div><div style="font-size:11px;color:#6c757d;">Volume Total (CBM)</div></div>' +
    '</div>' +
    // Volumes individuais
    (vols.length > 0 ? '<div style="margin-bottom:16px;">' +
      '<div style="font-size:12px;font-weight:700;color:#374151;margin-bottom:8px;">Detalhamento dos Volumes</div>' +
      '<table style="width:100%;border-collapse:collapse;font-size:12px;">' +
        '<thead><tr style="background:#1B4F72;color:white;"><th style="padding:7px 10px;">Qtd</th><th style="padding:7px 10px;">Comp (cm)</th><th style="padding:7px 10px;">Larg (cm)</th><th style="padding:7px 10px;">Alt (cm)</th><th style="padding:7px 10px;">Peso/un (kg)</th><th style="padding:7px 10px;">CBM total</th></tr></thead>' +
        '<tbody>' + vols.map(function(v) {
          var cbm = v.qtd * v.comp * v.larg * v.alt / 1000000;
          return '<tr style="border-bottom:1px solid #f1f3f5;"><td style="padding:6px 10px;text-align:center;font-weight:700;">' + v.qtd + '</td><td style="padding:6px 10px;text-align:center;">' + v.comp + '</td><td style="padding:6px 10px;text-align:center;">' + v.larg + '</td><td style="padding:6px 10px;text-align:center;">' + v.alt + '</td><td style="padding:6px 10px;text-align:center;">' + v.peso + '</td><td style="padding:6px 10px;text-align:center;font-weight:700;">' + cbm.toFixed(4) + ' m³</td></tr>';
        }).join('') + '</tbody></table></div>' : '') +
    // Transportadoras
    (transp.length > 0 ? '<div>' +
      '<div style="font-size:12px;font-weight:700;color:#374151;margin-bottom:8px;">Transportadoras</div>' +
      '<table style="width:100%;border-collapse:collapse;font-size:12px;">' +
        '<thead><tr style="background:#f8f9fa;"><th style="padding:7px 10px;text-align:left;">Nome</th><th style="padding:7px 10px;text-align:left;">Contato</th><th style="padding:7px 10px;text-align:right;">Valor R$</th><th style="padding:7px 10px;text-align:center;">Status</th></tr></thead>' +
        '<tbody>' + transp.map(function(t) {
          var isMin = melhorTransp && t.nome === melhorTransp.nome && t.valor > 0;
          return '<tr style="border-bottom:1px solid #f1f3f5;' + (isMin?'background:#f0fdf4;':'') + '">' +
            '<td style="padding:7px 10px;font-weight:600;">' + t.nome + (isMin?'<span style="font-size:10px;color:#16a34a;margin-left:6px;font-weight:700;">✓ MENOR PREÇO</span>':'') + '</td>' +
            '<td style="padding:7px 10px;color:#6c757d;">' + (t.contato||'—') + '</td>' +
            '<td style="padding:7px 10px;text-align:right;font-weight:700;color:' + (t.valor>0?'#16a34a':'#9ca3af') + ';">' + (t.valor>0 ? 'R$ '+t.valor.toFixed(2) : '—') + '</td>' +
            '<td style="padding:7px 10px;text-align:center;font-size:11px;color:#6c757d;">' + (t.status||'pendente') + '</td>' +
          '</tr>';
        }).join('') + '</tbody></table></div>' : '') +
  '</div>';
  document.getElementById('cotFreteDetalheContent').innerHTML = html;
  openModal('cotFreteDetalheModal');
}
</script>`

  return c.html(layout('Roteirização', content, 'roteirizacao', userInfo))
})

// ── APIs Veículos ─────────────────────────────────────────────────────────────
app.post('/api/veiculos', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const body = await c.req.json() as any
  if (!body.placa) return c.json(err('Placa obrigatória'), 400)
  await ensureTables(db)
  const now = new Date().toISOString()
  const id = genId('rotvei')
  try { await dbInsert(db, 'rot_veiculos', {
    id, user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
    placa: body.placa.toUpperCase(), apelido: body.apelido || null,
    tipo: body.tipo || 'truck', modelo: body.modelo || null, marca: body.marca || null,
    ano: body.ano || null, capacidade_kg: body.capacidade_kg || 0,
    capacidade_vol: body.capacidade_vol || 0, capacidade_pal: body.capacidade_pal || 0,
    motorista_nome: body.motorista_nome || null, motorista_cnh: body.motorista_cnh || null,
    motorista_tel: body.motorista_tel || null, status: body.status || 'disponivel',
    cor: body.cor || '#2980B9', observacoes: body.observacoes || null,
    created_at: now, updated_at: now,
  }) } catch(e: any) { return c.json(err('Erro ao inserir veículo: ' + (e?.message||e)), 500) }
  return c.json(ok({ id }))
})

app.put('/api/veiculos/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const id = c.req.param('id')
  const body = await c.req.json() as any
  await ensureTables(db)
  try { await dbUpdate(db, 'rot_veiculos', id, userId, {
    placa: body.placa?.toUpperCase(), apelido: body.apelido, tipo: body.tipo,
    modelo: body.modelo, marca: body.marca, ano: body.ano,
    capacidade_kg: body.capacidade_kg, capacidade_vol: body.capacidade_vol,
    motorista_nome: body.motorista_nome, motorista_cnh: body.motorista_cnh,
    motorista_tel: body.motorista_tel, status: body.status, cor: body.cor,
    observacoes: body.observacoes, updated_at: new Date().toISOString(),
  }) } catch(e: any) { return c.json(err('Erro: ' + (e?.message||e)), 500) }
  return c.json(ok({}))
})

app.delete('/api/veiculos/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  await ensureTables(db)
  try { await dbDelete(db, 'rot_veiculos', c.req.param('id'), userId) } catch(e: any) { return c.json(err('Erro: ' + (e?.message||e)), 500) }
  return c.json(ok({}))
})

// ── APIs Rotas ────────────────────────────────────────────────────────────────
app.post('/api/rotas', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const body = await c.req.json() as any
  if (!body.codigo || !body.data_saida_prev) return c.json(err('Código e data de saída obrigatórios'), 400)
  await ensureTables(db)
  const now = new Date().toISOString()
  const id = genId('rotrota')
  try { await dbInsert(db, 'rot_rotas', {
    id, user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
    codigo: body.codigo, descricao: body.descricao || null,
    veiculo_id: body.veiculo_id || null,
    motorista_nome: body.motorista_nome || null, motorista_tel: body.motorista_tel || null,
    data_saida_prev: body.data_saida_prev, data_saida_real: body.data_saida_real || null,
    data_retorno_prev: body.data_retorno_prev || null, data_retorno_real: null,
    origem_nome: body.origem_nome || 'Matriz', origem_endereco: body.origem_endereco || null,
    origem_cidade: body.origem_cidade || null, origem_estado: body.origem_estado || 'SP',
    origem_lat: body.origem_lat || -23.5505, origem_lon: body.origem_lon || -46.6333,
    total_paradas: 0, total_entregas: 0, total_peso_kg: 0,
    distancia_km: body.distancia_km || 0, tempo_est_min: body.tempo_est_min || 0,
    status: body.status || 'planejada', prioridade: body.prioridade || 'normal',
    observacoes: body.observacoes || null, created_at: now, updated_at: now,
  }) } catch(e: any) { return c.json(err('Erro ao inserir rota: ' + (e?.message||e)), 500) }
  return c.json(ok({ id }))
})

app.put('/api/rotas/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const id = c.req.param('id')
  const body = await c.req.json() as any
  await ensureTables(db)
  try { await dbUpdate(db, 'rot_rotas', id, userId, {
    codigo: body.codigo, descricao: body.descricao,
    veiculo_id: body.veiculo_id, motorista_nome: body.motorista_nome,
    motorista_tel: body.motorista_tel, data_saida_prev: body.data_saida_prev,
    data_saida_real: body.data_saida_real, data_retorno_prev: body.data_retorno_prev,
    data_retorno_real: body.data_retorno_real,
    origem_nome: body.origem_nome, origem_cidade: body.origem_cidade,
    origem_estado: body.origem_estado, distancia_km: body.distancia_km,
    tempo_est_min: body.tempo_est_min, status: body.status,
    prioridade: body.prioridade, observacoes: body.observacoes,
    updated_at: new Date().toISOString(),
  }) } catch(e: any) { return c.json(err('Erro ao atualizar rota: ' + (e?.message||e)), 500) }
  return c.json(ok({}))
})

app.delete('/api/rotas/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  await ensureTables(db)
  try { await db.prepare('DELETE FROM rot_paradas WHERE rota_id=? AND user_id=?').bind(c.req.param('id'), userId).run() } catch {}
  try { await db.prepare('DELETE FROM rot_ocorrencias WHERE rota_id=? AND user_id=?').bind(c.req.param('id'), userId).run() } catch {}
  try { await dbDelete(db, 'rot_rotas', c.req.param('id'), userId) } catch(e: any) { return c.json(err('Erro: ' + (e?.message||e)), 500) }
  return c.json(ok({}))
})

// ── APIs Paradas ──────────────────────────────────────────────────────────────
app.post('/api/paradas', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const body = await c.req.json() as any
  if (!body.rota_id || !body.cliente_nome || !body.endereco || !body.cidade) return c.json(err('Campos obrigatórios ausentes'), 400)
  await ensureTables(db)
  const now = new Date().toISOString()
  const id = genId('rotpar')
  try { await dbInsert(db, 'rot_paradas', {
    id, user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
    rota_id: body.rota_id, ordem: body.ordem || 1,
    cliente_nome: body.cliente_nome, cliente_id: body.cliente_id || null,
    documento: body.documento || null,
    endereco: body.endereco, numero: body.numero || null,
    complemento: body.complemento || null, bairro: body.bairro || null,
    cidade: body.cidade, estado: body.estado || 'SP', cep: body.cep || null,
    lat: body.lat || null, lon: body.lon || null,
    pedido_ref: body.pedido_ref || null, nf_numero: body.nf_numero || null,
    nf_chave: body.nf_chave || null,
    volumes: body.volumes || 1, peso_kg: body.peso_kg || 0, valor_nf: body.valor_nf || 0,
    horario_prev: body.horario_prev || null, horario_real: null,
    janela_ini: body.janela_ini || null, janela_fim: body.janela_fim || null,
    status: body.status || 'pendente',
    motivo_ocorrencia: null, assinatura_nome: null, foto_comprovante: null,
    observacoes: body.observacoes || null, created_at: now, updated_at: now,
  }) } catch(e: any) { return c.json(err('Erro ao inserir parada: ' + (e?.message||e)), 500) }
  // Atualiza totais da rota
  try {
    const totais = await db.prepare(
      'SELECT COUNT(*) as total, SUM(peso_kg) as peso FROM rot_paradas WHERE rota_id=? AND user_id=?'
    ).bind(body.rota_id, userId).first() as any
    await db.prepare(
      'UPDATE rot_rotas SET total_paradas=?, total_peso_kg=?, updated_at=? WHERE id=? AND user_id=?'
    ).bind(totais?.total || 0, totais?.peso || 0, now, body.rota_id, userId).run()
  } catch {}
  return c.json(ok({ id }))
})

app.put('/api/paradas/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const id = c.req.param('id')
  const body = await c.req.json() as any
  await ensureTables(db)
  const now = new Date().toISOString()
  try { await dbUpdate(db, 'rot_paradas', id, userId, {
    ordem: body.ordem, cliente_nome: body.cliente_nome, documento: body.documento,
    endereco: body.endereco, numero: body.numero, bairro: body.bairro,
    cidade: body.cidade, estado: body.estado, cep: body.cep,
    pedido_ref: body.pedido_ref, nf_numero: body.nf_numero,
    volumes: body.volumes, peso_kg: body.peso_kg, valor_nf: body.valor_nf,
    horario_prev: body.horario_prev, horario_real: body.horario_real,
    janela_ini: body.janela_ini, janela_fim: body.janela_fim,
    status: body.status, motivo_ocorrencia: body.motivo_ocorrencia,
    assinatura_nome: body.assinatura_nome, observacoes: body.observacoes,
    updated_at: now,
  }) } catch(e: any) { return c.json(err('Erro ao atualizar parada: ' + (e?.message||e)), 500) }
  // Registra ocorrência se status mudou
  if (body.status && body.motivo_ocorrencia) {
    try {
      const parada = await db.prepare('SELECT rota_id FROM rot_paradas WHERE id=? AND user_id=?').bind(id, userId).first() as any
      if (parada) {
        await dbInsert(db, 'rot_ocorrencias', {
          id: genId('rotocr'), user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
          rota_id: parada.rota_id, parada_id: id,
          tipo: body.status, descricao: body.motivo_ocorrencia,
          lat: null, lon: null, created_at: now,
        })
      }
    } catch {}
  }
  return c.json(ok({}))
})

app.delete('/api/paradas/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  await ensureTables(db)
  const parada = await db.prepare('SELECT rota_id FROM rot_paradas WHERE id=? AND user_id=?').bind(c.req.param('id'), userId).first() as any
  try { await dbDelete(db, 'rot_paradas', c.req.param('id'), userId) } catch(e: any) { return c.json(err('Erro: ' + (e?.message||e)), 500) }
  // Atualiza totais da rota
  if (parada) {
    try {
      const now = new Date().toISOString()
      const totais = await db.prepare(
        'SELECT COUNT(*) as total, SUM(peso_kg) as peso FROM rot_paradas WHERE rota_id=? AND user_id=?'
      ).bind(parada.rota_id, userId).first() as any
      await db.prepare(
        'UPDATE rot_rotas SET total_paradas=?, total_peso_kg=?, updated_at=? WHERE id=? AND user_id=?'
      ).bind(totais?.total || 0, totais?.peso || 0, now, parada.rota_id, userId).run()
    } catch {}
  }
  return c.json(ok({}))
})

// ── APIs Cotação de Frete ─────────────────────────────────────────────────────
app.post('/api/cotacoes-frete', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const body = await c.req.json() as any
  if (!body.numero || !body.remetente_nome || !body.destinatario_nome) return c.json(err('Número, remetente e destinatário são obrigatórios'), 400)
  await ensureTables(db)
  const now = new Date().toISOString()
  const id = genId('rotcot')
  try {
    await dbInsert(db, 'rot_cotacoes_frete', {
      id, user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
      numero: body.numero,
      remetente_nome: body.remetente_nome, remetente_endereco: body.remetente_endereco || null,
      remetente_cidade: body.remetente_cidade || null, remetente_estado: body.remetente_estado || 'SP',
      remetente_cep: body.remetente_cep || null, remetente_cnpj: body.remetente_cnpj || null,
      destinatario_nome: body.destinatario_nome, destinatario_endereco: body.destinatario_endereco || null,
      destinatario_cidade: body.destinatario_cidade || null, destinatario_estado: body.destinatario_estado || null,
      destinatario_cep: body.destinatario_cep || null, destinatario_cnpj: body.destinatario_cnpj || null,
      modal: body.modal || 'rodoviario', tipo_servico: body.tipo_servico || 'normal',
      total_volumes: body.total_volumes || 1, peso_total_kg: body.peso_total_kg || 0,
      valor_nf: body.valor_nf || 0, incoterm: body.incoterm || 'CIF',
      volumes_detalhe: body.volumes_detalhe || '[]',
      data_coleta: body.data_coleta || null, data_entrega_prev: body.data_entrega_prev || null,
      obs: body.obs || null, transportadoras: body.transportadoras || '[]',
      status: body.status || 'aberta', vencimento: body.vencimento || null,
      created_at: now, updated_at: now,
    })
  } catch(e: any) { return c.json(err('Erro ao inserir cotação: ' + (e?.message||e)), 500) }
  return c.json(ok({ id }))
})

app.put('/api/cotacoes-frete/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const id = c.req.param('id')
  const body = await c.req.json() as any
  await ensureTables(db)
  const now = new Date().toISOString()
  try {
    await dbUpdate(db, 'rot_cotacoes_frete', id, userId, {
      numero: body.numero,
      remetente_nome: body.remetente_nome, remetente_endereco: body.remetente_endereco,
      remetente_cidade: body.remetente_cidade, remetente_estado: body.remetente_estado,
      remetente_cep: body.remetente_cep, remetente_cnpj: body.remetente_cnpj,
      destinatario_nome: body.destinatario_nome, destinatario_endereco: body.destinatario_endereco,
      destinatario_cidade: body.destinatario_cidade, destinatario_estado: body.destinatario_estado,
      destinatario_cep: body.destinatario_cep, destinatario_cnpj: body.destinatario_cnpj,
      modal: body.modal, tipo_servico: body.tipo_servico,
      total_volumes: body.total_volumes, peso_total_kg: body.peso_total_kg,
      valor_nf: body.valor_nf, incoterm: body.incoterm,
      volumes_detalhe: body.volumes_detalhe,
      data_coleta: body.data_coleta, data_entrega_prev: body.data_entrega_prev,
      obs: body.obs, transportadoras: body.transportadoras,
      status: body.status, vencimento: body.vencimento, updated_at: now,
    })
  } catch(e: any) { return c.json(err('Erro ao atualizar cotação: ' + (e?.message||e)), 500) }
  return c.json(ok({}))
})

app.delete('/api/cotacoes-frete/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  await ensureTables(db)
  try { await dbDelete(db, 'rot_cotacoes_frete', c.req.param('id'), userId) } catch(e: any) { return c.json(err('Erro: ' + (e?.message||e)), 500) }
  return c.json(ok({}))
})

// ── API Ocorrências (listagem) ─────────────────────────────────────────────────
app.get('/api/ocorrencias', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(ok({ ocorrencias: [] }))
  await ensureTables(db)
  const rotaId = c.req.query('rota_id')
  const q = rotaId
    ? 'SELECT * FROM rot_ocorrencias WHERE user_id=? AND rota_id=? ORDER BY created_at DESC LIMIT 100'
    : 'SELECT * FROM rot_ocorrencias WHERE user_id=? ORDER BY created_at DESC LIMIT 100'
  const bind = rotaId ? [userId, rotaId] : [userId]
  try {
    const res = await db.prepare(q).bind(...bind).all()
    return c.json(ok({ ocorrencias: res.results || [] }))
  } catch { return c.json(ok({ ocorrencias: [] })) }
})

export default app
