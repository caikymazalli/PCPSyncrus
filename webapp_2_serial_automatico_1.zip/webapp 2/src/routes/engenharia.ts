import { Hono } from 'hono'
import { layout } from '../layout'
import { getCtxTenant, getCtxUserInfo, getCtxDB, getCtxUserId, getCtxEmpresaId } from '../sessionHelper'
import { genId, dbInsert, dbUpdate, dbDelete, ok, err } from '../dbHelpers'
import { markTenantModified } from '../userStore'
import { requireModuleWriteAccess } from '../moduleAccess'

const app = new Hono()

app.use('*', async (c, next) => {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(c.req.method)) {
    const blocked = await requireModuleWriteAccess(c, 'engenharia')
    if (blocked) return blocked
  }
  return next()
})

const PRODUTOS_URL = '/produtos'

app.get('/', (c) => {
  const tenant = getCtxTenant(c)
  const userInfo = getCtxUserInfo(c)
  const mockData = tenant  // per-session data
  const products = (mockData as any).products || []
  const bomItems = (mockData as any).bomItems || []
  const routes = (mockData as any).routes || []

  const content = `
  <!-- Header -->
  <div class="section-header">
    <div style="font-size:14px;color:#6c757d;">BOM (Lista de Materiais) e Roteiros de Fabricação</div>
    <a class="btn btn-secondary" href="${PRODUTOS_URL}"><i class="fas fa-external-link-alt"></i> Gerenciar Produtos</a>
  </div>

  <div data-tab-group="eng">
    <div class="tab-nav">
      <button class="tab-btn active" onclick="switchTab('tabProdutos','eng')"><i class="fas fa-box" style="margin-right:6px;"></i>Produtos (${products.length})</button>
      <button class="tab-btn" onclick="switchTab('tabBOM','eng')"><i class="fas fa-list-ul" style="margin-right:6px;"></i>BOM — Lista de Materiais</button>
      <button class="tab-btn" onclick="switchTab('tabRoteiros','eng')"><i class="fas fa-route" style="margin-right:6px;"></i>Roteiros (${routes.length})</button>
    </div>

    <!-- Produtos -->
    <div class="tab-content active" id="tabProdutos">
      <div class="card" style="overflow:hidden;">
        <div style="padding:14px 20px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;">
          <div class="search-box" style="flex:1;max-width:320px;">
            <i class="fas fa-search icon"></i>
            <input class="form-control" type="text" placeholder="Buscar produto...">
          </div>
          <a class="btn btn-secondary btn-sm" href="${PRODUTOS_URL}"><i class="fas fa-external-link-alt"></i> Abrir em /produtos</a>
        </div>
        <div class="table-wrapper">
          <table>
            <thead><tr>
              <th>Código</th><th>Nome</th><th>Descrição</th><th>Unidade</th><th>BOM</th><th>Roteiros</th><th>Ações</th>
            </tr></thead>
            <tbody>
              ${products.map(p => {
                const bomCount = bomItems.filter(b => b.productCode === p.code).length
                const routeCount = routes.filter(r => r.productCode === p.code).length
                return `
                <tr>
                  <td><span style="font-family:monospace;font-size:12px;background:#f1f5f9;padding:2px 8px;border-radius:4px;color:#1B4F72;font-weight:700;">${p.code}</span></td>
                  <td style="font-weight:600;color:#374151;">${p.name}</td>
                  <td style="font-size:12px;color:#6c757d;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${p.description || '—'}</td>
                  <td><span class="chip" style="background:#f1f5f9;color:#374151;">${p.unit}</span></td>
                  <td>
                    <a href="#" onclick="showBOM('${p.code}');return false;" style="font-size:12px;font-weight:600;color:${bomCount > 0 ? '#2980B9' : '#9ca3af'};">
                      ${bomCount > 0 ? `<i class="fas fa-list"></i> ${bomCount} itens` : '<i class="fas fa-plus"></i> Adicionar'}
                    </a>
                  </td>
                  <td>
                    <a href="#" onclick="showRoteiro('${p.code}');return false;" style="font-size:12px;font-weight:600;color:${routeCount > 0 ? '#27AE60' : '#9ca3af'};">
                      ${routeCount > 0 ? `<i class="fas fa-route"></i> ${routeCount} roteiros` : '<i class="fas fa-plus"></i> Adicionar'}
                    </a>
                  </td>
                  <td>
                    <a class="btn btn-secondary btn-sm" href="${PRODUTOS_URL}"><i class="fas fa-external-link-alt"></i> Abrir em /produtos</a>
                  </td>
                </tr>`
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- BOM Tab -->
    <div class="tab-content" id="tabBOM">
      <div style="display:grid;grid-template-columns:280px 1fr;gap:20px;">
        <!-- Product selector -->
        <div class="card" style="padding:16px;">
          <div style="font-size:13px;font-weight:700;color:#1B4F72;margin-bottom:12px;">Selecionar Produto</div>
          <div style="display:flex;flex-direction:column;gap:2px;">
            ${products.map((p, i) => `
            <button onclick="selectBOMProduct('${p.code}')" id="bomBtn_${p.code}" class="nav-item ${i === 0 ? 'active' : ''}" style="text-align:left;border:none;cursor:pointer;border-radius:6px;padding:8px 10px;">
              <div style="font-size:13px;font-weight:600;">${p.name}</div>
              <div style="font-size:10px;opacity:0.7;">${p.code}</div>
            </button>`).join('')}
          </div>
        </div>

        <!-- BOM content -->
        <div>
          <div class="card" style="overflow:hidden;" id="bomContent">
            <div style="padding:16px 20px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;">
              <h4 style="margin:0;font-size:15px;font-weight:700;color:#1B4F72;" id="bomTitle">BOM — ${products[0]?.name}</h4>
              <button class="btn btn-primary btn-sm" onclick="openModal('novoBOMModal')"><i class="fas fa-plus"></i> Adicionar Componente</button>
            </div>
            <div class="table-wrapper" id="bomTable">
              <table>
                <thead><tr><th>#</th><th>Componente</th><th>Código</th><th>Quantidade</th><th>Unidade</th><th>Notas</th><th>Ações</th></tr></thead>
                <tbody id="bomBody">
                  ${bomItems.filter(b => b.productCode === products[0]?.code).map((b, idx) => `
                  <tr>
                    <td style="color:#9ca3af;font-size:12px;">${idx + 1}</td>
                    <td style="font-weight:600;color:#374151;">${b.componentName}</td>
                    <td><span style="font-family:monospace;font-size:11px;background:#f1f5f9;padding:1px 6px;border-radius:4px;color:#6c757d;">${b.componentCode || '—'}</span></td>
                    <td style="font-weight:700;color:#1B4F72;">${b.quantity}</td>
                    <td><span class="chip" style="background:#f1f5f9;color:#374151;">${b.unit}</span></td>
                    <td style="font-size:12px;color:#9ca3af;">—</td>
                    <td>
                      <div style="display:flex;gap:4px;">
                        <button class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                      </div>
                    </td>
                  </tr>`).join('')}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Roteiros Tab -->
    <div class="tab-content" id="tabRoteiros">
      <!-- Header da aba -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
        <div>
          <div style="font-size:14px;font-weight:700;color:#1B4F72;">Roteiros de Fabricação</div>
          <div style="font-size:12px;color:#6c757d;margin-top:2px;">Sequência de operações para fabricação de cada produto</div>
        </div>
        <button class="btn btn-primary" onclick="openNovoRoteiro()">
          <i class="fas fa-plus"></i> Novo Roteiro
        </button>
      </div>

      ${routes.length === 0 ? `
      <!-- Estado vazio -->
      <div class="card" style="padding:56px 20px;text-align:center;color:#9ca3af;">
        <i class="fas fa-route" style="font-size:40px;margin-bottom:16px;display:block;opacity:0.2;"></i>
        <div style="font-size:16px;font-weight:600;color:#6c757d;margin-bottom:6px;">Nenhum roteiro cadastrado</div>
        <div style="font-size:13px;margin-bottom:20px;">Crie roteiros para definir a sequência de operações de fabricação de cada produto.</div>
        <button class="btn btn-primary" onclick="openNovoRoteiro()">
          <i class="fas fa-plus"></i> Criar Primeiro Roteiro
        </button>
      </div>` : `
      <!-- Lista de roteiros -->
      <div style="display:flex;flex-direction:column;gap:20px;">
        ${routes.map((r: any) => `
        <div class="card" style="overflow:hidden;">
          <div style="padding:16px 20px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;background:linear-gradient(to right,#f8fafc,#fff);">
            <div>
              <div style="font-size:15px;font-weight:700;color:#1B4F72;">${r.name}</div>
              <div style="font-size:12px;color:#9ca3af;margin-top:2px;"><i class="fas fa-box" style="margin-right:4px;"></i>${r.productName || '—'} ${r.productCode ? '(' + r.productCode + ')' : ''}</div>
            </div>
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:flex-end;">
              <span class="chip" style="background:#e8f4fd;color:#1B4F72;font-size:11px;">v${r.version || '1.0'}</span>
              <span class="chip" style="font-size:11px;background:${r.status === 'active' ? '#d1fae5' : r.status === 'draft' ? '#fef3c7' : '#f1f5f9'};color:${r.status === 'active' ? '#065f46' : r.status === 'draft' ? '#92400e' : '#6c757d'};">${r.status === 'active' ? '✅ Ativo' : r.status === 'draft' ? '📝 Rascunho' : '⚠️ Obsoleto'}</span>
              <span style="font-size:12px;color:#6c757d;">${(r.steps||[]).length} operação(ões)</span>
              <span style="font-size:12px;color:#27AE60;font-weight:700;"><i class="fas fa-clock" style="margin-right:4px;"></i>${(r.steps||[]).reduce((acc: number, s: any) => acc + (s.standardTime||0), 0)} min total</span>
              <button class="btn btn-secondary btn-sm" onclick="usarComoModelo('${r.id}')" title="Usar como modelo"><i class="fas fa-copy"></i> Usar como Modelo</button>
              <button class="btn btn-secondary btn-sm" onclick="openEditarRoteiro('${r.id}')" title="Editar roteiro"><i class="fas fa-edit"></i> Editar</button>
              <button class="btn btn-secondary btn-sm" onclick="openRoteiroHistory('${r.id}')" title="Histórico de versões"><i class="fas fa-history"></i> Histórico</button>
              <button class="btn btn-danger btn-sm" onclick="deleteRoteiro('${r.id}')" title="Excluir roteiro"><i class="fas fa-trash"></i></button>
            </div>
          </div>
          <div style="padding:16px 20px;">
            ${(r.steps||[]).length === 0 ? `
            <div style="text-align:center;padding:16px;color:#9ca3af;font-size:13px;">
              <i class="fas fa-list-ol" style="margin-right:6px;opacity:0.4;"></i>Nenhuma operação cadastrada neste roteiro.
            </div>` : `
            <div style="display:flex;gap:0;align-items:center;overflow-x:auto;padding-bottom:8px;">
              ${(r.steps||[]).map((s: any, idx: number) => `
              <div style="display:flex;align-items:center;">
                <div style="min-width:155px;background:#f8f9fa;border-radius:8px;padding:12px;border:1px solid #e9ecef;">
                  <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
                    <div style="width:22px;height:22px;border-radius:50%;background:#1B4F72;color:white;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0;">${s.order}</div>
                    <div style="font-size:12px;font-weight:700;color:#1B4F72;">${s.operation}</div>
                  </div>
                  <div style="font-size:11px;color:#9ca3af;"><i class="fas fa-clock" style="margin-right:3px;"></i>${s.standardTime} min</div>
                  ${s.machine ? `<div style="font-size:10px;color:#2980B9;margin-top:3px;"><i class="fas fa-cog" style="margin-right:3px;"></i>${s.machine}</div>` : ''}
                  <div style="font-size:10px;margin-top:4px;">
                    <span class="chip" style="background:#e8f4fd;color:#1B4F72;font-size:10px;">${s.resourceType === 'machine' ? '⚙️ Máquina' : s.resourceType === 'workbench' ? '🔧 Bancada' : '👤 Manual'}</span>
                  </div>
                </div>
                ${idx < (r.steps||[]).length - 1 ? '<div style="width:24px;height:2px;background:#d1d5db;flex-shrink:0;"></div><div style="color:#9ca3af;flex-shrink:0;font-size:14px;">›</div><div style="width:4px;height:2px;background:#d1d5db;flex-shrink:0;"></div>' : ''}
              </div>`).join('')}
            </div>`}
          </div>
        </div>`).join('')}
      </div>`}
    </div>
  </div>

  <!-- Novo BOM Modal -->
  <div class="modal-overlay" id="novoBOMModal">
    <div class="modal">
      <div style="padding:20px 24px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;">
        <h3 style="margin:0;font-size:17px;font-weight:700;color:#1B4F72;"><i class="fas fa-plus-circle" style="margin-right:8px;"></i>Adicionar Componente BOM</h3>
        <button onclick="closeModal('novoBOMModal')" style="background:none;border:none;font-size:20px;cursor:pointer;color:#9ca3af;">×</button>
      </div>
      <div style="padding:20px 24px;">
        <div class="form-group">
          <label class="form-label">Produto *</label>
          <select class="form-control" id="bom_produto">
            <option value="">— Selecione o produto —</option>
            ${products.map((p: any) => `<option value="${p.id || p.code}" data-code="${p.code}" data-name="${p.name}">${p.name} (${p.code})</option>`).join('')}
          </select>
        </div>
        <div class="form-group"><label class="form-label">Nome do Componente *</label><input class="form-control" id="bom_componente" type="text" placeholder="Ex: Rolamento 6205-2RS"></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
          <div class="form-group"><label class="form-label">Código do Componente</label><input class="form-control" id="bom_codigo" type="text" placeholder="ROL-003"></div>
          <div class="form-group"><label class="form-label">Quantidade *</label><input class="form-control" id="bom_quantidade" type="number" placeholder="0" step="0.01"></div>
          <div class="form-group"><label class="form-label">Unidade *</label>
            <select class="form-control" id="bom_unidade"><option value="un">un</option><option value="kg">kg</option><option value="m">m</option><option value="l">l</option></select>
          </div>
        </div>
        <div class="form-group"><label class="form-label">Notas</label><input class="form-control" id="bom_notas" type="text" placeholder="Especificações adicionais..."></div>
      </div>
      <div style="padding:16px 24px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
        <button onclick="closeModal('novoBOMModal')" class="btn btn-secondary">Cancelar</button>
        <button onclick="salvarBomItem()" class="btn btn-primary"><i class="fas fa-save"></i> Adicionar</button>
      </div>
    </div>
  </div>

  <!-- Modal: Novo Roteiro -->
  <div class="modal-overlay" id="novoRoteiroModal">
    <div class="modal" style="max-width:700px;">
      <div style="padding:20px 24px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;">
        <h3 style="margin:0;font-size:17px;font-weight:700;color:#1B4F72;"><i class="fas fa-route" style="margin-right:8px;color:#27AE60;"></i><span id="roteiroModalTitle">Novo Roteiro de Fabricação</span></h3>
        <button onclick="closeModal('novoRoteiroModal')" style="background:none;border:none;font-size:20px;cursor:pointer;color:#9ca3af;">×</button>
      </div>
      <div style="padding:20px 24px;max-height:70vh;overflow-y:auto;">
        <input type="hidden" id="rot_edit_id" value="">

        <!-- Dados gerais -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px;">
          <div class="form-group" style="grid-column:span 2;">
            <label class="form-label">Nome do Roteiro *</label>
            <input class="form-control" type="text" id="rot_nome" placeholder="Ex: Roteiro Usinagem – Eixo Principal">
          </div>
          <div class="form-group" style="grid-column:span 2;">
            <label class="form-label">Produto *</label>
            <select class="form-control" id="rot_produto">
              <option value="">— Selecione o produto —</option>
              ${products.map((p: any) => `<option value="${p.id || p.code}" data-code="${p.code}" data-name="${p.name}">${p.name} (${p.code})</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Versão</label>
            <input class="form-control" type="text" id="rot_versao" placeholder="Ex: 1.0" value="1.0">
          </div>
          <div class="form-group">
            <label class="form-label">Status</label>
            <select class="form-control" id="rot_status">
              <option value="active">Ativo</option>
              <option value="draft">Rascunho</option>
              <option value="obsolete">Obsoleto</option>
            </select>
          </div>
          <div class="form-group" style="grid-column:span 2;">
            <label class="form-label">Observações</label>
            <textarea class="form-control" id="rot_obs" rows="2" placeholder="Informações adicionais sobre o roteiro..."></textarea>
          </div>
        </div>

        <!-- Operações / Passos -->
        <div style="border-top:1px solid #f1f3f5;padding-top:16px;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
            <div style="font-size:13px;font-weight:700;color:#1B4F72;"><i class="fas fa-list-ol" style="margin-right:6px;color:#27AE60;"></i>Operações</div>
            <button type="button" class="btn btn-secondary btn-sm" onclick="addRoteiroStep()">
              <i class="fas fa-plus"></i> Adicionar Operação
            </button>
          </div>
          <div id="roteiroStepsContainer" style="display:flex;flex-direction:column;gap:8px;">
            <!-- Passos serão adicionados dinamicamente -->
          </div>
          <div id="roteiroStepsEmpty" style="text-align:center;padding:20px;color:#9ca3af;font-size:13px;border:2px dashed #e9ecef;border-radius:8px;">
            <i class="fas fa-plus-circle" style="font-size:22px;margin-bottom:8px;display:block;opacity:0.4;"></i>
            Clique em "Adicionar Operação" para inserir as etapas do roteiro.
          </div>
        </div>

      </div>
      <div style="padding:16px 24px;border-top:1px solid #f1f3f5;display:flex;justify-content:space-between;align-items:center;">
        <span id="rotStepCount" style="font-size:12px;color:#9ca3af;">0 operação(ões)</span>
        <div style="display:flex;gap:10px;">
          <button onclick="closeModal('novoRoteiroModal')" class="btn btn-secondary">Cancelar</button>
          <button onclick="salvarRoteiro()" class="btn btn-primary"><i class="fas fa-save"></i> Salvar Roteiro</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal: Escolha de Versão (edição) -->
  <div class="modal-overlay" id="versaoRoteiroModal">
    <div class="modal" style="max-width:440px;">
      <div style="padding:20px 24px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;">
        <h3 style="margin:0;font-size:17px;font-weight:700;color:#1B4F72;"><i class="fas fa-code-branch" style="margin-right:8px;color:#27AE60;"></i>Salvar Alterações</h3>
        <button onclick="closeModal('versaoRoteiroModal')" style="background:none;border:none;font-size:20px;cursor:pointer;color:#9ca3af;">×</button>
      </div>
      <div style="padding:20px 24px;">
        <p style="font-size:13px;color:#374151;margin-bottom:20px;">Como deseja salvar as alterações deste roteiro?</p>
        <div style="display:flex;flex-direction:column;gap:12px;">
          <button onclick="confirmarVersaoRoteiro('keep')" class="btn btn-secondary" style="text-align:left;padding:12px 16px;">
            <div style="font-size:13px;font-weight:700;color:#374151;">Manter versão <span id="versaoAtualLabel">1.0</span></div>
            <div style="font-size:11px;color:#9ca3af;margin-top:2px;">Sobrescreve o roteiro atual sem criar histórico</div>
          </button>
          <button onclick="confirmarVersaoRoteiro('new')" class="btn btn-primary" style="text-align:left;padding:12px 16px;">
            <div style="font-size:13px;font-weight:700;">Criar nova versão <span id="versaoNovaLabel">1.1</span></div>
            <div style="font-size:11px;opacity:0.8;margin-top:2px;">Cria novo registro mantendo histórico do anterior (arquiva o atual)</div>
          </button>
        </div>
      </div>
      <div style="padding:12px 24px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;">
        <button onclick="closeModal('versaoRoteiroModal')" class="btn btn-secondary">Cancelar</button>
      </div>
    </div>
  </div>

  <!-- Histórico de Versões Modal -->
  <div class="modal-overlay" id="roteiroHistoryModal">
    <div class="modal" style="max-width:600px;">
      <div style="padding:20px 24px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;">
        <h3 style="margin:0;font-size:17px;font-weight:700;color:#1B4F72;"><i class="fas fa-history" style="margin-right:8px;color:#27AE60;"></i>Histórico de Versões</h3>
        <button onclick="closeModal('roteiroHistoryModal')" style="background:none;border:none;font-size:20px;cursor:pointer;color:#9ca3af;">×</button>
      </div>
      <div style="padding:20px 24px;">
        <div id="roteiroHistoryLoading" style="text-align:center;padding:24px;color:#6c757d;display:none;">
          <i class="fas fa-spinner fa-spin" style="font-size:24px;margin-bottom:8px;display:block;"></i>Carregando histórico...
        </div>
        <div id="roteiroHistoryEmpty" style="text-align:center;padding:24px;color:#9ca3af;display:none;">
          <i class="fas fa-history" style="font-size:32px;margin-bottom:8px;display:block;opacity:0.3;"></i>
          <div style="font-size:14px;">Nenhum histórico de versões encontrado.</div>
        </div>
        <div id="roteiroHistoryContent" style="display:none;">
          <table style="width:100%;border-collapse:collapse;font-size:13px;">
            <thead>
              <tr style="background:#f8f9fa;border-bottom:2px solid #dee2e6;">
                <th style="padding:8px 12px;text-align:left;font-weight:700;color:#1B4F72;">Versão</th>
                <th style="padding:8px 12px;text-align:left;font-weight:700;color:#1B4F72;">Criado em</th>
                <th style="padding:8px 12px;text-align:left;font-weight:700;color:#1B4F72;">Atualizado em</th>
                <th style="padding:8px 12px;text-align:left;font-weight:700;color:#1B4F72;">Criado por</th>
                <th style="padding:8px 12px;text-align:left;font-weight:700;color:#1B4F72;">Atualizado por</th>
              </tr>
            </thead>
            <tbody id="roteiroHistoryBody"></tbody>
          </table>
        </div>
      </div>
      <div style="padding:12px 24px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;">
        <button onclick="closeModal('roteiroHistoryModal')" class="btn btn-secondary">Fechar</button>
      </div>
    </div>
  </div>

  <script>
  const allBOM = ${JSON.stringify(bomItems)};
  const allProducts = ${JSON.stringify(products)};
  const allRoutes = ${JSON.stringify(routes)};

  // ── Roteiro: abrir modal ──────────────────────────────────────────────────────
  function openNovoRoteiro() {
    _roteiroEditId = '';
    document.getElementById('rot_edit_id').value = '';
    document.getElementById('roteiroModalTitle').textContent = 'Novo Roteiro de Fabricação';
    // Limpar campos
    document.getElementById('rot_nome').value = '';
    document.getElementById('rot_produto').value = '';
    document.getElementById('rot_versao').value = '1.0';
    document.getElementById('rot_status').value = 'active';
    document.getElementById('rot_obs').value = '';
    document.getElementById('roteiroStepsContainer').innerHTML = '';
    document.getElementById('roteiroStepsEmpty').style.display = 'block';
    document.getElementById('rotStepCount').textContent = '0 operação(ões)';
    _roteiroStepCount = 0;
    openModal('novoRoteiroModal');
  }

  let _roteiroStepCount = 0;
  let _roteiroEditId = '';
  let _pendingRoteiroSave = null;

  function addRoteiroStep() {
    _roteiroStepCount++;
    const idx = _roteiroStepCount;
    document.getElementById('roteiroStepsEmpty').style.display = 'none';
    const container = document.getElementById('roteiroStepsContainer');
    const div = document.createElement('div');
    div.id = 'step_' + idx;
    div.style.cssText = 'background:#f8f9fa;border-radius:8px;padding:12px 14px;border:1px solid #e9ecef;';
    div.innerHTML = \`
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
        <div data-step-badge style="width:24px;height:24px;border-radius:50%;background:#1B4F72;color:white;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0;">\${idx}</div>
        <span data-step-label style="font-size:13px;font-weight:700;color:#374151;flex:1;">Operação \${idx}</span>
        <button type="button" onclick="moveStepUp(\${idx})" title="Mover para cima" style="background:none;border:1px solid #d1d5db;border-radius:4px;padding:2px 7px;cursor:pointer;color:#6c757d;font-size:12px;line-height:1.4;">↑</button>
        <button type="button" onclick="moveStepDown(\${idx})" title="Mover para baixo" style="background:none;border:1px solid #d1d5db;border-radius:4px;padding:2px 7px;cursor:pointer;color:#6c757d;font-size:12px;line-height:1.4;">↓</button>
        <button type="button" onclick="removeStep(\${idx})" style="background:none;border:none;color:#9ca3af;cursor:pointer;font-size:14px;" title="Remover operação"><i class="fas fa-times"></i></button>
      </div>
      <div style="display:grid;grid-template-columns:2fr 1fr 1fr;gap:10px;">
        <div>
          <label style="font-size:11px;font-weight:700;color:#6c757d;text-transform:uppercase;margin-bottom:4px;display:block;">Nome da Operação *</label>
          <input class="form-control" id="step_op_\${idx}" type="text" placeholder="Ex: Torneamento, Fresamento..." style="font-size:12px;">
        </div>
        <div>
          <label style="font-size:11px;font-weight:700;color:#6c757d;text-transform:uppercase;margin-bottom:4px;display:block;">Tempo (min) *</label>
          <input class="form-control" id="step_time_\${idx}" type="number" placeholder="0" min="0" step="0.5" style="font-size:12px;">
        </div>
        <div>
          <label style="font-size:11px;font-weight:700;color:#6c757d;text-transform:uppercase;margin-bottom:4px;display:block;">Tipo de Recurso</label>
          <select class="form-control" id="step_res_\${idx}" style="font-size:12px;">
            <option value="machine">⚙️ Máquina</option>
            <option value="workbench">🔧 Bancada</option>
            <option value="manual">👤 Manual</option>
          </select>
        </div>
        <div style="grid-column:span 3;">
          <label style="font-size:11px;font-weight:700;color:#6c757d;text-transform:uppercase;margin-bottom:4px;display:block;">Máquina / Centro de Trabalho</label>
          <input class="form-control" id="step_maq_\${idx}" type="text" placeholder="Ex: Torno CNC-01, Fresadora FA-02..." style="font-size:12px;">
        </div>
      </div>
    \`;
    container.appendChild(div);
    refreshStepBadges();
  }

  function removeStep(idx) {
    const el = document.getElementById('step_' + idx);
    if (el) el.remove();
    refreshStepBadges();
    const remaining = document.querySelectorAll('#roteiroStepsContainer > [id^="step_"]').length;
    if (remaining === 0) document.getElementById('roteiroStepsEmpty').style.display = 'block';
  }

  function moveStepUp(idx) {
    const el = document.getElementById('step_' + idx);
    if (!el || !el.previousElementSibling) return;
    el.parentNode.insertBefore(el, el.previousElementSibling);
    refreshStepBadges();
  }

  function moveStepDown(idx) {
    const el = document.getElementById('step_' + idx);
    if (!el || !el.nextElementSibling) return;
    el.parentNode.insertBefore(el.nextElementSibling, el);
    refreshStepBadges();
  }

  function refreshStepBadges() {
    const steps = document.querySelectorAll('#roteiroStepsContainer > [id^="step_"]');
    steps.forEach((stepEl, i) => {
      const badge = stepEl.querySelector('[data-step-badge]');
      if (badge) badge.textContent = String(i + 1);
      const label = stepEl.querySelector('[data-step-label]');
      if (label) label.textContent = 'Operação ' + (i + 1);
    });
    document.getElementById('rotStepCount').textContent = steps.length + ' operação(ões)';
  }

  function addRoteiroStepWithData(stepData) {
    addRoteiroStep();
    const idx = _roteiroStepCount;
    const opEl = document.getElementById('step_op_' + idx);
    const timeEl = document.getElementById('step_time_' + idx);
    const resEl = document.getElementById('step_res_' + idx);
    const maqEl = document.getElementById('step_maq_' + idx);
    if (opEl) opEl.value = stepData.operation || stepData.name || '';
    if (timeEl) timeEl.value = stepData.standardTime != null ? stepData.standardTime : 0;
    if (resEl) resEl.value = stepData.resourceType || 'manual';
    if (maqEl) maqEl.value = stepData.machine || '';
  }

  function _collectSteps() {
    const stepEls = Array.from(document.querySelectorAll('#roteiroStepsContainer > [id^="step_"]'));
    const steps = [];
    for (let i = 0; i < stepEls.length; i++) {
      const stepEl = stepEls[i];
      const idxStr = stepEl.id.replace('step_', '');
      const op    = document.getElementById('step_op_' + idxStr)?.value?.trim() || '';
      const time  = parseFloat(document.getElementById('step_time_' + idxStr)?.value || '0') || 0;
      const res   = document.getElementById('step_res_' + idxStr)?.value || 'manual';
      const maq   = document.getElementById('step_maq_' + idxStr)?.value?.trim() || '';
      if (!op) { showToast('Preencha o nome de todas as operações!', 'error'); return null; }
      steps.push({ order: i + 1, operation: op, standardTime: time, resourceType: res, machine: maq });
    }
    return steps;
  }

  function _openRoteiroWith(route, title, editId) {
    _roteiroEditId = editId || '';
    document.getElementById('rot_edit_id').value = _roteiroEditId;
    document.getElementById('roteiroModalTitle').textContent = title;
    document.getElementById('rot_nome').value = route.name || '';
    const sel = document.getElementById('rot_produto');
    if (sel) sel.value = route.productId || '';
    document.getElementById('rot_versao').value = route.version || '1.0';
    const statusEl = document.getElementById('rot_status');
    if (statusEl) statusEl.value = route.status || 'active';
    document.getElementById('rot_obs').value = route.notes || '';
    document.getElementById('roteiroStepsContainer').innerHTML = '';
    _roteiroStepCount = 0;
    (route.steps || []).forEach(s => addRoteiroStepWithData(s));
    const hasSteps = _roteiroStepCount > 0;
    document.getElementById('roteiroStepsEmpty').style.display = hasSteps ? 'none' : 'block';
    refreshStepBadges();
    openModal('novoRoteiroModal');
  }

  function usarComoModelo(routeId) {
    const route = allRoutes.find(r => r.id === routeId);
    if (!route) return;
    _openRoteiroWith(
      { ...route, name: route.name + ' (Cópia)', productId: '', version: '1.0', status: 'active' },
      'Novo Roteiro (baseado em modelo)',
      ''
    );
  }

  function openEditarRoteiro(routeId) {
    const route = allRoutes.find(r => r.id === routeId);
    if (!route) return;
    _openRoteiroWith(route, 'Editar Roteiro de Fabricação', routeId);
  }

  function incrementVersion(v) {
    const parts = String(v || '1.0').split('.');
    const major = parseInt(parts[0] || '1', 10);
    const minor = parseInt(parts[1] || '0', 10);
    return major + '.' + (minor + 1);
  }

  async function salvarRoteiro() {
    const nome    = document.getElementById('rot_nome')?.value?.trim() || '';
    const prodEl  = document.getElementById('rot_produto');
    const prodId  = prodEl?.value || '';
    const prodOpt = prodEl?.options[prodEl.selectedIndex];
    const productCode = prodOpt?.dataset?.code || '';
    const productName = prodOpt?.dataset?.name || '';
    const versao  = document.getElementById('rot_versao')?.value?.trim() || '1.0';
    const status  = document.getElementById('rot_status')?.value || 'active';
    const obs     = document.getElementById('rot_obs')?.value?.trim() || '';

    if (!nome)   { showToast('Informe o nome do roteiro!', 'error'); return; }
    if (!prodId) { showToast('Selecione o produto!', 'error'); return; }

    const steps = _collectSteps();
    if (!steps) return;

    const payload = { name: nome, productId: prodId, productCode, productName, version: versao, status, notes: obs, steps };
    const editId = document.getElementById('rot_edit_id')?.value || '';

    if (editId) {
      const currentRoute = allRoutes.find(r => r.id === editId);
      const curVersion = currentRoute?.version || versao;
      document.getElementById('versaoAtualLabel').textContent = curVersion;
      document.getElementById('versaoNovaLabel').textContent = incrementVersion(curVersion);
      _pendingRoteiroSave = { editId, payload, currentRoute };
      openModal('versaoRoteiroModal');
    } else {
      await _execSalvarRoteiro(payload);
    }
  }

  async function confirmarVersaoRoteiro(choice) {
    closeModal('versaoRoteiroModal');
    if (!_pendingRoteiroSave) return;
    const { editId, payload, currentRoute } = _pendingRoteiroSave;
    _pendingRoteiroSave = null;

    if (choice === 'keep') {
      await _execUpdateRoteiro(editId, payload);
    } else {
      if (!editId) { showToast('ID do roteiro não encontrado', 'error'); return; }
      const newVersion = incrementVersion(currentRoute?.version || '1.0');
      await _execNovaVersaoRoteiro(editId, { ...payload, version: newVersion });
    }
  }

  async function _execNovaVersaoRoteiro(parentId, payload) {
    try {
      const res = await fetch('/engenharia/api/roteiros/' + parentId + '/version', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.ok) {
        showToast('✅ Nova versão criada! Versão anterior arquivada automaticamente.');
        closeModal('novoRoteiroModal');
        setTimeout(() => location.reload(), 800);
      } else {
        showToast(data.error || 'Erro ao criar nova versão', 'error');
      }
    } catch(e) { showToast('Erro de conexão', 'error'); }
  }

  async function _execSalvarRoteiro(payload) {
    try {
      const res = await fetch('/engenharia/api/route/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.ok) {
        showToast('✅ Roteiro criado com sucesso!');
        closeModal('novoRoteiroModal');
        setTimeout(() => location.reload(), 800);
      } else {
        showToast(data.error || 'Erro ao salvar roteiro', 'error');
      }
    } catch(e) { showToast('Erro de conexão', 'error'); }
  }

  async function _execUpdateRoteiro(id, payload) {
    try {
      const res = await fetch('/engenharia/api/route/' + id, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.ok) {
        showToast('✅ Roteiro atualizado com sucesso!');
        closeModal('novoRoteiroModal');
        setTimeout(() => location.reload(), 800);
      } else {
        showToast(data.error || 'Erro ao atualizar roteiro', 'error');
      }
    } catch(e) { showToast('Erro de conexão', 'error'); }
  }

  async function deleteRoteiro(id) {
    if (!confirm('Excluir este roteiro? Esta ação não pode ser desfeita.')) return;
    try {
      const res = await fetch('/engenharia/api/route/' + id, { method: 'DELETE' });
      const data = await res.json();
      if (data.ok) { showToast('Roteiro excluído!'); setTimeout(() => location.reload(), 500); }
      else showToast(data.error || 'Erro ao excluir', 'error');
    } catch(e) { showToast('Erro de conexão', 'error'); }
  }

  async function openRoteiroHistory(routeId) {
    const loading = document.getElementById('roteiroHistoryLoading');
    const empty = document.getElementById('roteiroHistoryEmpty');
    const content = document.getElementById('roteiroHistoryContent');
    const tbody = document.getElementById('roteiroHistoryBody');
    if (loading) loading.style.display = 'block';
    if (empty) empty.style.display = 'none';
    if (content) content.style.display = 'none';
    if (tbody) tbody.innerHTML = '';
    openModal('roteiroHistoryModal');
    try {
      const res = await fetch('/engenharia/api/roteiros/' + routeId + '/history');
      const data = await res.json();
      if (loading) loading.style.display = 'none';
      if (!data.ok || !data.history || data.history.length === 0) {
        if (empty) empty.style.display = 'block';
        return;
      }
      if (content) content.style.display = 'block';
      if (tbody) {
        tbody.innerHTML = data.history.map((h, idx) => {
          const isLatest = idx === 0;
          const createdAt = h.createdAt ? new Date(h.createdAt).toLocaleString('pt-BR') : '—';
          const updatedAt = h.updatedAt ? new Date(h.updatedAt).toLocaleString('pt-BR') : '—';
          return \`<tr style="border-bottom:1px solid #f1f3f5;\${isLatest ? 'background:#f0fdf4;' : ''}">
            <td style="padding:8px 12px;">
              <span class="chip" style="background:#e8f4fd;color:#1B4F72;font-size:11px;">v\${h.version || '—'}</span>
              \${isLatest ? '<span class="chip" style="background:#d1fae5;color:#065f46;font-size:10px;margin-left:4px;">Atual</span>' : ''}
            </td>
            <td style="padding:8px 12px;font-size:12px;color:#374151;">\${createdAt}</td>
            <td style="padding:8px 12px;font-size:12px;color:#374151;">\${updatedAt}</td>
            <td style="padding:8px 12px;font-size:12px;color:#6c757d;">\${h.createdByUserId || '—'}</td>
            <td style="padding:8px 12px;font-size:12px;color:#6c757d;">\${h.updatedByUserId || '—'}</td>
          </tr>\`;
        }).join('');
      }
    } catch(e) {
      if (loading) loading.style.display = 'none';
      if (empty) empty.style.display = 'block';
      showToast('Erro ao carregar histórico', 'error');
    }
  }

  function selectBOMProduct(code) {
    // Update active button
    document.querySelectorAll('[id^="bomBtn_"]').forEach(b => b.classList.remove('active'));
    document.getElementById('bomBtn_' + code)?.classList.add('active');
    // Filter BOM
    const items = allBOM.filter(b => b.productCode === code);
    const prod = allProducts.find(p => p.code === code);
    document.getElementById('bomTitle').textContent = 'BOM — ' + (prod?.name || code);
    const tbody = document.getElementById('bomBody');
    if (tbody) {
      tbody.innerHTML = items.length === 0
        ? '<tr><td colspan="7" style="text-align:center;padding:40px;color:#9ca3af;"><i class="fas fa-inbox" style="font-size:32px;margin-bottom:8px;"></i><br>Nenhum componente cadastrado para este produto</td></tr>'
        : items.map((b, idx) => \`<tr>
          <td style="color:#9ca3af;font-size:12px;">\${idx+1}</td>
          <td style="font-weight:600;color:#374151;">\${b.componentName}</td>
          <td><span style="font-family:monospace;font-size:11px;background:#f1f5f9;padding:1px 6px;border-radius:4px;color:#6c757d;">\${b.componentCode || '—'}</span></td>
          <td style="font-weight:700;color:#1B4F72;">\${b.quantity}</td>
          <td><span class="chip" style="background:#f1f5f9;color:#374151;">\${b.unit}</span></td>
          <td style="font-size:12px;color:#9ca3af;">—</td>
          <td><div style="display:flex;gap:4px;"><button class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i></button><button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></div></td>
        </tr>\`).join('');
    }
  }

  function showBOM(code) {
    // Switch to BOM tab
    document.querySelectorAll('[data-tab-group="eng"] .tab-btn').forEach((b,i) => i === 1 ? b.classList.add('active') : b.classList.remove('active'));
    document.querySelectorAll('[data-tab-group="eng"] .tab-content').forEach((c,i) => i === 1 ? c.classList.add('active') : c.classList.remove('active'));
    selectBOMProduct(code);
  }

  function showRoteiro(code) {
    document.querySelectorAll('[data-tab-group="eng"] .tab-btn').forEach((b,i) => i === 2 ? b.classList.add('active') : b.classList.remove('active'));
    document.querySelectorAll('[data-tab-group="eng"] .tab-content').forEach((c,i) => i === 2 ? c.classList.add('active') : c.classList.remove('active'));
  }


  async function salvarBomItem() {
    const productId = document.getElementById('bom_produto')?.value || '';
    const productName = document.getElementById('bom_produto_nome')?.value || document.getElementById('bom_produto')?.options[document.getElementById('bom_produto')?.selectedIndex]?.text || '';
    const componentName = document.getElementById('bom_componente')?.value || '';
    const componentCode = document.getElementById('bom_codigo')?.value || '';
    const quantity = document.getElementById('bom_quantidade')?.value || 1;
    const unit = document.getElementById('bom_unidade')?.value || 'un';
    
    if (!productId || !componentName) { showToast('Selecione o produto e informe o componente!', 'error'); return; }
    
    try {
      const res = await fetch('/engenharia/api/bom/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId, productName, componentName, componentCode, quantity, unit })
      });
      const data = await res.json();
      if (data.ok) {
        showToast('✅ Componente adicionado à BOM!');
        closeModal('novoBomModal');
        setTimeout(() => location.reload(), 800);
      } else {
        showToast(data.error || 'Erro ao salvar', 'error');
      }
    } catch(e) { showToast('Erro de conexão', 'error'); }
  }

  async function deleteBomItem(id) {
    if (!confirm('Remover este componente da BOM?')) return;
    try {
      const res = await fetch('/engenharia/api/bom/' + id, { method: 'DELETE' });
      const data = await res.json();
      if (data.ok) { showToast('Componente removido!'); setTimeout(() => location.reload(), 500); }
      else showToast(data.error || 'Erro ao excluir', 'error');
    } catch(e) { showToast('Erro de conexão', 'error'); }
  }

  // ── Toast notification ────────────────────────────────────────────────────
  function showToast(msg, type = 'success') {
    const t = document.createElement('div');
    t.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;padding:12px 20px;border-radius:10px;font-size:13px;font-weight:600;color:white;box-shadow:0 4px 20px rgba(0,0,0,0.2);transition:opacity 0.3s;display:flex;align-items:center;gap:8px;max-width:360px;';
    t.style.background = type === 'success' ? '#27AE60' : type === 'error' ? '#E74C3C' : '#2980B9';
    t.innerHTML = (type === 'success' ? '<i class=\"fas fa-check-circle\"></i>' : type === 'error' ? '<i class=\"fas fa-exclamation-circle\"></i>' : '<i class=\"fas fa-info-circle\"></i>') + ' ' + msg;
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 300); }, 3500);
  }
  </script>
  `
  return c.html(layout('Engenharia de Produto', content, 'engenharia', userInfo))
})

// ── API: POST /engenharia/api/bom/create ─────────────────────────────────────
app.post('/api/bom/create', async (c) => {
  const db = getCtxDB(c); const userId = getCtxUserId(c); const tenant = getCtxTenant(c)
  const body = await c.req.json().catch(() => null)
  if (!body || !body.productId || !body.componentName) return err(c, 'Dados obrigatórios')
  const id = genId('bom')
  const bom = {
    id, productId: body.productId, productName: body.productName || '',
    componentId: body.componentId || '', componentName: body.componentName,
    componentCode: body.componentCode || '', quantity: parseFloat(body.quantity) || 1,
    unit: body.unit || 'un', notes: body.notes || '', createdAt: new Date().toISOString(),
  }
  // D1-first: inserir antes de atualizar memória (produção)
  if (db && userId !== 'demo-tenant') {
    const empresaId = getCtxEmpresaId(c)
    const inserted = await dbInsert(db, 'boms', {
      id, user_id: userId, empresa_id: empresaId, product_id: bom.productId, component_id: bom.componentId,
      component_name: bom.componentName, component_code: bom.componentCode,
      quantity: bom.quantity, unit: bom.unit, notes: bom.notes,
    })
    if (!inserted) {
      console.error(`[ENGENHARIA][BOM][CRÍTICO] Falha ao persistir BOM ${id} em D1`)
      return err(c, 'Erro ao salvar BOM no banco de dados', 500)
    }
    console.log(`[ENGENHARIA][BOM] BOM ${id} persistido em D1 com sucesso`)
  }
  // Atualizar memória apenas após sucesso do D1 (ou modo demo/sem db)
  tenant.bomItems.push(bom)
  return ok(c, { bom })
})

app.put('/api/bom/:id', async (c) => {
  const db = getCtxDB(c); const userId = getCtxUserId(c); const tenant = getCtxTenant(c)
  const id = c.req.param('id'); const body = await c.req.json().catch(() => null)
  if (!body) return err(c, 'Dados inválidos')
  const idx = tenant.bomItems.findIndex((b: any) => b.id === id)
  if (idx === -1) return err(c, 'Item de BOM não encontrado', 404)
  if (db && userId !== 'demo-tenant') {
    await dbUpdate(db, 'boms', id, userId, {
      component_name: body.componentName, quantity: body.quantity, unit: body.unit, notes: body.notes,
    })
  }
  Object.assign(tenant.bomItems[idx], body)
  return ok(c, { bom: tenant.bomItems[idx] })
})

app.delete('/api/bom/:id', async (c) => {
  const db = getCtxDB(c); const userId = getCtxUserId(c); const tenant = getCtxTenant(c)
  const id = c.req.param('id')
  const idx = tenant.bomItems.findIndex((b: any) => b.id === id)
  if (idx === -1) return err(c, 'Item não encontrado', 404)
  if (db && userId !== 'demo-tenant') await dbDelete(db, 'boms', id, userId)
  tenant.bomItems.splice(idx, 1)
  return ok(c)
})

app.get('/api/boms', (c) => ok(c, { boms: getCtxTenant(c).bomItems }))

// ── API: Roteiros ─────────────────────────────────────────────────────────────

// Helper: insert all steps for a roteiro into roteiro_operacoes
async function _insertRoteiroOperacoes(db: any, roteiroId: string, userId: string, empresaId: string | null, steps: any[], now: string) {
  for (let i = 0; i < steps.length; i++) {
    const step = steps[i]
    const stepId = genId('rop')
    await db.prepare(`
      INSERT INTO roteiro_operacoes (id, roteiro_id, user_id, empresa_id, order_index, operation, standard_time, resource_type, machine, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      stepId, roteiroId, userId, empresaId || null,
      step.order || i + 1, step.operation || '', step.standardTime || 0,
      step.resourceType || 'manual', step.machine || '', now
    ).run()
  }
}

app.post('/api/route/create', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  const tenant = getCtxTenant(c)
  const empresaId = getCtxEmpresaId(c)
  const body = await c.req.json().catch(() => null)
  if (!body || !body.name || !body.productId)
    return err(c, 'Nome e produto são obrigatórios')

  const id = genId('rot')
  const now = new Date().toISOString()
  const steps = Array.isArray(body.steps) ? body.steps : []
  const route = {
    id,
    name:        body.name,
    productId:   body.productId,
    productCode: body.productCode || '',
    productName: body.productName || '',
    version:     body.version     || '1.0',
    status:      body.status      || 'active',
    notes:       body.notes       || '',
    steps,
    isActive:    1,
    parentId:    null as string | null,
    createdAt:   now,
    updatedAt:   now,
  }

  // D1-first: persist to D1 before updating memory (production only)
  if (db && userId !== 'demo-tenant') {
    try {
      console.log(`[ENGENHARIA][ROTEIROS] Criando roteiro ${id} para ${userId}`)
      await db.prepare(`
        INSERT INTO roteiros (id, user_id, empresa_id, product_id, product_code, product_name, name, version, status, observacoes, is_active, parent_id, created_at, updated_at, created_by_user_id, updated_by_user_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NULL, ?, ?, ?, ?)
      `).bind(
        id, userId, empresaId || null, route.productId, route.productCode, route.productName,
        route.name, route.version, route.status, route.notes, now, now, userId, userId
      ).run()
      await _insertRoteiroOperacoes(db, id, userId, empresaId, steps, now)
      console.log(`[ENGENHARIA][ROTEIROS] Roteiro ${id} persistido em D1 com sucesso`)
    } catch (e) {
      console.error(`[ENGENHARIA][ROTEIROS][CRÍTICO] Falha ao persistir roteiro ${id} em D1:`, e)
      return err(c, 'Erro ao salvar roteiro no banco de dados', 500)
    }
  }

  // Update memory only after D1 success (or in demo/no-db mode)
  if (!tenant.routes) (tenant as any).routes = []
  tenant.routes.push(route)
  markTenantModified(userId)

  return ok(c, { route })
})

app.delete('/api/route/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  const tenant = getCtxTenant(c)
  const id = c.req.param('id')

  const idx = (tenant.routes || []).findIndex((r: any) => r.id === id)
  if (idx === -1) return err(c, 'Roteiro não encontrado', 404)

  // D1-first: delete from D1 before removing from memory (production only)
  if (db && userId !== 'demo-tenant') {
    try {
      console.log(`[ENGENHARIA][ROTEIROS] Deletando roteiro ${id} para ${userId}`)
      await db.prepare('DELETE FROM roteiro_operacoes WHERE roteiro_id = ? AND user_id = ?')
        .bind(id, userId).run()
      await db.prepare('DELETE FROM roteiros WHERE id = ? AND user_id = ?')
        .bind(id, userId).run()
      console.log(`[ENGENHARIA][ROTEIROS] Roteiro ${id} removido de D1 com sucesso`)
    } catch (e) {
      console.error(`[ENGENHARIA][ROTEIROS][CRÍTICO] Falha ao deletar roteiro ${id} em D1:`, e)
      return err(c, 'Erro ao remover roteiro do banco de dados', 500)
    }
  }

  // Remove from memory only after D1 success (or in demo/no-db mode)
  tenant.routes.splice(idx, 1)
  markTenantModified(userId)

  return ok(c)
})

app.put('/api/route/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  const tenant = getCtxTenant(c)
  const empresaId = getCtxEmpresaId(c)
  const id = c.req.param('id')
  const body = await c.req.json().catch(() => null)
  if (!body || !body.name || !body.productId)
    return err(c, 'Nome e produto são obrigatórios')

  const idx = (tenant.routes || []).findIndex((r: any) => r.id === id)
  if (idx === -1) return err(c, 'Roteiro não encontrado', 404)

  const now = new Date().toISOString()
  const existing = tenant.routes[idx]
  const updated = {
    ...existing,
    name:        body.name,
    productId:   body.productId,
    productCode: body.productCode ?? existing.productCode,
    productName: body.productName ?? existing.productName,
    version:     body.version     ?? existing.version,
    status:      body.status      ?? existing.status,
    notes:       body.notes       !== undefined ? body.notes : existing.notes,
    steps:       Array.isArray(body.steps) ? body.steps : existing.steps,
    updatedAt:   now,
  }

  // D1-first: update D1 before updating memory (production only)
  if (db && userId !== 'demo-tenant') {
    try {
      console.log(`[ENGENHARIA][ROTEIROS] Atualizando roteiro ${id} para ${userId}`)
      await db.prepare(`
        UPDATE roteiros SET name=?, product_code=?, product_name=?, version=?, status=?, product_id=?, observacoes=?, updated_at=?, updated_by_user_id=? WHERE id=? AND user_id=?
      `).bind(
        updated.name, updated.productCode, updated.productName, updated.version, updated.status,
        updated.productId, updated.notes, now, userId, id, userId
      ).run()
      // Replace steps: delete all then re-insert in new order
      await db.prepare('DELETE FROM roteiro_operacoes WHERE roteiro_id = ? AND user_id = ?')
        .bind(id, userId).run()
      await _insertRoteiroOperacoes(db, id, userId, empresaId, updated.steps, now)
      console.log(`[ENGENHARIA][ROTEIROS] Roteiro ${id} atualizado em D1 com sucesso`)
    } catch (e) {
      console.error(`[ENGENHARIA][ROTEIROS][CRÍTICO] Falha ao atualizar roteiro ${id} em D1:`, e)
      return err(c, 'Erro ao atualizar roteiro no banco de dados', 500)
    }
  }

  // Update memory only after D1 success (or in demo/no-db mode)
  tenant.routes[idx] = updated
  markTenantModified(userId)

  return ok(c, { route: updated })
})

// POST /engenharia/api/roteiros/:id/version
// Creates a new version of a roteiro, archiving the previous one (is_active=0).
app.post('/api/roteiros/:id/version', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  const tenant = getCtxTenant(c)
  const empresaId = getCtxEmpresaId(c)
  const parentId = c.req.param('id')
  const body = await c.req.json().catch(() => null)
  if (!body || !body.name || !body.productId)
    return err(c, 'Nome e produto são obrigatórios')

  const parentIdx = (tenant.routes || []).findIndex((r: any) => r.id === parentId)
  if (parentIdx === -1) return err(c, 'Roteiro não encontrado', 404)

  const parentRoute = tenant.routes[parentIdx]
  const newId = genId('rot')
  const now = new Date().toISOString()
  const steps = Array.isArray(body.steps) ? body.steps : (parentRoute.steps || [])

  const newRoute = {
    id: newId,
    name:        body.name,
    productId:   body.productId,
    productCode: body.productCode || parentRoute.productCode || '',
    productName: body.productName || parentRoute.productName || '',
    version:     body.version || '1.1',
    status:      body.status || 'active',
    notes:       body.notes !== undefined ? body.notes : (parentRoute.notes || ''),
    steps,
    isActive:    1,
    parentId:    parentId,
    createdAt:   now,
    updatedAt:   now,
  }

  // D1-first: archive old version and insert new one
  if (db && userId !== 'demo-tenant') {
    try {
      console.log(`[ENGENHARIA][ROTEIROS] Criando nova versão ${newId} a partir de ${parentId} para ${userId}`)
      // Archive parent: mark inactive and update audit
      await db.prepare(
        `UPDATE roteiros SET is_active=0, status='obsolete', updated_at=?, updated_by_user_id=? WHERE id=? AND user_id=?`
      ).bind(now, userId, parentId, userId).run()
      // Insert new version
      await db.prepare(`
        INSERT INTO roteiros (id, user_id, empresa_id, product_id, product_code, product_name, name, version, status, observacoes, is_active, parent_id, created_at, updated_at, created_by_user_id, updated_by_user_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?)
      `).bind(
        newId, userId, empresaId || null, newRoute.productId, newRoute.productCode, newRoute.productName,
        newRoute.name, newRoute.version, newRoute.status, newRoute.notes,
        parentId, now, now, userId, userId
      ).run()
      // Insert steps for new version
      await _insertRoteiroOperacoes(db, newId, userId, empresaId, steps, now)
      console.log(`[ENGENHARIA][ROTEIROS] Nova versão ${newId} criada em D1 com sucesso`)
    } catch (e) {
      console.error(`[ENGENHARIA][ROTEIROS][CRÍTICO] Falha ao criar nova versão em D1:`, e)
      return err(c, 'Erro ao criar nova versão no banco de dados', 500)
    }
  }

  // Update memory only after D1 success (or in demo/no-db mode)
  // Remove archived parent from active list in memory
  if (!tenant.routes) (tenant as any).routes = []
  tenant.routes.splice(parentIdx, 1)
  tenant.routes.push(newRoute)
  markTenantModified(userId)

  return ok(c, { route: newRoute })
})

app.get('/api/routes', (c) => ok(c, { routes: getCtxTenant(c).routes || [] }))

// GET /engenharia/api/roteiros/:id/history
// Returns the version history chain for a roteiro (newest → oldest).
app.get('/api/roteiros/:id/history', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  const tenant = getCtxTenant(c)
  const rotId = c.req.param('id')

  // In demo mode (no db), build history from in-memory routes
  if (!db || userId === 'demo-tenant') {
    const allRoutes: any[] = tenant.routes || []
    // Find the root of the chain by walking up parent_id
    let rootId = rotId
    const visited = new Set<string>()
    while (true) {
      if (visited.has(rootId)) break
      visited.add(rootId)
      const cur = allRoutes.find((r: any) => r.id === rootId)
      if (!cur || !cur.parentId) break
      rootId = cur.parentId
    }
    // Collect all nodes reachable from root (BFS)
    const collected: any[] = []
    const queue = [rootId]
    const seen = new Set<string>()
    while (queue.length > 0) {
      const cur = queue.shift()!
      if (seen.has(cur)) continue
      seen.add(cur)
      // include both active and archived (all routes in memory include only active ones; archived are removed)
      const node = allRoutes.find((r: any) => r.id === cur)
      if (node) {
        collected.push(node)
        allRoutes.filter((r: any) => r.parentId === cur).forEach((r: any) => queue.push(r.id))
      }
    }
    // Sort newest → oldest by createdAt
    collected.sort((a: any, b: any) => (b.createdAt || '1970-01-01').localeCompare(a.createdAt || '1970-01-01'))
    const history = collected.map((r: any) => ({
      id: r.id,
      version: r.version,
      createdAt: r.createdAt,
      updatedAt: r.updatedAt,
      createdByUserId: r.createdByUserId || null,
      updatedByUserId: r.updatedByUserId || null,
    }))
    return ok(c, { history })
  }

  // Production: query D1
  try {
    console.log(`[ENGENHARIA][ROTEIROS][HISTORY] Buscando histórico para ${rotId} usuario ${userId}`)
    // Step 1: find the root by walking up parent_id chain
    let rootId = rotId
    const visitedUp = new Set<string>()
    while (true) {
      if (visitedUp.has(rootId)) break
      visitedUp.add(rootId)
      const row = await db.prepare(
        `SELECT parent_id FROM roteiros WHERE id=? AND user_id=?`
      ).bind(rootId, userId).first<{ parent_id: string | null }>()
      if (!row || !row.parent_id) break
      rootId = row.parent_id
    }

    // Step 2: BFS from root collecting all descendants (active + archived)
    const allIds: string[] = []
    const queue = [rootId]
    const seenBFS = new Set<string>()
    while (queue.length > 0) {
      const cur = queue.shift()!
      if (seenBFS.has(cur)) continue
      seenBFS.add(cur)
      allIds.push(cur)
      const children = await db.prepare(
        `SELECT id FROM roteiros WHERE parent_id=? AND user_id=?`
      ).bind(cur, userId).all<{ id: string }>()
      for (const child of (children.results || [])) queue.push(child.id)
    }

    if (allIds.length === 0) return ok(c, { history: [] })

    // Step 3: fetch metadata for all collected ids
    const placeholders = allIds.map(() => '?').join(',')
    const rows = await db.prepare(
      `SELECT id, version, created_at, updated_at, created_by_user_id, updated_by_user_id FROM roteiros WHERE id IN (${placeholders}) AND user_id=? ORDER BY created_at DESC`
    ).bind(...allIds, userId).all<{
      id: string; version: string; created_at: string; updated_at: string;
      created_by_user_id: string | null; updated_by_user_id: string | null;
    }>()

    const history = (rows.results || []).map((r) => ({
      id: r.id,
      version: r.version,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
      createdByUserId: r.created_by_user_id,
      updatedByUserId: r.updated_by_user_id,
    }))

    console.log(`[ENGENHARIA][ROTEIROS][HISTORY] Retornando ${history.length} versão(ões) para ${rotId}`)
    return ok(c, { history })
  } catch (e) {
    console.error(`[ENGENHARIA][ROTEIROS][HISTORY][CRÍTICO] Falha ao buscar histórico de ${rotId}:`, e)
    return err(c, 'Erro ao buscar histórico de versões', 500)
  }
})

// ── API: POST /engenharia/api/product/create (removido) ─────────────────────
// Criação de produtos deve ser feita em /produtos (módulo oficial).
app.post('/api/product/create', (c) => {
  return c.json({ ok: false, error: 'A criação de produtos foi movida para /produtos. Use o módulo oficial de Produtos.' }, 410)
})

export default app
