import { Hono } from 'hono'
import { layout } from '../layout'
import { getCtxSession, getCtxDB, getCtxUserId, getCtxEmpresaId, getCtxUserInfo } from '../sessionHelper'
import { genId, dbInsert, dbUpdate, dbDelete } from '../dbHelpers'
function ok(data: any = {}) { return { ok: true, ...data } }
function err(msg: string) { return { ok: false, error: msg } }
import { requireModuleWriteAccess } from '../moduleAccess'

const app = new Hono()

// ── Write-guard middleware ────────────────────────────────────────────────────
app.use('*', async (c, next) => {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(c.req.method)) {
    const blocked = await requireModuleWriteAccess(c, 'exportacao')
    if (blocked) return blocked
  }
  return next()
})

// ── Helpers ──────────────────────────────────────────────────────────────────
function esc(s: any): string {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')
}
function fmtDate(d: string | null | undefined): string {
  if (!d) return '\u2014'
  try { return new Date(d + 'T12:00:00').toLocaleDateString('pt-BR') } catch { return d }
}
/** Serializa JSON de forma segura para uso em bloco <script> */
function safeJson(obj: any): string {
  return JSON.stringify(obj)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026')
    .replace(/'/g, '\\u0027')
}
function fmtMoeda(v: number, moeda = 'USD'): string {
  try {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: moeda }).format(v || 0)
  } catch {
    return `${moeda} ${(v || 0).toFixed(2)}`
  }
}
function fmtBRL(v: number): string { return fmtMoeda(v, 'BRL') }

// ── Auto-migração defensiva ───────────────────────────────────────────────────
async function ensureTables(db: D1Database) {
  const ddls = [
    `CREATE TABLE IF NOT EXISTS exp_clientes (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, empresa_id TEXT DEFAULT '1',
      razao_social TEXT NOT NULL, nome_fantasia TEXT, pais TEXT DEFAULT 'Brasil',
      cidade TEXT, estado TEXT, endereco TEXT, cep TEXT,
      tax_id TEXT, tipo_doc TEXT DEFAULT 'CNPJ', moeda TEXT DEFAULT 'USD',
      incoterm TEXT DEFAULT 'FOB', condicao_pgto TEXT DEFAULT '30 dias',
      limite_credito REAL DEFAULT 0, contato_nome TEXT, contato_email TEXT,
      contato_tel TEXT, contato_cargo TEXT, status TEXT DEFAULT 'ativo',
      categoria TEXT DEFAULT 'cliente', observacoes TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS exp_invoices (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, empresa_id TEXT DEFAULT '1',
      numero TEXT NOT NULL, cliente_id TEXT NOT NULL,
      data_emissao TEXT NOT NULL, data_embarque TEXT, data_vencimento TEXT,
      incoterm TEXT DEFAULT 'FOB', porto_origem TEXT, porto_destino TEXT,
      modal TEXT DEFAULT 'maritimo', transportadora TEXT, bl_awb TEXT,
      moeda TEXT DEFAULT 'USD', subtotal REAL DEFAULT 0, desconto REAL DEFAULT 0,
      frete REAL DEFAULT 0, seguro REAL DEFAULT 0, total REAL DEFAULT 0,
      total_brl REAL DEFAULT 0, taxa_cambio REAL DEFAULT 1,
      status TEXT DEFAULT 'rascunho', status_pgto TEXT DEFAULT 'pendente',
      ncm_principal TEXT, documentos TEXT DEFAULT '[]', observacoes TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS exp_invoice_items (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, empresa_id TEXT DEFAULT '1',
      invoice_id TEXT NOT NULL, produto_id TEXT, codigo TEXT NOT NULL,
      descricao TEXT NOT NULL, nome_en TEXT, ncm TEXT, quantidade REAL DEFAULT 1,
      unidade TEXT DEFAULT 'PC', peso_unit REAL DEFAULT 0, peso_total REAL DEFAULT 0,
      cbm_unit REAL DEFAULT 0,
      preco_unit REAL DEFAULT 0, desconto_pct REAL DEFAULT 0,
      preco_total REAL DEFAULT 0, pais_origem TEXT DEFAULT 'Brasil',
      created_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS exp_pagamentos (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, empresa_id TEXT DEFAULT '1',
      invoice_id TEXT NOT NULL, data_pgto TEXT NOT NULL, valor REAL NOT NULL,
      moeda TEXT DEFAULT 'USD', valor_brl REAL DEFAULT 0, taxa_cambio REAL DEFAULT 1,
      forma_pgto TEXT DEFAULT 'wire', banco_origem TEXT, referencia TEXT,
      observacoes TEXT, created_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS exp_proformas (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, empresa_id TEXT DEFAULT '1',
      numero TEXT NOT NULL, cliente_id TEXT NOT NULL,
      data_emissao TEXT NOT NULL, data_validade TEXT, incoterm TEXT DEFAULT 'FOB',
      moeda TEXT DEFAULT 'USD', total REAL DEFAULT 0,
      status TEXT DEFAULT 'ativa', invoice_id TEXT,
      itens TEXT DEFAULT '[]', observacoes TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    )`,
    `CREATE TABLE IF NOT EXISTS exp_produtos (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, empresa_id TEXT DEFAULT '1',
      codigo TEXT NOT NULL, nome_pt TEXT NOT NULL, nome_en TEXT,
      descricao_pt TEXT, descricao_en TEXT,
      ncm TEXT, hs_code TEXT,
      unidade TEXT DEFAULT 'PC', pais_origem TEXT DEFAULT 'Brasil',
      peso_bruto REAL DEFAULT 0, peso_liquido REAL DEFAULT 0, cbm REAL DEFAULT 0,
      preco_unit_usd REAL DEFAULT 0, preco_unit_brl REAL DEFAULT 0,
      categoria TEXT, marca TEXT, modelo TEXT,
      status TEXT DEFAULT 'ativo', observacoes TEXT,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    )`,
  ]
  for (const ddl of ddls) {
    try { await db.prepare(ddl).run() } catch {}
  }
  // Indexes
  const idxs = [
    'CREATE INDEX IF NOT EXISTS idx_exp_clientes_user ON exp_clientes(user_id)',
    'CREATE INDEX IF NOT EXISTS idx_exp_invoices_user ON exp_invoices(user_id)',
    'CREATE INDEX IF NOT EXISTS idx_exp_invoices_cliente ON exp_invoices(cliente_id)',
    'CREATE INDEX IF NOT EXISTS idx_exp_items_invoice ON exp_invoice_items(invoice_id)',
    'CREATE INDEX IF NOT EXISTS idx_exp_pgto_invoice ON exp_pagamentos(invoice_id)',
    'CREATE INDEX IF NOT EXISTS idx_exp_proformas_user ON exp_proformas(user_id)',
    'CREATE INDEX IF NOT EXISTS idx_exp_produtos_user ON exp_produtos(user_id)',
    'CREATE UNIQUE INDEX IF NOT EXISTS idx_exp_produtos_codigo ON exp_produtos(user_id, empresa_id, codigo)',
  ]
  for (const idx of idxs) { try { await db.prepare(idx).run() } catch {} }
}

// ── Loader D1-first ───────────────────────────────────────────────────────────
async function loadData(db: D1Database | null, userId: string) {
  if (!db) return { clientes: [], invoices: [], proformas: [], pagamentos: [], produtos: [] }
  try {
    await ensureTables(db)
    const [clientes, invoices, proformas, pagamentos, produtos] = await Promise.all([
      db.prepare('SELECT * FROM exp_clientes WHERE user_id=? ORDER BY razao_social ASC').bind(userId).all(),
      db.prepare('SELECT * FROM exp_invoices WHERE user_id=? ORDER BY created_at DESC').bind(userId).all(),
      db.prepare('SELECT * FROM exp_proformas WHERE user_id=? ORDER BY created_at DESC').bind(userId).all(),
      db.prepare('SELECT * FROM exp_pagamentos WHERE user_id=? ORDER BY data_pgto DESC').bind(userId).all(),
      db.prepare('SELECT * FROM exp_produtos WHERE user_id=? ORDER BY nome_pt ASC').bind(userId).all(),
    ])
    return {
      clientes: clientes.results || [],
      invoices: invoices.results || [],
      proformas: proformas.results || [],
      pagamentos: pagamentos.results || [],
      produtos: produtos.results || [],
    }
  } catch (e) {
    console.error('[EXPORTACAO] loadData error:', e)
    return { clientes: [], invoices: [], proformas: [], pagamentos: [], produtos: [] }
  }
}

// ── Status badges ─────────────────────────────────────────────────────────────
const INV_STATUS: Record<string, { label: string; color: string; bg: string }> = {
  rascunho:  { label: 'Rascunho',  color: '#6c757d', bg: '#f1f3f5' },
  emitida:   { label: 'Emitida',   color: '#2980B9', bg: '#e8f4fd' },
  aprovada:  { label: 'Aprovada',  color: '#27AE60', bg: '#d4edda' },
  embarcada: { label: 'Embarcada', color: '#8e44ad', bg: '#f5eef8' },
  entregue:  { label: 'Entregue',  color: '#16a34a', bg: '#dcfce7' },
  paga:      { label: 'Paga',      color: '#16a34a', bg: '#dcfce7' },
  cancelada: { label: 'Cancelada', color: '#dc2626', bg: '#fee2e2' },
}
const PGTO_STATUS: Record<string, { label: string; color: string; bg: string }> = {
  pendente:  { label: 'Pendente',  color: '#d97706', bg: '#fef9c3' },
  parcial:   { label: 'Parcial',   color: '#2980B9', bg: '#e8f4fd' },
  pago:      { label: 'Pago',      color: '#16a34a', bg: '#dcfce7' },
  vencido:   { label: 'Vencido',   color: '#dc2626', bg: '#fee2e2' },
  cancelado: { label: 'Cancelado', color: '#6c757d', bg: '#f1f3f5' },
}
const CLI_STATUS: Record<string, { label: string; color: string; bg: string }> = {
  ativo:      { label: 'Ativo',      color: '#16a34a', bg: '#dcfce7' },
  inativo:    { label: 'Inativo',    color: '#6c757d', bg: '#f1f3f5' },
  prospecto:  { label: 'Prospecto',  color: '#2980B9', bg: '#e8f4fd' },
  bloqueado:  { label: 'Bloqueado',  color: '#dc2626', bg: '#fee2e2' },
}
const PFORM_STATUS: Record<string, { label: string; color: string; bg: string }> = {
  ativa:      { label: 'Ativa',      color: '#2980B9', bg: '#e8f4fd' },
  expirada:   { label: 'Expirada',   color: '#6c757d', bg: '#f1f3f5' },
  aceita:     { label: 'Aceita',     color: '#16a34a', bg: '#dcfce7' },
  recusada:   { label: 'Recusada',   color: '#dc2626', bg: '#fee2e2' },
  convertida: { label: 'Convertida', color: '#8e44ad', bg: '#f5eef8' },
}
function badge(map: Record<string, any>, key: string): string {
  const m = map[key] || { label: key, color: '#6c757d', bg: '#f1f3f5' }
  return `<span class="badge" style="background:${m.bg};color:${m.color};">${esc(m.label)}</span>`
}

// ── Página principal GET / ───────────────────────────────────────────────────
app.get('/', async (c) => {
  const session = getCtxSession(c)
  if (!session) return c.redirect('/')
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  const userInfo = getCtxUserInfo(c)
  const { clientes, invoices, proformas, pagamentos, produtos } = await loadData(db, userId)

  // KPIs
  const totalInv = invoices.length
  const invAtivas = invoices.filter((i: any) => !['cancelada', 'paga'].includes(i.status))
  const totalUSD = invoices.filter((i: any) => i.moeda === 'USD').reduce((s: number, i: any) => s + (i.total || 0), 0)
  const totalBRL = invoices.reduce((s: number, i: any) => s + (i.total_brl || 0), 0)
  const totalPago = pagamentos.reduce((s: number, p: any) => s + (p.valor_brl || p.valor || 0), 0)
  const totalClientes = clientes.length
  const cliAtivos = clientes.filter((c: any) => c.status === 'ativo').length
  const totalProdutos = (produtos as any[]).length
  const produtosAtivos = (produtos as any[]).filter((p: any) => p.status === 'ativo').length

  const content = `
<div style="padding:24px;">

  <!-- KPIs -->
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;margin-bottom:24px;">
    <div class="kpi-card" style="border-left:4px solid #2980B9;">
      <div class="kpi-label"><i class="fas fa-file-invoice" style="color:#2980B9;margin-right:6px;"></i>Invoices</div>
      <div class="kpi-value">${totalInv}</div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px;">${invAtivas.length} em andamento</div>
    </div>
    <div class="kpi-card" style="border-left:4px solid #27AE60;">
      <div class="kpi-label"><i class="fas fa-dollar-sign" style="color:#27AE60;margin-right:6px;"></i>Faturado (USD)</div>
      <div class="kpi-value" style="font-size:20px;">${fmtMoeda(totalUSD)}</div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px;">${fmtBRL(totalBRL)} em BRL</div>
    </div>
    <div class="kpi-card" style="border-left:4px solid #16a34a;">
      <div class="kpi-label"><i class="fas fa-check-circle" style="color:#16a34a;margin-right:6px;"></i>Recebido (BRL)</div>
      <div class="kpi-value" style="font-size:20px;">${fmtBRL(totalPago)}</div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px;">${pagamentos.length} pagamentos</div>
    </div>
    <div class="kpi-card" style="border-left:4px solid #7c3aed;">
      <div class="kpi-label"><i class="fas fa-globe" style="color:#7c3aed;margin-right:6px;"></i>Clientes</div>
      <div class="kpi-value">${totalClientes}</div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px;">${cliAtivos} ativos</div>
    </div>
    <div class="kpi-card" style="border-left:4px solid #d97706;">
      <div class="kpi-label"><i class="fas fa-file-alt" style="color:#d97706;margin-right:6px;"></i>Proformas</div>
      <div class="kpi-value">${proformas.length}</div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px;">${proformas.filter((p: any) => p.status === 'ativa').length} ativas</div>
    </div>
    <div class="kpi-card" style="border-left:4px solid #16a34a;">
      <div class="kpi-label"><i class="fas fa-box-open" style="color:#16a34a;margin-right:6px;"></i>Produtos</div>
      <div class="kpi-value">${totalProdutos}</div>
      <div style="font-size:11px;color:#9ca3af;margin-top:4px;">${produtosAtivos} ativos</div>
    </div>
  </div>

  <!-- Abas -->
  <div style="display:flex;border-bottom:2px solid #e9ecef;margin-bottom:20px;overflow-x:auto;background:white;border-radius:12px 12px 0 0;padding:0 8px;">
    <button class="exp-tab active" data-tab="invoices" style="padding:10px 18px;font-size:13px;font-weight:600;border:none;background:none;cursor:pointer;color:#7c3aed;border-bottom:3px solid #7c3aed;white-space:nowrap;">
      <i class="fas fa-file-invoice" style="margin-right:6px;"></i>Invoices
    </button>
    <button class="exp-tab" data-tab="proformas" style="padding:10px 18px;font-size:13px;font-weight:600;border:none;background:none;cursor:pointer;color:#6c757d;border-bottom:3px solid transparent;white-space:nowrap;">
      <i class="fas fa-file-alt" style="margin-right:6px;"></i>Proformas
    </button>
    <button class="exp-tab" data-tab="clientes" style="padding:10px 18px;font-size:13px;font-weight:600;border:none;background:none;cursor:pointer;color:#6c757d;border-bottom:3px solid transparent;white-space:nowrap;">
      <i class="fas fa-address-book" style="margin-right:6px;"></i>Clientes
    </button>
    <button class="exp-tab" data-tab="pagamentos" style="padding:10px 18px;font-size:13px;font-weight:600;border:none;background:none;cursor:pointer;color:#6c757d;border-bottom:3px solid transparent;white-space:nowrap;">
      <i class="fas fa-money-bill-wave" style="margin-right:6px;"></i>Pagamentos
    </button>
    <button class="exp-tab" data-tab="produtos" style="padding:10px 18px;font-size:13px;font-weight:600;border:none;background:none;cursor:pointer;color:#6c757d;border-bottom:3px solid transparent;white-space:nowrap;">
      <i class="fas fa-box-open" style="margin-right:6px;"></i>Produtos Acabados
    </button>
  </div>

  <!-- Painel Invoices -->
  <div id="tab-invoices" class="exp-panel card" style="overflow:hidden;">
    <div style="padding:14px 18px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
      <span style="font-size:14px;font-weight:700;color:#1B4F72;"><i class="fas fa-file-invoice" style="color:#7c3aed;margin-right:8px;"></i>Commercial Invoices</span>
      <input type="text" id="searchInvoices" class="form-control" placeholder="🔍 Buscar invoice..." style="width:200px;margin-left:auto;" oninput="filterInvoices()">
      <select class="form-control" id="filterInvStatus" style="width:140px;" onchange="filterInvoices()">
        <option value="">Todos status</option>
        <option value="rascunho">Rascunho</option>
        <option value="emitida">Emitida</option>
        <option value="aprovada">Aprovada</option>
        <option value="embarcada">Embarcada</option>
        <option value="entregue">Entregue</option>
        <option value="paga">Paga</option>
      </select>
      <button class="btn btn-primary" onclick="openInvModal()"><i class="fas fa-plus"></i> Nova Invoice</button>
    </div>
    <div style="overflow-x:auto;">
      <table style="width:100%;border-collapse:collapse;font-size:13px;" id="invoicesTable">
        <thead><tr style="background:#f8f9fa;border-bottom:2px solid #e9ecef;">
          <th style="padding:10px 14px;text-align:left;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Nº Invoice</th>
          <th style="padding:10px 14px;text-align:left;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Cliente</th>
          <th style="padding:10px 14px;text-align:left;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Emissão</th>
          <th style="padding:10px 14px;text-align:left;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Embarque</th>
          <th style="padding:10px 14px;text-align:left;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Incoterm</th>
          <th style="padding:10px 14px;text-align:right;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Valor</th>
          <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Status</th>
          <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Pgto</th>
          <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Ações</th>
        </tr></thead>
        <tbody id="invoicesTbody">
          ${invoices.length === 0
            ? `<tr><td colspan="9" style="text-align:center;padding:32px;color:#9ca3af;"><i class="fas fa-file-invoice" style="font-size:32px;display:block;margin-bottom:8px;opacity:0.3;"></i>Nenhuma invoice cadastrada. Clique em "Nova Invoice" para começar.</td></tr>`
            : invoices.map((inv: any) => {
                const cli = clientes.find((cl: any) => cl.id === inv.cliente_id)
                const is = INV_STATUS[inv.status] || INV_STATUS.rascunho
                const ps = PGTO_STATUS[inv.status_pgto] || PGTO_STATUS.pendente
                return `<tr class="inv-row" data-status="${esc(inv.status)}" data-search="${esc(inv.numero.toLowerCase())} ${esc((cli?.razao_social||'').toLowerCase())}" style="border-bottom:1px solid #f1f3f5;">
                  <td style="padding:10px 14px;font-weight:700;color:#1B4F72;">${esc(inv.numero)}</td>
                  <td style="padding:10px 14px;">
                    <div style="font-weight:600;color:#374151;">${esc(cli?.razao_social || cli?.nome_fantasia || inv.cliente_id)}</div>
                    <div style="font-size:11px;color:#9ca3af;">${esc(cli?.pais || '—')}</div>
                  </td>
                  <td style="padding:10px 14px;color:#374151;">${fmtDate(inv.data_emissao)}</td>
                  <td style="padding:10px 14px;color:#374151;">${fmtDate(inv.data_embarque)}</td>
                  <td style="padding:10px 14px;font-weight:600;color:#374151;">${esc(inv.incoterm || '—')}</td>
                  <td style="padding:10px 14px;text-align:right;font-weight:700;color:#1B4F72;">${fmtMoeda(inv.total, inv.moeda)}</td>
                  <td style="padding:10px 14px;text-align:center;"><span class="badge" style="background:${is.bg};color:${is.color};">${esc(is.label)}</span></td>
                  <td style="padding:10px 14px;text-align:center;"><span class="badge" style="background:${ps.bg};color:${ps.color};">${esc(ps.label)}</span></td>
                  <td style="padding:10px 14px;text-align:center;">
                    <div style="display:flex;gap:4px;justify-content:center;">
                      <button class="btn btn-sm btn-secondary" onclick="openInvDetail('${esc(inv.id)}')" title="Ver detalhes"><i class="fas fa-eye"></i></button>
                      <button class="btn btn-sm" style="background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;" onclick="openPackingList('${esc(inv.id)}')" title="Packing List"><i class="fas fa-clipboard-list"></i></button>
                      <button class="btn btn-sm btn-secondary" onclick="openInvModal('${esc(inv.id)}')" title="Editar"><i class="fas fa-pencil-alt"></i></button>
                      <button class="btn btn-sm" style="background:#fee2e2;color:#dc2626;" onclick="deleteInvoice('${esc(inv.id)}','${esc(inv.numero)}')" title="Excluir"><i class="fas fa-trash"></i></button>
                    </div>
                  </td>
                </tr>`
              }).join('')
          }
        </tbody>
      </table>
    </div>
  </div>

  <!-- Painel Proformas -->
  <div id="tab-proformas" class="exp-panel card" style="overflow:hidden;display:none;">
    <div style="padding:14px 18px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
      <span style="font-size:14px;font-weight:700;color:#1B4F72;"><i class="fas fa-file-alt" style="color:#d97706;margin-right:8px;"></i>Proforma Invoices</span>
      <button class="btn btn-primary" style="margin-left:auto;" onclick="openProformaModal()"><i class="fas fa-plus"></i> Nova Proforma</button>
    </div>
    <div style="overflow-x:auto;">
      <table style="width:100%;border-collapse:collapse;font-size:13px;">
        <thead><tr style="background:#f8f9fa;border-bottom:2px solid #e9ecef;">
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Nº Proforma</th>
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Cliente</th>
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Emissão</th>
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Validade</th>
          <th style="padding:10px 14px;text-align:right;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Valor</th>
          <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Status</th>
          <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Ações</th>
        </tr></thead>
        <tbody>
          ${proformas.length === 0
            ? `<tr><td colspan="7" style="text-align:center;padding:32px;color:#9ca3af;"><i class="fas fa-file-alt" style="font-size:32px;display:block;margin-bottom:8px;opacity:0.3;"></i>Nenhuma proforma cadastrada.</td></tr>`
            : proformas.map((pf: any) => {
                const cli = clientes.find((cl: any) => cl.id === pf.cliente_id)
                const ps = PFORM_STATUS[pf.status] || PFORM_STATUS.ativa
                return `<tr style="border-bottom:1px solid #f1f3f5;">
                  <td style="padding:10px 14px;font-weight:700;color:#1B4F72;">${esc(pf.numero)}</td>
                  <td style="padding:10px 14px;font-weight:600;color:#374151;">${esc(cli?.razao_social || pf.cliente_id)}</td>
                  <td style="padding:10px 14px;color:#374151;">${fmtDate(pf.data_emissao)}</td>
                  <td style="padding:10px 14px;color:#374151;">${fmtDate(pf.data_validade)}</td>
                  <td style="padding:10px 14px;text-align:right;font-weight:700;color:#1B4F72;">${fmtMoeda(pf.total, pf.moeda)}</td>
                  <td style="padding:10px 14px;text-align:center;"><span class="badge" style="background:${ps.bg};color:${ps.color};">${esc(ps.label)}</span></td>
                  <td style="padding:10px 14px;text-align:center;">
                    <div style="display:flex;gap:4px;justify-content:center;">
                      <button class="btn btn-sm btn-secondary" onclick="openProformaModal('${esc(pf.id)}')" title="Editar"><i class="fas fa-pencil-alt"></i></button>
                      <button class="btn btn-sm btn-success" onclick="convertProforma('${esc(pf.id)}')" title="Converter em Invoice"><i class="fas fa-exchange-alt"></i> Invoice</button>
                    </div>
                  </td>
                </tr>`
              }).join('')
          }
        </tbody>
      </table>
    </div>
  </div>

  <!-- Painel Clientes -->
  <div id="tab-clientes" class="exp-panel card" style="overflow:hidden;display:none;">
    <div style="padding:14px 18px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
      <span style="font-size:14px;font-weight:700;color:#1B4F72;"><i class="fas fa-address-book" style="color:#7c3aed;margin-right:8px;"></i>Clientes de Exportação</span>
      <input type="text" id="searchClientes" class="form-control" placeholder="🔍 Buscar cliente..." style="width:200px;margin-left:auto;" oninput="filterClientes()">
      <button class="btn btn-primary" onclick="openClienteModal()"><i class="fas fa-plus"></i> Novo Cliente</button>
    </div>
    <div style="overflow-x:auto;">
      <table style="width:100%;border-collapse:collapse;font-size:13px;" id="clientesTable">
        <thead><tr style="background:#f8f9fa;border-bottom:2px solid #e9ecef;">
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Razão Social</th>
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">País</th>
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Categoria</th>
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Moeda</th>
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Incoterm</th>
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Contato</th>
          <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Status</th>
          <th style="padding:10px 14px;text-align:center;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Ações</th>
        </tr></thead>
        <tbody id="clientesTbody">
          ${clientes.length === 0
            ? `<tr><td colspan="8" style="text-align:center;padding:32px;color:#9ca3af;"><i class="fas fa-globe" style="font-size:32px;display:block;margin-bottom:8px;opacity:0.3;"></i>Nenhum cliente cadastrado.</td></tr>`
            : clientes.map((cl: any) => {
                const cs = CLI_STATUS[cl.status] || CLI_STATUS.ativo
                const invCount = invoices.filter((i: any) => i.cliente_id === cl.id).length
                return `<tr class="cli-row" data-search="${esc(cl.razao_social.toLowerCase())} ${esc((cl.pais||'').toLowerCase())}" style="border-bottom:1px solid #f1f3f5;">
                  <td style="padding:10px 14px;">
                    <div style="font-weight:700;color:#1B4F72;">${esc(cl.razao_social)}</div>
                    <div style="font-size:11px;color:#9ca3af;">${esc(cl.nome_fantasia || '')} ${cl.tax_id ? '· '+esc(cl.tipo_doc)+': '+esc(cl.tax_id) : ''}</div>
                  </td>
                  <td style="padding:10px 14px;font-weight:600;color:#374151;">${esc(cl.pais)}</td>
                  <td style="padding:10px 14px;color:#374151;text-transform:capitalize;">${esc(cl.categoria)}</td>
                  <td style="padding:10px 14px;font-weight:600;color:#2980B9;">${esc(cl.moeda)}</td>
                  <td style="padding:10px 14px;color:#374151;">${esc(cl.incoterm)}</td>
                  <td style="padding:10px 14px;">
                    <div style="font-size:12px;color:#374151;">${esc(cl.contato_nome || '—')}</div>
                    <div style="font-size:11px;color:#9ca3af;">${esc(cl.contato_email || '')}</div>
                  </td>
                  <td style="padding:10px 14px;text-align:center;"><span class="badge" style="background:${cs.bg};color:${cs.color};">${esc(cs.label)}</span></td>
                  <td style="padding:10px 14px;text-align:center;">
                    <div style="display:flex;gap:4px;justify-content:center;">
                      <button class="btn btn-sm btn-secondary" onclick="openClienteModal('${esc(cl.id)}')" title="Editar"><i class="fas fa-pencil-alt"></i></button>
                      <button class="btn btn-sm" style="background:#fee2e2;color:#dc2626;" onclick="deleteCliente('${esc(cl.id)}','${esc(cl.razao_social)}')" title="Excluir"><i class="fas fa-trash"></i></button>
                    </div>
                  </td>
                </tr>`
              }).join('')
          }
        </tbody>
      </table>
    </div>
  </div>

  <!-- Painel Pagamentos -->
  <div id="tab-pagamentos" class="exp-panel card" style="overflow:hidden;display:none;">
    <div style="padding:14px 18px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
      <span style="font-size:14px;font-weight:700;color:#1B4F72;"><i class="fas fa-money-bill-wave" style="color:#27AE60;margin-right:8px;"></i>Registro de Pagamentos</span>
      <button class="btn btn-primary" style="margin-left:auto;" onclick="openPgtoModal()"><i class="fas fa-plus"></i> Registrar Pagamento</button>
    </div>
    <div style="overflow-x:auto;">
      <table style="width:100%;border-collapse:collapse;font-size:13px;">
        <thead><tr style="background:#f8f9fa;border-bottom:2px solid #e9ecef;">
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Invoice</th>
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Cliente</th>
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Data Pgto</th>
          <th style="padding:10px 14px;text-align:right;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Valor</th>
          <th style="padding:10px 14px;text-align:right;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Valor BRL</th>
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Forma</th>
          <th style="padding:10px 14px;font-size:11px;color:#6c757d;text-transform:uppercase;font-weight:700;">Referência</th>
        </tr></thead>
        <tbody>
          ${pagamentos.length === 0
            ? `<tr><td colspan="7" style="text-align:center;padding:32px;color:#9ca3af;"><i class="fas fa-money-bill" style="font-size:32px;display:block;margin-bottom:8px;opacity:0.3;"></i>Nenhum pagamento registrado.</td></tr>`
            : pagamentos.map((p: any) => {
                const inv = invoices.find((i: any) => i.id === p.invoice_id)
                const cli = inv ? clientes.find((cl: any) => cl.id === inv.cliente_id) : null
                return `<tr style="border-bottom:1px solid #f1f3f5;">
                  <td style="padding:10px 14px;font-weight:700;color:#1B4F72;">${esc(inv?.numero || p.invoice_id)}</td>
                  <td style="padding:10px 14px;color:#374151;">${esc(cli?.razao_social || '—')}</td>
                  <td style="padding:10px 14px;color:#374151;">${fmtDate(p.data_pgto)}</td>
                  <td style="padding:10px 14px;text-align:right;font-weight:700;color:#16a34a;">${fmtMoeda(p.valor, p.moeda)}</td>
                  <td style="padding:10px 14px;text-align:right;color:#374151;">${p.valor_brl ? fmtBRL(p.valor_brl) : '—'}</td>
                  <td style="padding:10px 14px;color:#374151;text-transform:capitalize;">${esc(p.forma_pgto || '—')}</td>
                  <td style="padding:10px 14px;color:#6c757d;font-size:12px;">${esc(p.referencia || '—')}</td>
                </tr>`
              }).join('')
          }
        </tbody>
      </table>
    </div>
  </div>

  <!-- Painel Produtos Acabados -->
  <div id="tab-produtos" class="exp-panel card" style="overflow:hidden;display:none;">
    <div style="padding:14px 18px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
      <span style="font-size:14px;font-weight:700;color:#1B4F72;"><i class="fas fa-box-open" style="color:#16a34a;margin-right:8px;"></i>Produtos Acabados para Exportação</span>
      <input type="text" id="searchProdutos" class="form-control" placeholder="🔍 Filtrar produto..." style="width:200px;margin-left:auto;" oninput="filterExpProdutos()">
      <select class="form-control" id="filterProdStatus" style="width:120px;" onchange="filterExpProdutos()">
        <option value="">Todos</option>
        <option value="ativo">Ativo</option>
        <option value="inativo">Inativo</option>
      </select>
      <button class="btn btn-secondary" onclick="openExpProdCsvModal()"><i class="fas fa-file-csv"></i> Importar CSV</button>
      <button class="btn btn-primary" onclick="openExpProdModal()"><i class="fas fa-plus"></i> Novo Produto</button>
    </div>

    <!-- Stats rápidos -->
    <div style="padding:12px 18px;background:#f8fafc;border-bottom:1px solid #f1f3f5;display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;">
      <div style="background:white;border-radius:8px;padding:10px 14px;border-left:3px solid #16a34a;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
        <div style="font-size:20px;font-weight:800;color:#16a34a;">${produtos.length}</div>
        <div style="font-size:11px;color:#6c757d;">Produtos cadastrados</div>
      </div>
      <div style="background:white;border-radius:8px;padding:10px 14px;border-left:3px solid #7c3aed;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
        <div style="font-size:20px;font-weight:800;color:#7c3aed;">${(produtos as any[]).filter((p: any) => p.ncm).length}</div>
        <div style="font-size:11px;color:#6c757d;">Com NCM cadastrado</div>
      </div>
      <div style="background:white;border-radius:8px;padding:10px 14px;border-left:3px solid #2980B9;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
        <div style="font-size:20px;font-weight:800;color:#2980B9;">${(produtos as any[]).filter((p: any) => p.peso_bruto > 0).length}</div>
        <div style="font-size:11px;color:#6c757d;">Com dados físicos</div>
      </div>
      <div style="background:white;border-radius:8px;padding:10px 14px;border-left:3px solid #d97706;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
        <div style="font-size:20px;font-weight:800;color:#d97706;">${(produtos as any[]).filter((p: any) => !p.ncm || !p.nome_en || !p.peso_bruto).length}</div>
        <div style="font-size:11px;color:#6c757d;">Pendentes de completar</div>
      </div>
    </div>

    <div style="overflow-x:auto;">
      <table style="width:100%;border-collapse:collapse;font-size:12px;" id="produtosTable">
        <thead>
          <tr style="background:#1B4F72;color:white;">
            <th style="padding:10px 12px;text-align:left;white-space:nowrap;width:100px;">Código</th>
            <th style="padding:10px 12px;text-align:left;">Nome PT <span style="font-size:9px;opacity:0.8;">(clique p/ editar)</span></th>
            <th style="padding:10px 12px;text-align:left;font-style:italic;">Nome EN <span style="font-size:9px;opacity:0.8;">(clique p/ editar)</span></th>
            <th style="padding:10px 12px;text-align:left;width:110px;">NCM <span style="font-size:9px;opacity:0.8;">(clique p/ editar)</span></th>
            <th style="padding:10px 12px;text-align:left;width:90px;">HS Code</th>
            <th style="padding:10px 12px;text-align:center;white-space:nowrap;">Peso Bruto</th>
            <th style="padding:10px 12px;text-align:center;white-space:nowrap;">Peso Líq.</th>
            <th style="padding:10px 12px;text-align:center;white-space:nowrap;">CBM</th>
            <th style="padding:10px 12px;text-align:right;white-space:nowrap;">Preço (USD)</th>
            <th style="padding:10px 12px;text-align:center;white-space:nowrap;">Origem</th>
            <th style="padding:10px 12px;text-align:center;">Status</th>
            <th style="padding:10px 12px;text-align:center;">Ações</th>
          </tr>
        </thead>
        <tbody id="produtosTbody">
          ${(produtos as any[]).length === 0
            ? `<tr><td colspan="12" style="text-align:center;padding:32px;color:#9ca3af;"><i class="fas fa-box-open" style="font-size:32px;display:block;margin-bottom:8px;opacity:0.3;"></i>Nenhum produto cadastrado. Clique em "Novo Produto" para começar.</td></tr>`
            : (produtos as any[]).map((p: any) => {
                const temFisico = p.peso_bruto > 0
                const temNCM = !!p.ncm
                const temEN = !!p.nome_en
                const completo = temFisico && temNCM && temEN
                const statusColor = p.status === 'ativo' ? { c: '#16a34a', bg: '#dcfce7' } : { c: '#6c757d', bg: '#f1f3f5' }
                return `<tr class="prod-exp-row" data-status="${esc(p.status)}" data-search="${esc((p.codigo||'').toLowerCase())} ${esc((p.nome_pt||'').toLowerCase())} ${esc((p.nome_en||'').toLowerCase())} ${esc((p.ncm||'').toLowerCase())}" style="border-bottom:1px solid #f1f3f5;" onmouseenter="this.style.background='#f0fdf4'" onmouseleave="this.style.background='white'">
                  <td style="padding:8px 12px;font-family:monospace;font-size:11px;background:#f0fdf4;color:#166534;font-weight:700;white-space:nowrap;">${esc(p.codigo)}</td>
                  <td style="padding:8px 12px;max-width:180px;">
                    <div style="font-size:12px;font-weight:700;color:#1B4F72;cursor:pointer;text-decoration:underline dotted;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="Clique para editar dados físicos" data-prod-id="${esc(p.id)}" onclick="openExpProdModal(this.dataset.prodId)">
                      ${esc(p.nome_pt)}
                      ${!completo ? '<i class="fas fa-exclamation-circle" style="font-size:9px;color:#d97706;margin-left:3px;" title="Dados incompletos"></i>' : '<i class="fas fa-check-circle" style="font-size:9px;color:#16a34a;margin-left:3px;" title="Cadastro completo"></i>'}
                    </div>
                    ${p.categoria ? `<div style="font-size:10px;color:#9ca3af;">${esc(p.categoria)}</div>` : ''}
                  </td>
                  <td style="padding:8px 12px;max-width:180px;font-style:italic;">
                    <span style="font-size:12px;color:${temEN ? '#374151' : '#dc2626'};cursor:pointer;" title="Clique para editar" data-prod-id="${esc(p.id)}" onclick="openExpProdModal(this.dataset.prodId)">
                      ${p.nome_en ? esc(p.nome_en) : '<span style="font-style:italic;font-size:11px;color:#dc2626;">— preencher —</span>'}
                    </span>
                  </td>
                  <td style="padding:8px 12px;font-family:monospace;font-weight:700;color:${temNCM ? '#7c3aed' : '#dc2626'};">
                    ${p.ncm ? esc(p.ncm) : '<span style="font-size:11px;font-family:sans-serif;color:#dc2626;">— preencher —</span>'}
                  </td>
                  <td style="padding:8px 12px;font-family:monospace;font-size:11px;color:#374151;">${p.hs_code ? esc(p.hs_code) : '<span style="color:#9ca3af;">—</span>'}</td>
                  <td style="padding:8px 12px;text-align:center;font-size:12px;color:${temFisico ? '#374151' : '#dc2626'};">${p.peso_bruto > 0 ? (p.peso_bruto).toFixed(3)+' kg' : '—'}</td>
                  <td style="padding:8px 12px;text-align:center;font-size:12px;color:#374151;">${p.peso_liquido > 0 ? (p.peso_liquido).toFixed(3)+' kg' : '—'}</td>
                  <td style="padding:8px 12px;text-align:center;font-size:12px;color:#374151;">${p.cbm > 0 ? (p.cbm).toFixed(4)+' m³' : '—'}</td>
                  <td style="padding:8px 12px;text-align:right;font-weight:700;color:#1B4F72;">${p.preco_unit_usd > 0 ? fmtMoeda(p.preco_unit_usd) : '—'}</td>
                  <td style="padding:8px 12px;text-align:center;font-size:11px;color:#374151;">${esc(p.pais_origem || 'Brasil')}</td>
                  <td style="padding:8px 12px;text-align:center;"><span class="badge" style="background:${statusColor.bg};color:${statusColor.c};">${p.status === 'ativo' ? 'Ativo' : 'Inativo'}</span></td>
                  <td style="padding:8px 12px;text-align:center;">
                    <div style="display:flex;gap:4px;justify-content:center;">
                      <button class="btn btn-sm btn-secondary" data-prod-id="${esc(p.id)}" onclick="openExpProdModal(this.dataset.prodId)" title="Editar"><i class="fas fa-pencil-alt"></i></button>
                      <button class="btn btn-sm" style="background:#fee2e2;color:#dc2626;" data-prod-id="${esc(p.id)}" data-prod-nome="${esc(p.nome_pt)}" onclick="deleteExpProd(this.dataset.prodId, this.dataset.prodNome)" title="Excluir"><i class="fas fa-trash"></i></button>
                    </div>
                  </td>
                </tr>`
              }).join('')
          }
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal Produto de Exportação -->
<div class="modal-overlay" id="expProdModal">
  <div class="modal" style="max-width:700px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:white;z-index:1;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;" id="expProdModalTitle"><i class="fas fa-box-open" style="color:#16a34a;margin-right:8px;"></i>Novo Produto</h3>
      <button onclick="closeModal('expProdModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div style="padding:22px;overflow-y:auto;max-height:75vh;">
      <input type="hidden" id="expProd_id">

      <!-- Identificação -->
      <div style="font-size:12px;font-weight:700;color:#7c3aed;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:12px;padding-bottom:6px;border-bottom:2px solid #ede9fe;">
        <i class="fas fa-tag" style="margin-right:6px;"></i>Identificação
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px;">
        <div><label class="form-label">Código do Produto *</label><input class="form-control" id="expProd_codigo" placeholder="EXP-001 / SKU-ABC"></div>
        <div><label class="form-label">Categoria</label><input class="form-control" id="expProd_categoria" placeholder="Eletrônico, Têxtil, Metal..."></div>
        <div style="grid-column:span 2;"><label class="form-label">Nome em Português *</label><input class="form-control" id="expProd_nome_pt" placeholder="Nome comercial completo do produto"></div>
        <div style="grid-column:span 2;"><label class="form-label">Nome em Inglês (para documentos de exportação)</label><input class="form-control" id="expProd_nome_en" placeholder="Full commercial name in English" style="font-style:italic;"></div>
        <div><label class="form-label">Marca</label><input class="form-control" id="expProd_marca" placeholder="Marca do produto"></div>
        <div><label class="form-label">Modelo / Referência</label><input class="form-control" id="expProd_modelo" placeholder="Modelo ou referência"></div>
      </div>

      <!-- Classificação Fiscal -->
      <div style="font-size:12px;font-weight:700;color:#7c3aed;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:12px;padding-bottom:6px;border-bottom:2px solid #ede9fe;">
        <i class="fas fa-barcode" style="margin-right:6px;"></i>Classificação Fiscal
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px;">
        <div>
          <label class="form-label">NCM (Nomenclatura Comum do Mercosul)</label>
          <input class="form-control" id="expProd_ncm" placeholder="0000.00.00 — 8 dígitos" style="font-family:monospace;font-weight:700;">
          <div style="font-size:10px;color:#6c757d;margin-top:3px;">Formato: 0000.00.00 — usado na NF-e e RE</div>
        </div>
        <div>
          <label class="form-label">HS Code (Harmonized System)</label>
          <input class="form-control" id="expProd_hs_code" placeholder="000000 — 6 dígitos" style="font-family:monospace;">
          <div style="font-size:10px;color:#6c757d;margin-top:3px;">Código internacional — primeiros 6 dígitos do NCM</div>
        </div>
        <div>
          <label class="form-label">País de Origem</label>
          <input class="form-control" id="expProd_pais_origem" value="Brasil" placeholder="Brasil">
        </div>
        <div>
          <label class="form-label">Unidade de Medida</label>
          <select class="form-control" id="expProd_unidade">
            <option value="PC">PC — Peça</option>
            <option value="UN">UN — Unidade</option>
            <option value="KG">KG — Quilograma</option>
            <option value="MT">MT — Metro</option>
            <option value="M2">M2 — Metro Quadrado</option>
            <option value="M3">M3 — Metro Cúbico</option>
            <option value="LT">LT — Litro</option>
            <option value="CX">CX — Caixa</option>
            <option value="DZ">DZ — Dúzia</option>
            <option value="SET">SET — Conjunto</option>
          </select>
        </div>
      </div>

      <!-- Descrições Técnicas -->
      <div style="font-size:12px;font-weight:700;color:#7c3aed;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:12px;padding-bottom:6px;border-bottom:2px solid #ede9fe;">
        <i class="fas fa-align-left" style="margin-right:6px;"></i>Descrições Técnicas
      </div>
      <div style="display:grid;grid-template-columns:1fr;gap:14px;margin-bottom:18px;">
        <div>
          <label class="form-label">Descrição Técnica em Português</label>
          <textarea class="form-control" id="expProd_descricao_pt" rows="2" placeholder="Descrição técnica detalhada para documentos nacionais (NF-e, DU-E...)"></textarea>
        </div>
        <div>
          <label class="form-label">Descrição Técnica em Inglês (Invoice / Packing List)</label>
          <textarea class="form-control" id="expProd_descricao_en" rows="2" placeholder="Technical description in English for Commercial Invoice and Packing List..." style="font-style:italic;"></textarea>
        </div>
      </div>

      <!-- Dados Físicos -->
      <div style="font-size:12px;font-weight:700;color:#7c3aed;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:12px;padding-bottom:6px;border-bottom:2px solid #ede9fe;">
        <i class="fas fa-weight" style="margin-right:6px;"></i>Dados Físicos (por unidade)
      </div>
      <div style="background:#f0fdf4;border-radius:8px;padding:14px;margin-bottom:18px;">
        <div style="font-size:11px;color:#166534;margin-bottom:12px;"><i class="fas fa-info-circle" style="margin-right:4px;"></i>Dados utilizados no Packing List e cálculo de frete. Informe os valores por unidade vendida.</div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;">
          <div>
            <label class="form-label">Peso Bruto (kg)</label>
            <input class="form-control" type="number" step="0.001" min="0" id="expProd_peso_bruto" placeholder="0.000">
          </div>
          <div>
            <label class="form-label">Peso Líquido (kg)</label>
            <input class="form-control" type="number" step="0.001" min="0" id="expProd_peso_liquido" placeholder="0.000">
          </div>
          <div>
            <label class="form-label">CBM — Volume (m³)</label>
            <input class="form-control" type="number" step="0.0001" min="0" id="expProd_cbm" placeholder="0.0000">
            <div style="font-size:10px;color:#6c757d;margin-top:3px;">Comprimento × Largura × Altura</div>
          </div>
        </div>
      </div>

      <!-- Preços de Referência -->
      <div style="font-size:12px;font-weight:700;color:#7c3aed;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:12px;padding-bottom:6px;border-bottom:2px solid #ede9fe;">
        <i class="fas fa-dollar-sign" style="margin-right:6px;"></i>Preços de Referência
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px;">
        <div>
          <label class="form-label">Preço Unitário (USD)</label>
          <input class="form-control" type="number" step="0.01" min="0" id="expProd_preco_usd" placeholder="0.00">
        </div>
        <div>
          <label class="form-label">Preço Unitário (BRL)</label>
          <input class="form-control" type="number" step="0.01" min="0" id="expProd_preco_brl" placeholder="0.00">
        </div>
      </div>

      <!-- Status e Observações -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
        <div>
          <label class="form-label">Status</label>
          <select class="form-control" id="expProd_status">
            <option value="ativo">Ativo</option>
            <option value="inativo">Inativo</option>
          </select>
        </div>
        <div style="grid-column:span 1;"></div>
        <div style="grid-column:span 2;">
          <label class="form-label">Observações</label>
          <textarea class="form-control" id="expProd_obs" rows="2" placeholder="Observações internas, notas de embalagem, restrições de exportação..."></textarea>
        </div>
      </div>
    </div>
    <div style="padding:14px 22px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;position:sticky;bottom:0;background:white;">
      <button class="btn btn-secondary" onclick="closeModal('expProdModal')">Cancelar</button>
      <button class="btn btn-primary" onclick="saveExpProd()"><i class="fas fa-save"></i> Salvar Produto</button>
    </div>
  </div>
</div>

<!-- Modal Invoice -->
<div class="modal-overlay" id="invModal">
  <div class="modal" style="max-width:700px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:white;z-index:1;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;" id="invModalTitle"><i class="fas fa-file-invoice" style="color:#7c3aed;margin-right:8px;"></i>Nova Invoice</h3>
      <button onclick="closeModal('invModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div style="padding:22px;display:grid;grid-template-columns:1fr 1fr;gap:14px;">
      <input type="hidden" id="inv_id">
      <div><label class="form-label">Nº Invoice *</label><input class="form-control" id="inv_numero" placeholder="INV-2025-001"></div>
      <div><label class="form-label">Cliente *</label>
        <select class="form-control" id="inv_cliente">
          <option value="">Selecione o cliente...</option>
          ${clientes.map((cl: any) => `<option value="${esc(cl.id)}">${esc(cl.razao_social)}</option>`).join('')}
        </select>
      </div>
      <div><label class="form-label">Data Emissão *</label><input class="form-control" type="date" id="inv_data_emissao"></div>
      <div><label class="form-label">Data Embarque</label><input class="form-control" type="date" id="inv_data_embarque"></div>
      <div><label class="form-label">Data Vencimento</label><input class="form-control" type="date" id="inv_data_vencimento"></div>
      <div><label class="form-label">Incoterm</label>
        <select class="form-control" id="inv_incoterm">
          <option>EXW</option><option>FCA</option><option selected>FOB</option><option>CFR</option>
          <option>CIF</option><option>CPT</option><option>CIP</option><option>DAP</option>
          <option>DPU</option><option>DDP</option>
        </select>
      </div>
      <div><label class="form-label">Moeda</label>
        <select class="form-control" id="inv_moeda">
          <option value="USD" selected>USD — Dólar Americano</option>
          <option value="EUR">EUR — Euro</option>
          <option value="GBP">GBP — Libra Esterlina</option>
          <option value="BRL">BRL — Real Brasileiro</option>
        </select>
      </div>
      <div><label class="form-label">Modal Transporte</label>
        <select class="form-control" id="inv_modal">
          <option value="maritimo" selected>Marítimo</option>
          <option value="aereo">Aéreo</option>
          <option value="rodoviario">Rodoviário</option>
          <option value="ferroviario">Ferroviário</option>
        </select>
      </div>
      <div><label class="form-label">Porto/Local Origem</label><input class="form-control" id="inv_porto_origem" placeholder="Santos, SP"></div>
      <div><label class="form-label">Porto/Local Destino</label><input class="form-control" id="inv_porto_destino" placeholder="Los Angeles, CA"></div>
      <div><label class="form-label">Transportadora</label><input class="form-control" id="inv_transportadora" placeholder="Nome da transportadora"></div>
      <div><label class="form-label">BL / AWB</label><input class="form-control" id="inv_bl_awb" placeholder="Número do BL ou AWB"></div>
      <div><label class="form-label">Subtotal (${'moeda'})</label><input class="form-control" type="number" step="0.01" id="inv_subtotal" oninput="calcInvTotal()"></div>
      <div><label class="form-label">Desconto</label><input class="form-control" type="number" step="0.01" id="inv_desconto" value="0" oninput="calcInvTotal()"></div>
      <div><label class="form-label">Frete</label><input class="form-control" type="number" step="0.01" id="inv_frete" value="0" oninput="calcInvTotal()"></div>
      <div><label class="form-label">Seguro</label><input class="form-control" type="number" step="0.01" id="inv_seguro" value="0" oninput="calcInvTotal()"></div>
      <div><label class="form-label">Taxa de Câmbio (para BRL)</label><input class="form-control" type="number" step="0.0001" id="inv_taxa_cambio" value="5.80" oninput="calcInvTotal()"></div>
      <div><label class="form-label">Total Calculado</label><input class="form-control" id="inv_total_display" readonly style="background:#f8f9fa;font-weight:700;"></div>
      <div><label class="form-label">Status Invoice</label>
        <select class="form-control" id="inv_status">
          <option value="rascunho">Rascunho</option>
          <option value="emitida">Emitida</option>
          <option value="aprovada">Aprovada</option>
          <option value="embarcada">Embarcada</option>
          <option value="entregue">Entregue</option>
          <option value="paga">Paga</option>
          <option value="cancelada">Cancelada</option>
        </select>
      </div>
      <div><label class="form-label">Status Pagamento</label>
        <select class="form-control" id="inv_status_pgto">
          <option value="pendente">Pendente</option>
          <option value="parcial">Parcial</option>
          <option value="pago">Pago</option>
          <option value="vencido">Vencido</option>
          <option value="cancelado">Cancelado</option>
        </select>
      </div>
      <div style="grid-column:span 2;"><label class="form-label">Observações</label><textarea class="form-control" id="inv_obs" rows="2" placeholder="Observações adicionais..."></textarea></div>
    </div>

    <!-- Seção de Itens da Invoice -->
    <div style="padding:0 22px 18px;">
      <div style="font-size:12px;font-weight:700;color:#7c3aed;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:12px;padding-bottom:6px;border-bottom:2px solid #ede9fe;display:flex;align-items:center;justify-content:space-between;">
        <span><i class="fas fa-list" style="margin-right:6px;"></i>Itens da Invoice</span>
        <button type="button" class="btn btn-secondary" style="font-size:12px;padding:4px 10px;" onclick="addInvItem()"><i class="fas fa-plus"></i> Adicionar Item</button>
      </div>
      <div style="overflow-x:auto;">
        <table style="width:100%;border-collapse:collapse;font-size:12px;" id="invItemsTable">
          <thead><tr style="background:#f8f9fa;">
            <th style="padding:7px 8px;text-align:left;font-size:11px;color:#6c757d;font-weight:700;">Produto</th>
            <th style="padding:7px 8px;text-align:left;font-size:11px;color:#6c757d;font-weight:700;width:70px;">Código</th>
            <th style="padding:7px 8px;text-align:left;font-size:11px;color:#6c757d;font-weight:700;">Descrição EN</th>
            <th style="padding:7px 8px;text-align:left;font-size:11px;color:#6c757d;font-weight:700;width:90px;">NCM</th>
            <th style="padding:7px 8px;text-align:center;font-size:11px;color:#6c757d;font-weight:700;width:60px;">Qtd</th>
            <th style="padding:7px 8px;text-align:left;font-size:11px;color:#6c757d;font-weight:700;width:45px;">Un</th>
            <th style="padding:7px 8px;text-align:right;font-size:11px;color:#6c757d;font-weight:700;width:90px;">Preço Unit</th>
            <th style="padding:7px 8px;text-align:right;font-size:11px;color:#6c757d;font-weight:700;width:90px;">Total</th>
            <th style="padding:7px 8px;text-align:center;width:32px;"></th>
          </tr></thead>
          <tbody id="invItemsTbody"></tbody>
          <tfoot><tr id="invItemsTotRow" style="background:#f0f9ff;font-weight:700;display:none;">
            <td colspan="7" style="padding:7px 8px;text-align:right;font-size:12px;color:#1B4F72;">Total Itens:</td>
            <td style="padding:7px 8px;text-align:right;color:#1B4F72;" id="invItemsTotalDisplay">—</td>
            <td></td>
          </tr></tfoot>
        </table>
        <div id="invItemsEmpty" style="padding:18px;text-align:center;color:#9ca3af;font-size:12px;"><i class="fas fa-box" style="display:block;font-size:20px;margin-bottom:6px;opacity:0.3;"></i>Nenhum item adicionado. Clique em "Adicionar Item" para incluir produtos.</div>
      </div>
      <!-- Select produto para adicionar -->
      <div id="invItemAddRow" style="display:none;background:#f8fafc;border-radius:8px;padding:12px;margin-top:8px;border:1px solid #e9ecef;">
        <div style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr 1fr auto;gap:8px;align-items:end;">
          <div>
            <label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px;">Produto (buscar por nome ou código)</label>
            <select class="form-control" id="invItemProdSelect" style="font-size:12px;" onchange="fillInvItemFromProd()">
              <option value="">— Selecione um produto cadastrado —</option>
              ${(produtos as any[]).map((p: any) => `<option value="${esc(p.id)}" data-codigo="${esc(p.codigo)}" data-nome-en="${esc(p.nome_en||p.nome_pt)}" data-ncm="${esc(p.ncm||'')}" data-preco="${p.preco_unit_usd||0}" data-unidade="${esc(p.unidade||'PC')}" data-peso="${p.peso_bruto||0}" data-cbm="${p.cbm||0}">${esc(p.codigo)} — ${esc(p.nome_pt)}</option>`).join('')}
            </select>
          </div>
          <div><label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px;">Qtd *</label><input class="form-control" type="number" min="0.001" step="0.001" id="invItemQtd" style="font-size:12px;" placeholder="1" oninput="calcInvItemTotal()"></div>
          <div><label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px;">Preço Unit *</label><input class="form-control" type="number" step="0.01" id="invItemPreco" style="font-size:12px;" placeholder="0.00" oninput="calcInvItemTotal()"></div>
          <div><label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px;">Desconto %</label><input class="form-control" type="number" step="0.1" id="invItemDesc" style="font-size:12px;" value="0" oninput="calcInvItemTotal()"></div>
          <div><label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px;">Total</label><input class="form-control" id="invItemTotalPreview" style="font-size:12px;background:#f0fdf4;font-weight:700;" readonly></div>
          <div style="display:flex;gap:4px;">
            <button type="button" class="btn btn-primary" style="padding:8px 12px;font-size:12px;" onclick="confirmAddInvItem()"><i class="fas fa-check"></i></button>
            <button type="button" class="btn btn-secondary" style="padding:8px 12px;font-size:12px;" onclick="cancelAddInvItem()"><i class="fas fa-times"></i></button>
          </div>
        </div>
        <div style="margin-top:8px;display:grid;grid-template-columns:1fr 1fr;gap:8px;">
          <div><label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px;">Descrição EN (para invoice)</label><input class="form-control" id="invItemDescEN" style="font-size:12px;font-style:italic;" placeholder="Description in English..."></div>
          <div><label style="font-size:11px;font-weight:600;color:#374151;display:block;margin-bottom:4px;">NCM</label><input class="form-control" id="invItemNCM" style="font-size:12px;font-family:monospace;" placeholder="0000.00.00"></div>
        </div>
      </div>
    </div>

    <div style="padding:14px 22px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
      <button class="btn btn-secondary" onclick="closeModal('invModal')">Cancelar</button>
      <button class="btn btn-primary" onclick="saveInvoice()"><i class="fas fa-save"></i> Salvar Invoice</button>
    </div>
  </div>
</div>

<!-- Modal Cliente -->
<div class="modal-overlay" id="clienteModal">
  <div class="modal" style="max-width:640px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:white;z-index:1;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;" id="clienteModalTitle"><i class="fas fa-globe" style="color:#7c3aed;margin-right:8px;"></i>Novo Cliente</h3>
      <button onclick="closeModal('clienteModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div style="padding:22px;display:grid;grid-template-columns:1fr 1fr;gap:14px;">
      <input type="hidden" id="cli_id">
      <div style="grid-column:span 2;"><label class="form-label">Razão Social *</label><input class="form-control" id="cli_razao_social" placeholder="Nome completo da empresa"></div>
      <div><label class="form-label">Nome Fantasia</label><input class="form-control" id="cli_nome_fantasia" placeholder="Nome comercial"></div>
      <div><label class="form-label">País *</label><input class="form-control" id="cli_pais" placeholder="Estados Unidos"></div>
      <div><label class="form-label">Cidade</label><input class="form-control" id="cli_cidade" placeholder="New York"></div>
      <div><label class="form-label">Estado/Região</label><input class="form-control" id="cli_estado" placeholder="NY"></div>
      <div><label class="form-label">Tipo Documento</label>
        <select class="form-control" id="cli_tipo_doc">
          <option value="CNPJ">CNPJ</option><option value="VAT">VAT</option>
          <option value="EIN">EIN</option><option value="NIF">NIF</option><option value="Outro">Outro</option>
        </select>
      </div>
      <div><label class="form-label">Tax ID / CNPJ</label><input class="form-control" id="cli_tax_id" placeholder="00.000.000/0001-00"></div>
      <div><label class="form-label">Moeda Padrão</label>
        <select class="form-control" id="cli_moeda">
          <option value="USD" selected>USD</option><option value="EUR">EUR</option>
          <option value="GBP">GBP</option><option value="BRL">BRL</option>
        </select>
      </div>
      <div><label class="form-label">Incoterm Padrão</label>
        <select class="form-control" id="cli_incoterm">
          <option>EXW</option><option>FOB</option><option>CIF</option><option>DAP</option><option>DDP</option>
        </select>
      </div>
      <div><label class="form-label">Condição de Pagamento</label><input class="form-control" id="cli_cond_pgto" placeholder="30 dias" value="30 dias"></div>
      <div><label class="form-label">Limite de Crédito (USD)</label><input class="form-control" type="number" step="1000" id="cli_limite" value="0"></div>
      <div><label class="form-label">Categoria</label>
        <select class="form-control" id="cli_categoria">
          <option value="cliente">Cliente</option><option value="distribuidor">Distribuidor</option>
          <option value="agente">Agente</option><option value="prospecto">Prospecto</option>
        </select>
      </div>
      <div><label class="form-label">Status</label>
        <select class="form-control" id="cli_status">
          <option value="ativo">Ativo</option><option value="prospecto">Prospecto</option>
          <option value="inativo">Inativo</option><option value="bloqueado">Bloqueado</option>
        </select>
      </div>
      <div><label class="form-label">Nome do Contato</label><input class="form-control" id="cli_contato_nome" placeholder="John Smith"></div>
      <div><label class="form-label">E-mail Contato</label><input class="form-control" type="email" id="cli_contato_email" placeholder="john@company.com"></div>
      <div><label class="form-label">Telefone Contato</label><input class="form-control" id="cli_contato_tel" placeholder="+1 555-0000"></div>
      <div><label class="form-label">Cargo Contato</label><input class="form-control" id="cli_contato_cargo" placeholder="Purchasing Manager"></div>
      <div style="grid-column:span 2;"><label class="form-label">Endereço</label><input class="form-control" id="cli_endereco" placeholder="123 Main St, Suite 400"></div>
      <div style="grid-column:span 2;"><label class="form-label">Observações</label><textarea class="form-control" id="cli_obs" rows="2"></textarea></div>
    </div>
    <div style="padding:14px 22px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
      <button class="btn btn-secondary" onclick="closeModal('clienteModal')">Cancelar</button>
      <button class="btn btn-primary" onclick="saveCliente()"><i class="fas fa-save"></i> Salvar Cliente</button>
    </div>
  </div>
</div>

<!-- Modal Pagamento -->
<div class="modal-overlay" id="pgtoModal">
  <div class="modal" style="max-width:500px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;"><i class="fas fa-money-bill-wave" style="color:#27AE60;margin-right:8px;"></i>Registrar Pagamento</h3>
      <button onclick="closeModal('pgtoModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div style="padding:22px;display:grid;grid-template-columns:1fr 1fr;gap:14px;">
      <div style="grid-column:span 2;"><label class="form-label">Invoice *</label>
        <select class="form-control" id="pgto_invoice">
          <option value="">Selecione a invoice...</option>
          ${invoices.map((i: any) => `<option value="${esc(i.id)}">${esc(i.numero)} — ${fmtMoeda(i.total, i.moeda)}</option>`).join('')}
        </select>
      </div>
      <div><label class="form-label">Data do Pagamento *</label><input class="form-control" type="date" id="pgto_data"></div>
      <div><label class="form-label">Valor Pago *</label><input class="form-control" type="number" step="0.01" id="pgto_valor"></div>
      <div><label class="form-label">Moeda</label>
        <select class="form-control" id="pgto_moeda">
          <option value="USD" selected>USD</option><option value="EUR">EUR</option>
          <option value="BRL">BRL</option>
        </select>
      </div>
      <div><label class="form-label">Valor em BRL</label><input class="form-control" type="number" step="0.01" id="pgto_valor_brl"></div>
      <div><label class="form-label">Taxa de Câmbio</label><input class="form-control" type="number" step="0.0001" id="pgto_taxa" value="5.80"></div>
      <div><label class="form-label">Forma de Pagamento</label>
        <select class="form-control" id="pgto_forma">
          <option value="wire">Wire Transfer</option><option value="carta_credito">Carta de Crédito (LC)</option>
          <option value="cheque">Cheque</option><option value="antecipado">Antecipado</option>
        </select>
      </div>
      <div><label class="form-label">Banco Origem</label><input class="form-control" id="pgto_banco" placeholder="Nome do banco"></div>
      <div style="grid-column:span 2;"><label class="form-label">Referência / Comprovante</label><input class="form-control" id="pgto_ref" placeholder="Número da transferência, etc."></div>
      <div style="grid-column:span 2;"><label class="form-label">Observações</label><textarea class="form-control" id="pgto_obs" rows="2"></textarea></div>
    </div>
    <div style="padding:14px 22px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
      <button class="btn btn-secondary" onclick="closeModal('pgtoModal')">Cancelar</button>
      <button class="btn btn-primary" onclick="savePagamento()"><i class="fas fa-save"></i> Registrar</button>
    </div>
  </div>
</div>

<!-- Modal Proforma -->
<div class="modal-overlay" id="proformaModal">
  <div class="modal" style="max-width:600px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:white;z-index:1;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;" id="proformaModalTitle"><i class="fas fa-file-alt" style="color:#d97706;margin-right:8px;"></i>Nova Proforma Invoice</h3>
      <button onclick="closeModal('proformaModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div style="padding:22px;display:grid;grid-template-columns:1fr 1fr;gap:14px;">
      <input type="hidden" id="pf_id">
      <div><label class="form-label">Nº Proforma *</label><input class="form-control" id="pf_numero" placeholder="PF-2025-001"></div>
      <div><label class="form-label">Cliente *</label>
        <select class="form-control" id="pf_cliente">
          <option value="">Selecione...</option>
          ${clientes.map((cl: any) => `<option value="${esc(cl.id)}">${esc(cl.razao_social)}</option>`).join('')}
        </select>
      </div>
      <div><label class="form-label">Data Emissão *</label><input class="form-control" type="date" id="pf_emissao"></div>
      <div><label class="form-label">Validade</label><input class="form-control" type="date" id="pf_validade"></div>
      <div><label class="form-label">Incoterm</label>
        <select class="form-control" id="pf_incoterm">
          <option>EXW</option><option selected>FOB</option><option>CIF</option><option>DAP</option><option>DDP</option>
        </select>
      </div>
      <div><label class="form-label">Moeda</label>
        <select class="form-control" id="pf_moeda">
          <option value="USD" selected>USD</option><option value="EUR">EUR</option><option value="BRL">BRL</option>
        </select>
      </div>
      <div><label class="form-label">Valor Total</label><input class="form-control" type="number" step="0.01" id="pf_total"></div>
      <div><label class="form-label">Status</label>
        <select class="form-control" id="pf_status">
          <option value="ativa">Ativa</option><option value="aceita">Aceita</option>
          <option value="recusada">Recusada</option><option value="expirada">Expirada</option>
        </select>
      </div>
      <div style="grid-column:span 2;"><label class="form-label">Observações</label><textarea class="form-control" id="pf_obs" rows="2"></textarea></div>
    </div>
    <div style="padding:14px 22px;border-top:1px solid #f1f3f5;display:flex;justify-content:flex-end;gap:10px;">
      <button class="btn btn-secondary" onclick="closeModal('proformaModal')">Cancelar</button>
      <button class="btn btn-primary" onclick="saveProforma()"><i class="fas fa-save"></i> Salvar Proforma</button>
    </div>
  </div>
</div>

<!-- Toast -->
<div id="expToast" style="position:fixed;bottom:24px;right:24px;z-index:9999;pointer-events:none;"></div>

<!-- Modal Packing List -->
<div class="modal-overlay" id="packingListModal">
  <div class="modal" style="max-width:860px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:white;z-index:1;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;"><i class="fas fa-clipboard-list" style="color:#16a34a;margin-right:8px;"></i>Packing List — <span id="plInvNumero"></span></h3>
      <div style="display:flex;gap:8px;">
        <button onclick="printPackingList()" class="btn btn-primary" style="font-size:12px;"><i class="fas fa-print"></i> Imprimir</button>
        <button onclick="closeModal('packingListModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
      </div>
    </div>
    <div id="packingListContent" style="padding:24px;overflow-y:auto;max-height:75vh;">
      <!-- Preenchido dinamicamente -->
    </div>
  </div>
</div>

<!-- Modal Import CSV Produtos -->
<div class="modal-overlay" id="expProdCsvModal">
  <div class="modal" style="max-width:800px;">
    <div style="padding:18px 22px;border-bottom:1px solid #f1f3f5;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:white;z-index:1;">
      <h3 style="margin:0;font-size:16px;font-weight:700;color:#1B4F72;"><i class="fas fa-file-csv" style="color:#16a34a;margin-right:8px;"></i>Importar Produtos por CSV</h3>
      <button onclick="closeModal('expProdCsvModal')" style="background:none;border:none;font-size:22px;cursor:pointer;color:#9ca3af;">&times;</button>
    </div>
    <div style="display:flex;border-bottom:1px solid #f1f3f5;">
      <button id="csvTab1" onclick="showCsvTab(1)" style="padding:10px 20px;border:none;background:none;font-size:13px;font-weight:600;color:#1B4F72;border-bottom:2px solid #1B4F72;cursor:pointer;">1. Colar / Carregar</button>
      <button id="csvTab2" onclick="showCsvTab(2)" style="padding:10px 20px;border:none;background:none;font-size:13px;font-weight:600;color:#9ca3af;border-bottom:2px solid transparent;cursor:pointer;">2. Rascunho</button>
      <button id="csvTab3" onclick="showCsvTab(3)" style="padding:10px 20px;border:none;background:none;font-size:13px;font-weight:600;color:#9ca3af;border-bottom:2px solid transparent;cursor:pointer;">3. Relatório</button>
    </div>
    <div style="overflow-y:auto;max-height:65vh;">
      <!-- Aba 1: Input -->
      <div id="csvStep1" style="padding:20px 24px;">
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:14px 16px;margin-bottom:16px;font-size:12px;color:#166534;">
          <div style="font-weight:700;margin-bottom:6px;"><i class="fas fa-info-circle" style="margin-right:4px;"></i>Formato esperado (cabeçalhos):</div>
          <code style="font-size:11px;background:white;padding:4px 8px;border-radius:4px;display:inline-block;word-break:break-all;color:#374151;">codigo | nome_pt | nome_en | ncm | hs_code | unidade | pais_origem | peso_bruto | peso_liquido | cbm | preco_usd | preco_brl | categoria | marca | modelo | descricao_pt | descricao_en</code>
          <div style="margin-top:6px;">• <strong>codigo</strong> e <strong>nome_pt</strong> são obrigatórios. • Suporta CSV (vírgula/ponto-e-vírgula) e TSV (tab/Excel).</div>
        </div>
        <div style="display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap;">
          <div style="flex:1;min-width:200px;">
            <label style="font-size:12px;font-weight:600;color:#374151;display:block;margin-bottom:6px;"><i class="fas fa-keyboard" style="margin-right:4px;"></i>Colar do Excel / Google Sheets</label>
            <textarea id="csvPasteArea" rows="8" placeholder="Cole aqui os dados copiados do Excel ou Google Sheets..." style="width:100%;font-family:monospace;font-size:12px;border:1.5px solid #d1d5db;border-radius:8px;padding:10px;resize:vertical;box-sizing:border-box;" oninput="csvPreviewFromPaste()"></textarea>
          </div>
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;color:#9ca3af;font-size:13px;font-weight:600;padding:0 8px;">OU</div>
          <div style="flex:1;min-width:200px;">
            <label style="font-size:12px;font-weight:600;color:#374151;display:block;margin-bottom:6px;"><i class="fas fa-upload" style="margin-right:4px;"></i>Upload de arquivo CSV</label>
            <div id="csvDropZone" style="border:2px dashed #d1d5db;border-radius:8px;padding:24px;text-align:center;cursor:pointer;background:#fafafa;" onclick="document.getElementById('csvFileInput').click()" ondragover="event.preventDefault();this.style.borderColor='#16a34a'" ondragleave="this.style.borderColor='#d1d5db'" ondrop="csvHandleDrop(event)">
              <i class="fas fa-cloud-upload-alt" style="font-size:28px;color:#9ca3af;display:block;margin-bottom:8px;"></i>
              <div style="font-size:12px;color:#6c757d;">Clique ou arraste um arquivo CSV aqui</div>
              <div id="csvFileName" style="font-size:11px;color:#16a34a;margin-top:6px;font-weight:600;"></div>
            </div>
            <input type="file" id="csvFileInput" accept=".csv,.tsv,.txt" style="display:none;" onchange="csvHandleFile(this)">
          </div>
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end;">
          <button onclick="csvDownloadTemplate()" class="btn btn-secondary" style="font-size:12px;"><i class="fas fa-download"></i> Baixar Modelo CSV</button>
          <button onclick="csvPreviewParsed()" class="btn btn-primary" id="csvParseBtn" disabled><i class="fas fa-eye"></i> Visualizar Rascunho</button>
        </div>
      </div>
      <!-- Aba 2: Rascunho -->
      <div id="csvStep2" style="display:none;padding:20px 24px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px;">
          <div id="csvDraftStats" style="font-size:13px;color:#374151;"></div>
          <div style="display:flex;gap:8px;">
            <button onclick="csvCommit()" class="btn btn-primary" id="csvCommitBtn"><i class="fas fa-check"></i> Importar Agora</button>
          </div>
        </div>
        <div style="overflow-x:auto;">
          <table style="width:100%;border-collapse:collapse;font-size:11px;" id="csvDraftTable">
            <thead><tr style="background:#166534;color:white;">
              <th style="padding:7px 8px;">#</th>
              <th style="padding:7px 8px;text-align:left;">Código *</th>
              <th style="padding:7px 8px;text-align:left;">Nome PT *</th>
              <th style="padding:7px 8px;text-align:left;font-style:italic;">Nome EN</th>
              <th style="padding:7px 8px;text-align:left;">NCM</th>
              <th style="padding:7px 8px;text-align:left;">HS Code</th>
              <th style="padding:7px 8px;text-align:center;">Unidade</th>
              <th style="padding:7px 8px;text-align:center;">Peso Bruto</th>
              <th style="padding:7px 8px;text-align:center;">CBM</th>
              <th style="padding:7px 8px;text-align:right;">Preço USD</th>
              <th style="padding:7px 8px;text-align:center;">Status</th>
              <th style="padding:7px 8px;text-align:center;">Ação</th>
            </tr></thead>
            <tbody id="csvDraftBody"></tbody>
          </table>
        </div>
      </div>
      <!-- Aba 3: Relatório -->
      <div id="csvStep3" style="display:none;padding:20px 24px;">
        <div id="csvReportSummary" style="margin-bottom:16px;"></div>
        <div style="overflow-x:auto;">
          <table style="width:100%;border-collapse:collapse;font-size:12px;">
            <thead><tr style="background:#166534;color:white;">
              <th style="padding:8px 10px;">#</th>
              <th style="padding:8px 10px;text-align:left;">Código</th>
              <th style="padding:8px 10px;text-align:left;">Nome PT</th>
              <th style="padding:8px 10px;text-align:center;">Ação</th>
              <th style="padding:8px 10px;text-align:left;">Mensagem</th>
            </tr></thead>
            <tbody id="csvReportBody"></tbody>
          </table>
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px;">
          <button onclick="closeModal('expProdCsvModal')" class="btn btn-primary"><i class="fas fa-check"></i> Concluir</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
const EXP_CLIENTES = ${safeJson(clientes)};
const EXP_INVOICES = ${safeJson(invoices)};

function showToast(msg, type='success') {
  const c = document.getElementById('expToast');
  const t = document.createElement('div');
  const col = type==='success'?'#16a34a':type==='info'?'#2980B9':'#dc2626';
  const ico = type==='success'?'fa-check-circle':type==='info'?'fa-info-circle':'fa-exclamation-circle';
  t.style.cssText = 'padding:12px 20px;border-radius:10px;font-size:13px;font-weight:700;color:white;background:'+col+';box-shadow:0 4px 20px rgba(0,0,0,0.2);margin-bottom:8px;display:flex;align-items:center;gap:8px;pointer-events:auto;animation:fadeInUp 0.3s ease;';
  t.innerHTML = '<i class="fas '+ico+'"></i> ' + msg;
  c.appendChild(t);
  setTimeout(()=>t.remove(), 3500);
}
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
function openModal(id) { document.getElementById(id).classList.add('open'); }

// Abas
document.querySelectorAll('.exp-tab').forEach(btn => {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.exp-tab').forEach(b => {
      b.style.color = '#6c757d'; b.style.borderBottom = '3px solid transparent';
    });
    this.style.color = '#7c3aed'; this.style.borderBottom = '3px solid #7c3aed';
    document.querySelectorAll('.exp-panel').forEach(p => p.style.display = 'none');
    document.getElementById('tab-' + this.dataset.tab).style.display = 'block';
  });
});

// ── Filtros ──────────────────────────────────────────────────────────────────
function filterInvoices() {
  const s = document.getElementById('searchInvoices').value.toLowerCase();
  const st = document.getElementById('filterInvStatus').value;
  document.querySelectorAll('#invoicesTbody .inv-row').forEach(row => {
    const match = (!s || row.dataset.search.includes(s)) && (!st || row.dataset.status === st);
    row.style.display = match ? '' : 'none';
  });
}
function filterClientes() {
  const s = document.getElementById('searchClientes').value.toLowerCase();
  document.querySelectorAll('#clientesTbody .cli-row').forEach(row => {
    row.style.display = (!s || row.dataset.search.includes(s)) ? '' : 'none';
  });
}

// ── Invoice Modal ─────────────────────────────────────────────────────────────
function calcInvTotal() {
  const sub = parseFloat(document.getElementById('inv_subtotal').value)||0;
  const desc = parseFloat(document.getElementById('inv_desconto').value)||0;
  const frete = parseFloat(document.getElementById('inv_frete').value)||0;
  const seg = parseFloat(document.getElementById('inv_seguro').value)||0;
  const tx = parseFloat(document.getElementById('inv_taxa_cambio').value)||1;
  const total = sub - desc + frete + seg;
  const moeda = document.getElementById('inv_moeda').value || 'USD';
  try {
    document.getElementById('inv_total_display').value =
      new Intl.NumberFormat('pt-BR', {style:'currency', currency: moeda}).format(total) +
      ' = BRL ' + new Intl.NumberFormat('pt-BR', {style:'currency', currency:'BRL'}).format(total * tx);
  } catch {
    document.getElementById('inv_total_display').value = total.toFixed(2);
  }
}

function openInvModal(id) {
  const fields = ['inv_id','inv_numero','inv_cliente','inv_data_emissao','inv_data_embarque',
    'inv_data_vencimento','inv_incoterm','inv_moeda','inv_modal','inv_porto_origem',
    'inv_porto_destino','inv_transportadora','inv_bl_awb','inv_subtotal','inv_desconto',
    'inv_frete','inv_seguro','inv_taxa_cambio','inv_status','inv_status_pgto','inv_obs'];
  fields.forEach(f => { const el=document.getElementById(f); if(el) el.value=''; });
  document.getElementById('inv_desconto').value='0';
  document.getElementById('inv_frete').value='0';
  document.getElementById('inv_seguro').value='0';
  document.getElementById('inv_taxa_cambio').value='5.80';
  document.getElementById('inv_total_display').value='';
  document.getElementById('invModalTitle').innerHTML='<i class="fas fa-file-invoice" style="color:#7c3aed;margin-right:8px;"></i>Nova Invoice';

  if (id) {
    const inv = EXP_INVOICES.find(i => i.id === id);
    if (inv) {
      document.getElementById('inv_id').value = inv.id || '';
      document.getElementById('inv_numero').value = inv.numero || '';
      document.getElementById('inv_cliente').value = inv.cliente_id || '';
      document.getElementById('inv_data_emissao').value = inv.data_emissao || '';
      document.getElementById('inv_data_embarque').value = inv.data_embarque || '';
      document.getElementById('inv_data_vencimento').value = inv.data_vencimento || '';
      document.getElementById('inv_incoterm').value = inv.incoterm || 'FOB';
      document.getElementById('inv_moeda').value = inv.moeda || 'USD';
      document.getElementById('inv_modal').value = inv.modal || 'maritimo';
      document.getElementById('inv_porto_origem').value = inv.porto_origem || '';
      document.getElementById('inv_porto_destino').value = inv.porto_destino || '';
      document.getElementById('inv_transportadora').value = inv.transportadora || '';
      document.getElementById('inv_bl_awb').value = inv.bl_awb || '';
      document.getElementById('inv_subtotal').value = inv.subtotal || 0;
      document.getElementById('inv_desconto').value = inv.desconto || 0;
      document.getElementById('inv_frete').value = inv.frete || 0;
      document.getElementById('inv_seguro').value = inv.seguro || 0;
      document.getElementById('inv_taxa_cambio').value = inv.taxa_cambio || 5.80;
      document.getElementById('inv_status').value = inv.status || 'rascunho';
      document.getElementById('inv_status_pgto').value = inv.status_pgto || 'pendente';
      document.getElementById('inv_obs').value = inv.observacoes || '';
      calcInvTotal();
      document.getElementById('invModalTitle').innerHTML='<i class="fas fa-file-invoice" style="color:#7c3aed;margin-right:8px;"></i>Editar Invoice';
    }
  } else {
    // Preencher data atual
    document.getElementById('inv_data_emissao').value = new Date().toISOString().split('T')[0];
    document.getElementById('inv_status').value = 'rascunho';
    document.getElementById('inv_status_pgto').value = 'pendente';
    document.getElementById('inv_moeda').value = 'USD';
    document.getElementById('inv_incoterm').value = 'FOB';
  }
  openModal('invModal');
}

async function saveInvoice() {
  const id = document.getElementById('inv_id').value;
  const numero = document.getElementById('inv_numero').value.trim();
  const cliente = document.getElementById('inv_cliente').value;
  const dataEmissao = document.getElementById('inv_data_emissao').value;
  if (!numero || !cliente || !dataEmissao) { showToast('Preencha N\u00ba Invoice, Cliente e Data de Emiss\u00e3o.', 'error'); return; }
  const sub = parseFloat(document.getElementById('inv_subtotal').value)||0;
  const desc = parseFloat(document.getElementById('inv_desconto').value)||0;
  const frete = parseFloat(document.getElementById('inv_frete').value)||0;
  const seg = parseFloat(document.getElementById('inv_seguro').value)||0;
  const tx = parseFloat(document.getElementById('inv_taxa_cambio').value)||1;
  const total = sub - desc + frete + seg;
  const payload = {
    numero, cliente_id: cliente,
    data_emissao: dataEmissao,
    data_embarque: document.getElementById('inv_data_embarque').value||null,
    data_vencimento: document.getElementById('inv_data_vencimento').value||null,
    incoterm: document.getElementById('inv_incoterm').value,
    moeda: document.getElementById('inv_moeda').value,
    modal: document.getElementById('inv_modal').value,
    porto_origem: document.getElementById('inv_porto_origem').value,
    porto_destino: document.getElementById('inv_porto_destino').value,
    transportadora: document.getElementById('inv_transportadora').value,
    bl_awb: document.getElementById('inv_bl_awb').value,
    subtotal: sub, desconto: desc, frete, seguro: seg,
    total, total_brl: total * tx, taxa_cambio: tx,
    status: document.getElementById('inv_status').value,
    status_pgto: document.getElementById('inv_status_pgto').value,
    observacoes: document.getElementById('inv_obs').value,
  };
  try {
    const url = id ? '/exportacao/api/invoices/' + id : '/exportacao/api/invoices';
    const method = id ? 'PUT' : 'POST';
    const res = await fetch(url, { method, headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const data = await res.json();
    if (data.ok) { showToast(id ? 'Invoice atualizada!' : 'Invoice criada!', 'success'); closeModal('invModal'); setTimeout(()=>location.reload(), 800); }
    else showToast('Erro: ' + (data.error||'Falha ao salvar'), 'error');
  } catch { showToast('Erro de conex\u00e3o.', 'error'); }
}

async function deleteInvoice(id, num) {
  if (!confirm('Excluir invoice ' + num + '?')) return;
  const res = await fetch('/exportacao/api/invoices/' + id, {method:'DELETE'});
  const data = await res.json();
  if (data.ok) { showToast('Invoice exclu\u00edda.', 'info'); setTimeout(()=>location.reload(), 600); }
  else showToast('Erro ao excluir.', 'error');
}

function openInvDetail(id) {
  const inv = EXP_INVOICES.find(i => i.id === id);
  if (!inv) return;
  showToast('Detalhes: ' + inv.numero, 'info');
  // TODO: expandir para modal de detalhes com itens
}

// ── Cliente Modal ─────────────────────────────────────────────────────────────
function openClienteModal(id) {
  document.getElementById('clienteModalTitle').innerHTML = '<i class="fas fa-globe" style="color:#7c3aed;margin-right:8px;"></i>' + (id ? 'Editar Cliente' : 'Novo Cliente');
  ['cli_id','cli_razao_social','cli_nome_fantasia','cli_pais','cli_cidade','cli_estado',
   'cli_tipo_doc','cli_tax_id','cli_moeda','cli_incoterm','cli_cond_pgto','cli_limite',
   'cli_categoria','cli_status','cli_contato_nome','cli_contato_email','cli_contato_tel',
   'cli_contato_cargo','cli_endereco','cli_obs'].forEach(f => {
    const el = document.getElementById(f);
    if (el) el.value = '';
  });
  if (id) {
    const cl = EXP_CLIENTES.find(c => c.id === id);
    if (cl) {
      document.getElementById('cli_id').value = cl.id||'';
      document.getElementById('cli_razao_social').value = cl.razao_social||'';
      document.getElementById('cli_nome_fantasia').value = cl.nome_fantasia||'';
      document.getElementById('cli_pais').value = cl.pais||'';
      document.getElementById('cli_cidade').value = cl.cidade||'';
      document.getElementById('cli_estado').value = cl.estado||'';
      document.getElementById('cli_tipo_doc').value = cl.tipo_doc||'CNPJ';
      document.getElementById('cli_tax_id').value = cl.tax_id||'';
      document.getElementById('cli_moeda').value = cl.moeda||'USD';
      document.getElementById('cli_incoterm').value = cl.incoterm||'FOB';
      document.getElementById('cli_cond_pgto').value = cl.condicao_pgto||'30 dias';
      document.getElementById('cli_limite').value = cl.limite_credito||0;
      document.getElementById('cli_categoria').value = cl.categoria||'cliente';
      document.getElementById('cli_status').value = cl.status||'ativo';
      document.getElementById('cli_contato_nome').value = cl.contato_nome||'';
      document.getElementById('cli_contato_email').value = cl.contato_email||'';
      document.getElementById('cli_contato_tel').value = cl.contato_tel||'';
      document.getElementById('cli_contato_cargo').value = cl.contato_cargo||'';
      document.getElementById('cli_endereco').value = cl.endereco||'';
      document.getElementById('cli_obs').value = cl.observacoes||'';
    }
  } else {
    document.getElementById('cli_moeda').value = 'USD';
    document.getElementById('cli_incoterm').value = 'FOB';
    document.getElementById('cli_cond_pgto').value = '30 dias';
    document.getElementById('cli_categoria').value = 'cliente';
    document.getElementById('cli_status').value = 'ativo';
  }
  openModal('clienteModal');
}

async function saveCliente() {
  const id = document.getElementById('cli_id').value;
  const razao = document.getElementById('cli_razao_social').value.trim();
  const pais = document.getElementById('cli_pais').value.trim();
  if (!razao || !pais) { showToast('Preencha Raz\u00e3o Social e Pa\u00eds.', 'error'); return; }
  const payload = {
    razao_social: razao,
    nome_fantasia: document.getElementById('cli_nome_fantasia').value,
    pais, cidade: document.getElementById('cli_cidade').value,
    estado: document.getElementById('cli_estado').value,
    tipo_doc: document.getElementById('cli_tipo_doc').value,
    tax_id: document.getElementById('cli_tax_id').value,
    moeda: document.getElementById('cli_moeda').value,
    incoterm: document.getElementById('cli_incoterm').value,
    condicao_pgto: document.getElementById('cli_cond_pgto').value,
    limite_credito: parseFloat(document.getElementById('cli_limite').value)||0,
    categoria: document.getElementById('cli_categoria').value,
    status: document.getElementById('cli_status').value,
    contato_nome: document.getElementById('cli_contato_nome').value,
    contato_email: document.getElementById('cli_contato_email').value,
    contato_tel: document.getElementById('cli_contato_tel').value,
    contato_cargo: document.getElementById('cli_contato_cargo').value,
    endereco: document.getElementById('cli_endereco').value,
    observacoes: document.getElementById('cli_obs').value,
  };
  try {
    const url = id ? '/exportacao/api/clientes/' + id : '/exportacao/api/clientes';
    const method = id ? 'PUT' : 'POST';
    const res = await fetch(url, { method, headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const data = await res.json();
    if (data.ok) { showToast(id ? 'Cliente atualizado!' : 'Cliente criado!', 'success'); closeModal('clienteModal'); setTimeout(()=>location.reload(), 800); }
    else showToast('Erro: ' + (data.error||'Falha ao salvar'), 'error');
  } catch { showToast('Erro de conex\u00e3o.', 'error'); }
}

async function deleteCliente(id, nome) {
  if (!confirm('Excluir cliente "' + nome + '"?')) return;
  const res = await fetch('/exportacao/api/clientes/' + id, {method:'DELETE'});
  const data = await res.json();
  if (data.ok) { showToast('Cliente exclu\u00eddo.', 'info'); setTimeout(()=>location.reload(), 600); }
  else showToast('Erro ao excluir.', 'error');
}

// ── Pagamento Modal ──────────────────────────────────────────────────────────
function openPgtoModal() {
  ['pgto_invoice','pgto_data','pgto_valor','pgto_moeda','pgto_valor_brl','pgto_taxa','pgto_forma','pgto_banco','pgto_ref','pgto_obs'].forEach(f => {
    const el = document.getElementById(f);
    if (el) { if (f === 'pgto_taxa') el.value = '5.80'; else if (f === 'pgto_moeda') el.value = 'USD'; else el.value = ''; }
  });
  document.getElementById('pgto_data').value = new Date().toISOString().split('T')[0];
  openModal('pgtoModal');
}

async function savePagamento() {
  const invId = document.getElementById('pgto_invoice').value;
  const data = document.getElementById('pgto_data').value;
  const valor = parseFloat(document.getElementById('pgto_valor').value)||0;
  if (!invId || !data || !valor) { showToast('Preencha Invoice, Data e Valor.', 'error'); return; }
  const payload = {
    invoice_id: invId, data_pgto: data, valor,
    moeda: document.getElementById('pgto_moeda').value,
    valor_brl: parseFloat(document.getElementById('pgto_valor_brl').value)||0,
    taxa_cambio: parseFloat(document.getElementById('pgto_taxa').value)||1,
    forma_pgto: document.getElementById('pgto_forma').value,
    banco_origem: document.getElementById('pgto_banco').value,
    referencia: document.getElementById('pgto_ref').value,
    observacoes: document.getElementById('pgto_obs').value,
  };
  try {
    const res = await fetch('/exportacao/api/pagamentos', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const d = await res.json();
    if (d.ok) { showToast('Pagamento registrado!', 'success'); closeModal('pgtoModal'); setTimeout(()=>location.reload(), 800); }
    else showToast('Erro: ' + (d.error||'Falha'), 'error');
  } catch { showToast('Erro de conex\u00e3o.', 'error'); }
}

// ── Proforma Modal ───────────────────────────────────────────────────────────
function openProformaModal(id) {
  document.getElementById('proformaModalTitle').innerHTML = '<i class="fas fa-file-alt" style="color:#d97706;margin-right:8px;"></i>' + (id ? 'Editar Proforma' : 'Nova Proforma Invoice');
  ['pf_id','pf_numero','pf_cliente','pf_emissao','pf_validade','pf_incoterm','pf_moeda','pf_total','pf_status','pf_obs'].forEach(f => {
    const el = document.getElementById(f);
    if (el) el.value = '';
  });
  document.getElementById('pf_emissao').value = new Date().toISOString().split('T')[0];
  document.getElementById('pf_status').value = 'ativa';
  openModal('proformaModal');
}

async function saveProforma() {
  const numero = document.getElementById('pf_numero').value.trim();
  const cliente = document.getElementById('pf_cliente').value;
  const emissao = document.getElementById('pf_emissao').value;
  if (!numero || !cliente || !emissao) { showToast('Preencha N\u00ba, Cliente e Data.', 'error'); return; }
  const payload = {
    numero, cliente_id: cliente,
    data_emissao: emissao,
    data_validade: document.getElementById('pf_validade').value||null,
    incoterm: document.getElementById('pf_incoterm').value,
    moeda: document.getElementById('pf_moeda').value,
    total: parseFloat(document.getElementById('pf_total').value)||0,
    status: document.getElementById('pf_status').value,
    observacoes: document.getElementById('pf_obs').value,
  };
  const id = document.getElementById('pf_id').value;
  try {
    const url = id ? '/exportacao/api/proformas/' + id : '/exportacao/api/proformas';
    const method = id ? 'PUT' : 'POST';
    const res = await fetch(url, { method, headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const d = await res.json();
    if (d.ok) { showToast(id ? 'Proforma atualizada!' : 'Proforma criada!', 'success'); closeModal('proformaModal'); setTimeout(()=>location.reload(), 800); }
    else showToast('Erro: ' + (d.error||''), 'error');
  } catch { showToast('Erro de conex\u00e3o.', 'error'); }
}

async function convertProforma(id) {
  if (!confirm('Converter esta proforma em Commercial Invoice?')) return;
  const res = await fetch('/exportacao/api/proformas/' + id + '/convert', {method:'POST'});
  const d = await res.json();
  if (d.ok) { showToast('Proforma convertida em Invoice!', 'success'); setTimeout(()=>location.reload(), 800); }
  else showToast('Erro: ' + (d.error||''), 'error');
}

// Fechar modais ao clicar fora
document.querySelectorAll('.modal-overlay').forEach(el => {
  el.addEventListener('click', function(e) {
    if (e.target === this) this.classList.remove('open');
  });
});

// ── Produtos de Exportação ────────────────────────────────────────────────────
const EXP_PRODUTOS = ${safeJson(produtos)};

function filterExpProdutos() {
  const s = document.getElementById('searchProdutos').value.toLowerCase();
  const st = document.getElementById('filterProdStatus').value;
  document.querySelectorAll('#produtosTbody .prod-exp-row').forEach(row => {
    const match = (!s || row.dataset.search.includes(s)) && (!st || row.dataset.status === st);
    row.style.display = match ? '' : 'none';
  });
}

function openExpProdModal(id) {
  const fields = ['expProd_id','expProd_codigo','expProd_categoria','expProd_nome_pt','expProd_nome_en',
    'expProd_marca','expProd_modelo','expProd_ncm','expProd_hs_code','expProd_pais_origem',
    'expProd_unidade','expProd_descricao_pt','expProd_descricao_en',
    'expProd_peso_bruto','expProd_peso_liquido','expProd_cbm',
    'expProd_preco_usd','expProd_preco_brl','expProd_status','expProd_obs'];
  fields.forEach(f => { const el = document.getElementById(f); if (el) el.value = ''; });
  document.getElementById('expProd_pais_origem').value = 'Brasil';
  document.getElementById('expProd_unidade').value = 'PC';
  document.getElementById('expProd_status').value = 'ativo';
  document.getElementById('expProdModalTitle').innerHTML = '<i class="fas fa-box-open" style="color:#16a34a;margin-right:8px;"></i>Novo Produto';

  if (id) {
    const p = EXP_PRODUTOS.find(x => x.id === id);
    if (p) {
      document.getElementById('expProd_id').value = p.id || '';
      document.getElementById('expProd_codigo').value = p.codigo || '';
      document.getElementById('expProd_categoria').value = p.categoria || '';
      document.getElementById('expProd_nome_pt').value = p.nome_pt || '';
      document.getElementById('expProd_nome_en').value = p.nome_en || '';
      document.getElementById('expProd_marca').value = p.marca || '';
      document.getElementById('expProd_modelo').value = p.modelo || '';
      document.getElementById('expProd_ncm').value = p.ncm || '';
      document.getElementById('expProd_hs_code').value = p.hs_code || '';
      document.getElementById('expProd_pais_origem').value = p.pais_origem || 'Brasil';
      document.getElementById('expProd_unidade').value = p.unidade || 'PC';
      document.getElementById('expProd_descricao_pt').value = p.descricao_pt || '';
      document.getElementById('expProd_descricao_en').value = p.descricao_en || '';
      document.getElementById('expProd_peso_bruto').value = p.peso_bruto || '';
      document.getElementById('expProd_peso_liquido').value = p.peso_liquido || '';
      document.getElementById('expProd_cbm').value = p.cbm || '';
      document.getElementById('expProd_preco_usd').value = p.preco_unit_usd || '';
      document.getElementById('expProd_preco_brl').value = p.preco_unit_brl || '';
      document.getElementById('expProd_status').value = p.status || 'ativo';
      document.getElementById('expProd_obs').value = p.observacoes || '';
      document.getElementById('expProdModalTitle').innerHTML = '<i class="fas fa-box-open" style="color:#16a34a;margin-right:8px;"></i>Editar Produto';
    }
  }
  openModal('expProdModal');
}

async function saveExpProd() {
  const codigo = document.getElementById('expProd_codigo').value.trim();
  const nome_pt = document.getElementById('expProd_nome_pt').value.trim();
  if (!codigo) { showToast('Informe o c\u00f3digo do produto.', 'error'); return; }
  if (!nome_pt) { showToast('Informe o nome em portugu\u00eas.', 'error'); return; }
  const payload = {
    codigo,
    nome_pt,
    nome_en: document.getElementById('expProd_nome_en').value.trim(),
    categoria: document.getElementById('expProd_categoria').value.trim(),
    marca: document.getElementById('expProd_marca').value.trim(),
    modelo: document.getElementById('expProd_modelo').value.trim(),
    ncm: document.getElementById('expProd_ncm').value.trim(),
    hs_code: document.getElementById('expProd_hs_code').value.trim(),
    pais_origem: document.getElementById('expProd_pais_origem').value.trim() || 'Brasil',
    unidade: document.getElementById('expProd_unidade').value,
    descricao_pt: document.getElementById('expProd_descricao_pt').value.trim(),
    descricao_en: document.getElementById('expProd_descricao_en').value.trim(),
    peso_bruto: parseFloat(document.getElementById('expProd_peso_bruto').value) || 0,
    peso_liquido: parseFloat(document.getElementById('expProd_peso_liquido').value) || 0,
    cbm: parseFloat(document.getElementById('expProd_cbm').value) || 0,
    preco_unit_usd: parseFloat(document.getElementById('expProd_preco_usd').value) || 0,
    preco_unit_brl: parseFloat(document.getElementById('expProd_preco_brl').value) || 0,
    status: document.getElementById('expProd_status').value,
    observacoes: document.getElementById('expProd_obs').value.trim(),
  };
  const id = document.getElementById('expProd_id').value;
  try {
    const url = id ? '/exportacao/api/produtos/' + id : '/exportacao/api/produtos';
    const method = id ? 'PUT' : 'POST';
    const res = await fetch(url, { method, headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const d = await res.json();
    if (d.ok) {
      showToast(id ? 'Produto atualizado!' : 'Produto cadastrado!', 'success');
      closeModal('expProdModal');
      setTimeout(() => location.reload(), 800);
    } else {
      showToast('Erro: ' + (d.error || 'desconhecido'), 'error');
    }
  } catch { showToast('Erro de conex\u00e3o.', 'error'); }
}

async function deleteExpProd(id, nome) {
  if (!confirm('Excluir o produto "' + nome + '"? Esta a\u00e7\u00e3o n\u00e3o pode ser desfeita.')) return;
  try {
    const res = await fetch('/exportacao/api/produtos/' + id, { method: 'DELETE' });
    const d = await res.json();
    if (d.ok) { showToast('Produto exclu\u00eddo.', 'success'); setTimeout(() => location.reload(), 800); }
    else showToast('Erro: ' + (d.error || ''), 'error');
  } catch { showToast('Erro de conex\u00e3o.', 'error'); }
}

// ── Itens da Invoice ──────────────────────────────────────────────────────────
var _invItems = []; // array de itens do modal atual

function renderInvItems() {
  var tbody = document.getElementById('invItemsTbody');
  var empty = document.getElementById('invItemsEmpty');
  var totRow = document.getElementById('invItemsTotRow');
  if (!tbody) return;
  if (_invItems.length === 0) {
    tbody.innerHTML = '';
    if (empty) empty.style.display = '';
    if (totRow) totRow.style.display = 'none';
    return;
  }
  if (empty) empty.style.display = 'none';
  if (totRow) totRow.style.display = '';
  var total = 0;
  tbody.innerHTML = _invItems.map(function(it, idx) {
    var t = it.preco_total || (it.quantidade * it.preco_unit * (1 - (it.desconto_pct||0)/100));
    total += t;
    return '<tr style="border-bottom:1px solid #f1f3f5;">' +
      '<td style="padding:6px 8px;font-size:12px;font-weight:600;color:#1B4F72;">' + (it.nome_en || it.descricao || '') + '</td>' +
      '<td style="padding:6px 8px;font-family:monospace;font-size:11px;color:#16a34a;">' + (it.codigo||'') + '</td>' +
      '<td style="padding:6px 8px;font-size:11px;color:#374151;font-style:italic;">' + (it.descricao||'') + '</td>' +
      '<td style="padding:6px 8px;font-family:monospace;font-size:11px;color:#7c3aed;">' + (it.ncm||'\u2014') + '</td>' +
      '<td style="padding:6px 8px;text-align:center;font-size:12px;">' + (it.quantidade||1) + '</td>' +
      '<td style="padding:6px 8px;font-size:11px;color:#6c757d;">' + (it.unidade||'PC') + '</td>' +
      '<td style="padding:6px 8px;text-align:right;font-size:12px;">' + (it.preco_unit||0).toFixed(2) + '</td>' +
      '<td style="padding:6px 8px;text-align:right;font-weight:700;color:#1B4F72;font-size:12px;">' + t.toFixed(2) + '</td>' +
      '<td style="padding:6px 8px;text-align:center;"><button type="button" style="background:none;border:none;color:#dc2626;cursor:pointer;font-size:13px;" onclick="removeInvItem(' + idx + ')"><i class="fas fa-times"></i></button></td>' +
      '</tr>';
  }).join('');
  var moeda = document.getElementById('inv_moeda') ? document.getElementById('inv_moeda').value : 'USD';
  document.getElementById('invItemsTotalDisplay').textContent = moeda + ' ' + total.toFixed(2);
  // Atualizar subtotal automaticamente
  var subEl = document.getElementById('inv_subtotal');
  if (subEl && _invItems.length > 0) { subEl.value = total.toFixed(2); calcInvTotal(); }
}

function addInvItem() {
  document.getElementById('invItemAddRow').style.display = '';
  document.getElementById('invItemProdSelect').value = '';
  document.getElementById('invItemQtd').value = '1';
  document.getElementById('invItemPreco').value = '';
  document.getElementById('invItemDesc').value = '0';
  document.getElementById('invItemTotalPreview').value = '';
  document.getElementById('invItemDescEN').value = '';
  document.getElementById('invItemNCM').value = '';
}
function cancelAddInvItem() { document.getElementById('invItemAddRow').style.display = 'none'; }

function fillInvItemFromProd() {
  var sel = document.getElementById('invItemProdSelect');
  var opt = sel.options[sel.selectedIndex];
  if (!opt || !opt.value) return;
  document.getElementById('invItemPreco').value = opt.dataset.preco || '0';
  document.getElementById('invItemDescEN').value = opt.dataset.nomeEn || '';
  document.getElementById('invItemNCM').value = opt.dataset.ncm || '';
  calcInvItemTotal();
}

function calcInvItemTotal() {
  var q = parseFloat(document.getElementById('invItemQtd').value)||0;
  var p = parseFloat(document.getElementById('invItemPreco').value)||0;
  var d = parseFloat(document.getElementById('invItemDesc').value)||0;
  var t = q * p * (1 - d/100);
  document.getElementById('invItemTotalPreview').value = t.toFixed(2);
}

function confirmAddInvItem() {
  var sel = document.getElementById('invItemProdSelect');
  var opt = sel.options[sel.selectedIndex];
  var qtd = parseFloat(document.getElementById('invItemQtd').value)||0;
  var preco = parseFloat(document.getElementById('invItemPreco').value)||0;
  var desc = parseFloat(document.getElementById('invItemDesc').value)||0;
  if (!qtd || !preco) { showToast('Informe quantidade e pre\u00e7o unit\u00e1rio.', 'error'); return; }
  var descEN = document.getElementById('invItemDescEN').value.trim();
  var ncm = document.getElementById('invItemNCM').value.trim();
  _invItems.push({
    produto_id: opt && opt.value ? opt.value : null,
    codigo: opt ? opt.dataset.codigo||'' : '',
    nome_en: opt ? (opt.dataset.nomeEn||opt.text||'') : descEN,
    descricao: descEN,
    ncm: ncm,
    quantidade: qtd,
    unidade: opt ? (opt.dataset.unidade||'PC') : 'PC',
    peso_unit: opt ? parseFloat(opt.dataset.peso||'0') : 0,
    cbm_unit: opt ? parseFloat(opt.dataset.cbm||'0') : 0,
    preco_unit: preco,
    desconto_pct: desc,
    preco_total: qtd * preco * (1 - desc/100),
  });
  cancelAddInvItem();
  renderInvItems();
}

function removeInvItem(idx) {
  _invItems.splice(idx, 1);
  renderInvItems();
}

// Injetar itens no openInvModal original (wrap)
var _origOpenInvModal = openInvModal;
openInvModal = function(id) {
  _invItems = [];
  _origOpenInvModal(id);
  // Se editando, carregar itens existentes da invoice
  if (id) {
    fetch('/exportacao/api/invoices/' + id + '/items').then(r=>r.json()).then(d=>{
      if (d.ok && d.items) { _invItems = d.items; renderInvItems(); }
    }).catch(()=>{});
  } else {
    renderInvItems();
  }
};

// Wrap saveInvoice para enviar itens junto
var _origSaveInvoice = saveInvoice;
saveInvoice = async function() {
  // Salvar invoice primeiro, depois itens
  var id = document.getElementById('inv_id').value;
  // Chamar original save mas capturar o id retornado
  await _origSaveInvAndItems(id);
};

async function _origSaveInvAndItems(existingId) {
  if (!document.getElementById('inv_numero').value.trim()) { showToast('N\u00famero da invoice \u00e9 obrigat\u00f3rio.', 'error'); return; }
  if (!document.getElementById('inv_cliente').value) { showToast('Selecione o cliente.', 'error'); return; }
  if (!document.getElementById('inv_data_emissao').value) { showToast('Data de emiss\u00e3o \u00e9 obrigat\u00f3ria.', 'error'); return; }
  const sub = parseFloat(document.getElementById('inv_subtotal').value)||0;
  const desc = parseFloat(document.getElementById('inv_desconto').value)||0;
  const frete = parseFloat(document.getElementById('inv_frete').value)||0;
  const seg = parseFloat(document.getElementById('inv_seguro').value)||0;
  const tx = parseFloat(document.getElementById('inv_taxa_cambio').value)||1;
  const total = sub - desc + frete + seg;
  const payload = {
    numero: document.getElementById('inv_numero').value.trim(),
    cliente_id: document.getElementById('inv_cliente').value,
    data_emissao: document.getElementById('inv_data_emissao').value,
    data_embarque: document.getElementById('inv_data_embarque').value||null,
    data_vencimento: document.getElementById('inv_data_vencimento').value||null,
    incoterm: document.getElementById('inv_incoterm').value,
    moeda: document.getElementById('inv_moeda').value,
    modal: document.getElementById('inv_modal').value,
    porto_origem: document.getElementById('inv_porto_origem').value,
    porto_destino: document.getElementById('inv_porto_destino').value,
    transportadora: document.getElementById('inv_transportadora').value,
    bl_awb: document.getElementById('inv_bl_awb').value,
    subtotal: sub, desconto: desc, frete, seguro: seg,
    total, total_brl: total * tx, taxa_cambio: tx,
    status: document.getElementById('inv_status').value,
    status_pgto: document.getElementById('inv_status_pgto').value,
    observacoes: document.getElementById('inv_obs').value,
    itens: _invItems,
  };
  const url = existingId ? '/exportacao/api/invoices/' + existingId : '/exportacao/api/invoices';
  const method = existingId ? 'PUT' : 'POST';
  try {
    const res = await fetch(url, { method, headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const d = await res.json();
    if (d.ok) {
      showToast(existingId ? 'Invoice atualizada!' : 'Invoice criada!', 'success');
      closeModal('invModal');
      setTimeout(()=>location.reload(), 800);
    } else { showToast('Erro: ' + (d.error||''), 'error'); }
  } catch { showToast('Erro de conex\u00e3o.', 'error'); }
}

// ── Packing List ──────────────────────────────────────────────────────────────
async function openPackingList(invId) {
  const inv = EXP_INVOICES.find(i => i.id === invId);
  if (!inv) { showToast('Invoice n\u00e3o encontrada.', 'error'); return; }
  const cli = EXP_CLIENTES.find(c => c.id === inv.cliente_id);
  document.getElementById('plInvNumero').textContent = inv.numero || '';
  // Carregar itens
  let items = [];
  try {
    const r = await fetch('/exportacao/api/invoices/' + invId + '/items');
    const d = await r.json();
    if (d.ok) items = d.items || [];
  } catch {}
  const moeda = inv.moeda || 'USD';
  const fmtN = v => (v||0).toFixed(3);
  const fmtV = v => (v||0).toFixed(2);
  let totalQtd = 0, totalPeso = 0, totalCBM = 0, totalValor = 0;
  items.forEach(it => {
    totalQtd += it.quantidade||0;
    totalPeso += (it.peso_unit||0) * (it.quantidade||1);
    totalCBM += (it.cbm_unit||0) * (it.quantidade||1);
    totalValor += it.preco_total||0;
  });
  const html = '<div style="font-family:sans-serif;font-size:12px;">' +
    // Header
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;">' +
      '<div style="background:#f0fdf4;border-radius:8px;padding:14px;border-left:4px solid #16a34a;">' +
        '<div style="font-size:11px;font-weight:700;color:#166534;text-transform:uppercase;margin-bottom:8px;">Exportador / Shipper</div>' +
        '<div style="font-weight:700;color:#1B4F72;font-size:13px;">SUA EMPRESA LTDA</div>' +
        '<div style="color:#374151;">Brasil</div>' +
      '</div>' +
      '<div style="background:#f0f9ff;border-radius:8px;padding:14px;border-left:4px solid #2980B9;">' +
        '<div style="font-size:11px;font-weight:700;color:#1e40af;text-transform:uppercase;margin-bottom:8px;">Importador / Consignee</div>' +
        '<div style="font-weight:700;color:#1B4F72;font-size:13px;">' + (cli ? cli.razao_social : inv.cliente_id) + '</div>' +
        '<div style="color:#374151;">' + (cli ? (cli.cidade||'') + (cli.pais ? ', ' + cli.pais : '') : '') + '</div>' +
        (cli && cli.tax_id ? '<div style="color:#6c757d;font-size:11px;">' + (cli.tipo_doc||'Tax ID') + ': ' + cli.tax_id + '</div>' : '') +
      '</div>' +
    '</div>' +
    // Invoice info
    '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:20px;background:#f8f9fa;border-radius:8px;padding:12px;">' +
      '<div><div style="font-size:10px;color:#6c757d;font-weight:700;text-transform:uppercase;">Invoice N\u00ba</div><div style="font-weight:700;color:#1B4F72;">' + inv.numero + '</div></div>' +
      '<div><div style="font-size:10px;color:#6c757d;font-weight:700;text-transform:uppercase;">Data Emiss\u00e3o</div><div>' + (inv.data_emissao||'\u2014') + '</div></div>' +
      '<div><div style="font-size:10px;color:#6c757d;font-weight:700;text-transform:uppercase;">Incoterm</div><div style="font-weight:700;">' + (inv.incoterm||'\u2014') + '</div></div>' +
      '<div><div style="font-size:10px;color:#6c757d;font-weight:700;text-transform:uppercase;">Modal</div><div style="text-transform:capitalize;">' + (inv.modal||'\u2014') + '</div></div>' +
      '<div><div style="font-size:10px;color:#6c757d;font-weight:700;text-transform:uppercase;">Porto Origem</div><div>' + (inv.porto_origem||'\u2014') + '</div></div>' +
      '<div><div style="font-size:10px;color:#6c757d;font-weight:700;text-transform:uppercase;">Porto Destino</div><div>' + (inv.porto_destino||'\u2014') + '</div></div>' +
      '<div><div style="font-size:10px;color:#6c757d;font-weight:700;text-transform:uppercase;">B/L - AWB</div><div style="font-family:monospace;">' + (inv.bl_awb||'\u2014') + '</div></div>' +
      '<div><div style="font-size:10px;color:#6c757d;font-weight:700;text-transform:uppercase;">Moeda</div><div style="font-weight:700;">' + moeda + '</div></div>' +
    '</div>' +
    // Tabela de itens
    (items.length === 0
      ? '<div style="text-align:center;padding:32px;color:#9ca3af;">Nenhum item cadastrado nesta invoice.</div>'
      : '<table style="width:100%;border-collapse:collapse;font-size:12px;margin-bottom:16px;">' +
          '<thead><tr style="background:#1B4F72;color:white;">' +
            '<th style="padding:9px 10px;text-align:left;">#</th>' +
            '<th style="padding:9px 10px;text-align:left;">C\u00f3digo</th>' +
            '<th style="padding:9px 10px;text-align:left;">Descri\u00e7\u00e3o / Description</th>' +
            '<th style="padding:9px 10px;text-align:left;">NCM</th>' +
            '<th style="padding:9px 10px;text-align:center;">Qtd</th>' +
            '<th style="padding:9px 10px;text-align:center;">Un</th>' +
            '<th style="padding:9px 10px;text-align:center;">Peso Unit (kg)</th>' +
            '<th style="padding:9px 10px;text-align:center;">Peso Total (kg)</th>' +
            '<th style="padding:9px 10px;text-align:center;">CBM Unit (m\u00b3)</th>' +
            '<th style="padding:9px 10px;text-align:center;">CBM Total (m\u00b3)</th>' +
            '<th style="padding:9px 10px;text-align:right;">Pre\u00e7o Unit</th>' +
            '<th style="padding:9px 10px;text-align:right;">Total</th>' +
          '</tr></thead>' +
          '<tbody>' +
          items.map(function(it, i) {
            var pesoTot = (it.peso_unit||0) * (it.quantidade||1);
            var cbmTot = (it.cbm_unit||0) * (it.quantidade||1);
            return '<tr style="border-bottom:1px solid #f1f3f5;' + (i%2===0?'background:white;':'background:#f8fafc;') + '">' +
              '<td style="padding:7px 10px;color:#6c757d;">' + (i+1) + '</td>' +
              '<td style="padding:7px 10px;font-family:monospace;font-size:11px;color:#166534;font-weight:700;">' + (it.codigo||'') + '</td>' +
              '<td style="padding:7px 10px;">' +
                '<div style="font-weight:600;color:#1B4F72;">' + (it.nome_en || it.descricao || '') + '</div>' +
                (it.descricao && it.nome_en ? '<div style="font-size:11px;color:#6c757d;font-style:italic;">' + it.descricao + '</div>' : '') +
              '</td>' +
              '<td style="padding:7px 10px;font-family:monospace;color:#7c3aed;">' + (it.ncm||'\u2014') + '</td>' +
              '<td style="padding:7px 10px;text-align:center;font-weight:700;">' + (it.quantidade||1) + '</td>' +
              '<td style="padding:7px 10px;text-align:center;color:#6c757d;">' + (it.unidade||'PC') + '</td>' +
              '<td style="padding:7px 10px;text-align:center;">' + fmtN(it.peso_unit) + '</td>' +
              '<td style="padding:7px 10px;text-align:center;font-weight:600;">' + fmtN(pesoTot) + '</td>' +
              '<td style="padding:7px 10px;text-align:center;">' + (it.cbm_unit||0).toFixed(4) + '</td>' +
              '<td style="padding:7px 10px;text-align:center;font-weight:600;">' + cbmTot.toFixed(4) + '</td>' +
              '<td style="padding:7px 10px;text-align:right;">' + moeda + ' ' + fmtV(it.preco_unit) + '</td>' +
              '<td style="padding:7px 10px;text-align:right;font-weight:700;color:#1B4F72;">' + moeda + ' ' + fmtV(it.preco_total) + '</td>' +
            '</tr>';
          }).join('') +
          '</tbody>' +
          '<tfoot><tr style="background:#1B4F72;color:white;font-weight:700;">' +
            '<td colspan="4" style="padding:9px 10px;text-align:right;">TOTAIS</td>' +
            '<td style="padding:9px 10px;text-align:center;">' + totalQtd + '</td>' +
            '<td></td>' +
            '<td></td>' +
            '<td style="padding:9px 10px;text-align:center;">' + fmtN(totalPeso) + ' kg</td>' +
            '<td></td>' +
            '<td style="padding:9px 10px;text-align:center;">' + totalCBM.toFixed(4) + ' m\u00b3</td>' +
            '<td style="padding:9px 10px;text-align:right;">' + moeda + ' ' + fmtV(totalValor) + '</td>' +
            '<td style="padding:9px 10px;text-align:right;">' + moeda + ' ' + fmtV(totalValor) + '</td>' +
          '</tr></tfoot>' +
        '</table>'
    ) +
    // Resumo financeiro
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">' +
      '<div style="background:#f8f9fa;border-radius:8px;padding:12px;">' +
        '<div style="font-size:11px;font-weight:700;color:#374151;margin-bottom:8px;text-transform:uppercase;">Resumo de Volumes</div>' +
        '<div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="color:#6c757d;">Total de Itens:</span><strong>' + items.length + ' SKUs</strong></div>' +
        '<div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="color:#6c757d;">Quantidade Total:</span><strong>' + totalQtd + ' unidades</strong></div>' +
        '<div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="color:#6c757d;">Peso Bruto Total:</span><strong>' + fmtN(totalPeso) + ' kg</strong></div>' +
        '<div style="display:flex;justify-content:space-between;"><span style="color:#6c757d;">Volume Total (CBM):</span><strong>' + totalCBM.toFixed(4) + ' m\u00b3</strong></div>' +
      '</div>' +
      '<div style="background:#f0fdf4;border-radius:8px;padding:12px;">' +
        '<div style="font-size:11px;font-weight:700;color:#374151;margin-bottom:8px;text-transform:uppercase;">Resumo Financeiro</div>' +
        '<div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="color:#6c757d;">Subtotal:</span><strong>' + moeda + ' ' + fmtV(inv.subtotal||0) + '</strong></div>' +
        (inv.desconto > 0 ? '<div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="color:#6c757d;">Desconto:</span><strong style="color:#dc2626;">- ' + moeda + ' ' + fmtV(inv.desconto) + '</strong></div>' : '') +
        (inv.frete > 0 ? '<div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="color:#6c757d;">Frete:</span><strong>' + moeda + ' ' + fmtV(inv.frete) + '</strong></div>' : '') +
        (inv.seguro > 0 ? '<div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="color:#6c757d;">Seguro:</span><strong>' + moeda + ' ' + fmtV(inv.seguro) + '</strong></div>' : '') +
        '<div style="display:flex;justify-content:space-between;border-top:2px solid #16a34a;padding-top:8px;margin-top:4px;"><span style="font-weight:700;">TOTAL:</span><strong style="color:#16a34a;font-size:14px;">' + moeda + ' ' + fmtV(inv.total||0) + '</strong></div>' +
      '</div>' +
    '</div>' +
  '</div>';
  document.getElementById('packingListContent').innerHTML = html;
  openModal('packingListModal');
}

function printPackingList() {
  var content = document.getElementById('packingListContent').innerHTML;
  var win = window.open('','_blank','width=900,height=700');
  win.document.write('<html><head><title>Packing List</title><style>body{font-family:sans-serif;padding:20px;font-size:12px;}table{width:100%;border-collapse:collapse;}th,td{padding:7px 10px;border:1px solid #e5e7eb;}th{background:#1B4F72;color:white;}@media print{button{display:none;}}</style></head><body>' + content + '</body></html>');
  win.document.close();
  win.focus();
  setTimeout(()=>win.print(), 400);
}

// ── CSV Import Produtos ───────────────────────────────────────────────────────
var _csvRows = [];

function showCsvTab(n) {
  [1,2,3].forEach(function(i) {
    document.getElementById('csvStep'+i).style.display = i===n ? '' : 'none';
    var btn = document.getElementById('csvTab'+i);
    if (btn) { btn.style.color = i===n ? '#1B4F72' : '#9ca3af'; btn.style.borderBottom = i===n ? '2px solid #1B4F72' : '2px solid transparent'; }
  });
}

function openExpProdCsvModal() {
  _csvRows = [];
  document.getElementById('csvPasteArea').value = '';
  document.getElementById('csvFileName').textContent = '';
  document.getElementById('csvDraftBody').innerHTML = '';
  document.getElementById('csvDraftStats').textContent = '';
  showCsvTab(1);
  document.getElementById('csvParseBtn').disabled = true;
  openModal('expProdCsvModal');
}

function csvPreviewFromPaste() {
  var v = document.getElementById('csvPasteArea').value.trim();
  document.getElementById('csvParseBtn').disabled = !v;
}

function csvHandleDrop(e) {
  e.preventDefault();
  document.getElementById('csvDropZone').style.borderColor = '#d1d5db';
  var f = e.dataTransfer.files[0];
  if (f) { document.getElementById('csvFileName').textContent = f.name; _readCsvFile(f); }
}
function csvHandleFile(input) {
  var f = input.files[0];
  if (!f) return;
  document.getElementById('csvFileName').textContent = f.name;
  _readCsvFile(f);
}
function _readCsvFile(f) {
  var reader = new FileReader();
  reader.onload = function(e) {
    document.getElementById('csvPasteArea').value = e.target.result;
    document.getElementById('csvParseBtn').disabled = false;
  };
  reader.readAsText(f, 'UTF-8');
}

function csvDownloadTemplate() {
  var header = 'codigo;nome_pt;nome_en;ncm;hs_code;unidade;pais_origem;peso_bruto;peso_liquido;cbm;preco_usd;preco_brl;categoria;marca;modelo;descricao_pt;descricao_en';
  var ex = 'EXP-001;Carca\u00e7a de Alum\u00ednio;Aluminum Housing;7616.99.00;761699;PC;Brasil;0.450;0.380;0.002;12.50;65.00;Metal;MinhaMarca;MD-001;Carca\u00e7a usinada em alum\u00ednio;CNC machined aluminum housing';
  var blob = new Blob([header + '\\n' + ex], {type:'text/csv;charset=utf-8;'});
  var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'modelo_produtos_exportacao.csv'; a.click();
}

function _csvDetectDelimiter(line) {
  var counts = {',':0, ';':0, '\\t':0};
  for (var i=0;i<line.length;i++) { if (counts[line[i]] !== undefined) counts[line[i]]++; }
  if (counts['\\t'] > counts[';'] && counts['\\t'] > counts[',']) return '\\t';
  return counts[';'] >= counts[','] ? ';' : ',';
}

function _csvParseLine(line, delim) {
  var res = [], cur = '', inQ = false;
  for (var i=0; i<line.length; i++) {
    var ch = line[i];
    if (ch === '"') { inQ = !inQ; continue; }
    if (!inQ && ch === delim) { res.push(cur.trim()); cur = ''; continue; }
    cur += ch;
  }
  res.push(cur.trim());
  return res;
}

function csvPreviewParsed() {
  var text = document.getElementById('csvPasteArea').value.trim();
  if (!text) { showToast('Nenhum dado para processar.', 'error'); return; }
  var lines = text.split('\\r\\n').join('\\n').split('\\r').join('\\n').split('\\n').filter(function(l) { return l.trim(); });
  if (lines.length < 2) { showToast('Formato inv\u00e1lido. Necess\u00e1rio cabe\u00e7alho + pelo menos 1 linha.', 'error'); return; }
  var delim = _csvDetectDelimiter(lines[0]);
  var headers = _csvParseLine(lines[0], delim).map(h => h.toLowerCase().replace(/\s+/g,'').replace(/[^a-z0-9_]/g,''));
  _csvRows = [];
  for (var i=1; i<lines.length; i++) {
    if (!lines[i].trim()) continue;
    var vals = _csvParseLine(lines[i], delim);
    var obj = {};
    headers.forEach(function(h, idx) { obj[h] = vals[idx] !== undefined ? vals[idx] : ''; });
    // Normalizar aliases
    obj.codigo = obj.codigo || obj.code || obj.cod || '';
    obj.nome_pt = obj.nome_pt || obj.nomept || obj.nome || obj.name || '';
    obj.nome_en = obj.nome_en || obj.nomeen || obj.englishname || obj.name_en || '';
    obj.ncm = obj.ncm || '';
    obj.hs_code = obj.hs_code || obj.hscode || obj.hs || '';
    obj.unidade = obj.unidade || obj.unit || 'PC';
    obj.pais_origem = obj.pais_origem || obj.paisorigem || obj.origin || 'Brasil';
    obj.peso_bruto = parseFloat(obj.peso_bruto || obj.pesobruto || obj.grossweight || '0') || 0;
    obj.peso_liquido = parseFloat(obj.peso_liquido || obj.pesoliquido || obj.netweight || '0') || 0;
    obj.cbm = parseFloat(obj.cbm || obj.volume || '0') || 0;
    obj.preco_usd = parseFloat(obj.preco_usd || obj.precousd || obj.price_usd || obj.priceusd || '0') || 0;
    obj.preco_brl = parseFloat(obj.preco_brl || obj.precobrl || obj.price_brl || '0') || 0;
    obj.categoria = obj.categoria || obj.category || '';
    obj.marca = obj.marca || obj.brand || '';
    obj.modelo = obj.modelo || obj.model || '';
    obj.descricao_pt = obj.descricao_pt || obj.descricaopt || obj.description_pt || '';
    obj.descricao_en = obj.descricao_en || obj.descricaoen || obj.description_en || obj.description || '';
    obj._row = i + 1;
    obj._valid = !!(obj.codigo && obj.nome_pt);
    _csvRows.push(obj);
  }
  if (_csvRows.length === 0) { showToast('Nenhuma linha v\u00e1lida encontrada.', 'error'); return; }
  // Renderizar rascunho
  var valid = _csvRows.filter(r => r._valid).length;
  var invalid = _csvRows.length - valid;
  document.getElementById('csvDraftStats').innerHTML = '<strong>' + _csvRows.length + '</strong> linhas encontradas \u2014 <span style="color:#16a34a;font-weight:700;">' + valid + ' v\u00e1lidas</span>' + (invalid ? ', <span style="color:#dc2626;font-weight:700;">' + invalid + ' com erro</span>' : '');
  var tbody = document.getElementById('csvDraftBody');
  tbody.innerHTML = _csvRows.map(function(r, idx) {
    var rowStyle = r._valid ? '' : 'background:#fef2f2;';
    return '<tr style="border-bottom:1px solid #f1f3f5;' + rowStyle + '">' +
      '<td style="padding:6px 8px;color:#9ca3af;">' + r._row + '</td>' +
      '<td style="padding:6px 8px;font-family:monospace;font-weight:700;color:' + (r.codigo?'#166534':'#dc2626') + ';">' + (r.codigo||'<em>vazio</em>') + '</td>' +
      '<td style="padding:6px 8px;color:' + (r.nome_pt?'#374151':'#dc2626') + ';">' + (r.nome_pt||'<em>vazio</em>') + '</td>' +
      '<td style="padding:6px 8px;font-style:italic;color:#374151;">' + (r.nome_en||'\u2014') + '</td>' +
      '<td style="padding:6px 8px;font-family:monospace;color:#7c3aed;">' + (r.ncm||'\u2014') + '</td>' +
      '<td style="padding:6px 8px;font-family:monospace;color:#374151;">' + (r.hs_code||'\u2014') + '</td>' +
      '<td style="padding:6px 8px;text-align:center;">' + (r.unidade||'PC') + '</td>' +
      '<td style="padding:6px 8px;text-align:center;">' + (r.peso_bruto > 0 ? r.peso_bruto + ' kg' : '\u2014') + '</td>' +
      '<td style="padding:6px 8px;text-align:center;">' + (r.cbm > 0 ? r.cbm : '\u2014') + '</td>' +
      '<td style="padding:6px 8px;text-align:right;">' + (r.preco_usd > 0 ? 'USD ' + r.preco_usd.toFixed(2) : '\u2014') + '</td>' +
      '<td style="padding:6px 8px;text-align:center;">' + (r._valid ? '<span style="color:#16a34a;font-weight:700;">\u2713 OK</span>' : '<span style="color:#dc2626;font-weight:700;">\u2717 Erro</span>') + '</td>' +
      '<td style="padding:6px 8px;text-align:center;"><button style="background:none;border:none;color:#dc2626;cursor:pointer;" onclick="csvRemoveRow(' + idx + ')"><i class="fas fa-times"></i></button></td>' +
    '</tr>';
  }).join('');
  document.getElementById('csvCommitBtn').disabled = valid === 0;
  showCsvTab(2);
}

function csvRemoveRow(idx) {
  _csvRows.splice(idx, 1);
  csvPreviewParsed();
  showCsvTab(2);
}

async function csvCommit() {
  var validRows = _csvRows.filter(r => r._valid);
  if (validRows.length === 0) { showToast('Nenhuma linha v\u00e1lida para importar.', 'error'); return; }
  var btn = document.getElementById('csvCommitBtn');
  btn.disabled = true; btn.textContent = 'Importando...';
  try {
    var res = await fetch('/exportacao/api/produtos/import', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({rows: validRows})
    });
    var d = await res.json();
    if (d.ok) {
      var report = d.report || [];
      var created = report.filter(r => r.action === 'IMPORTED').length;
      var skipped = report.filter(r => r.action === 'SKIPPED').length;
      document.getElementById('csvReportSummary').innerHTML =
        '<div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:12px;">' +
          '<div style="background:#f0fdf4;border-radius:8px;padding:10px 16px;"><strong style="color:#16a34a;font-size:18px;">' + created + '</strong><div style="font-size:11px;color:#6c757d;">Importados</div></div>' +
          '<div style="background:#fef9c3;border-radius:8px;padding:10px 16px;"><strong style="color:#d97706;font-size:18px;">' + skipped + '</strong><div style="font-size:11px;color:#6c757d;">Ignorados (j\u00e1 existem)</div></div>' +
        '</div>';
      document.getElementById('csvReportBody').innerHTML = report.map(function(r, i) {
        return '<tr style="border-bottom:1px solid #f1f3f5;">' +
          '<td style="padding:6px 10px;">' + (i+1) + '</td>' +
          '<td style="padding:6px 10px;font-family:monospace;">' + r.code + '</td>' +
          '<td style="padding:6px 10px;">' + r.name + '</td>' +
          '<td style="padding:6px 10px;text-align:center;"><span style="color:' + (r.action==='IMPORTED'?'#16a34a':'#d97706') + ';font-weight:700;">' + (r.action==='IMPORTED'?'\u2713 Importado':'\u26a0 Ignorado') + '</span></td>' +
          '<td style="padding:6px 10px;color:#6c757d;">' + (r.message||'') + '</td>' +
        '</tr>';
      }).join('');
      showCsvTab(3);
      if (created > 0) setTimeout(() => location.reload(), 2000);
    } else { showToast('Erro: ' + (d.error||''), 'error'); btn.disabled = false; btn.textContent = 'Importar Agora'; }
  } catch { showToast('Erro de conex\u00e3o.', 'error'); btn.disabled = false; btn.textContent = 'Importar Agora'; }
}
</script>`

  return c.html(layout('Exportação', content, 'exportacao', userInfo))
})

// ── APIs Clientes ─────────────────────────────────────────────────────────────
app.post('/api/clientes', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const body = await c.req.json() as any
  if (!body.razao_social || !body.pais) return c.json(err('Campos obrigatórios ausentes'), 400)
  await ensureTables(db)
  const now = new Date().toISOString()
  const id = genId('expcli')
  try { await dbInsert(db, 'exp_clientes', {
    id, user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
    razao_social: body.razao_social, nome_fantasia: body.nome_fantasia || null,
    pais: body.pais, cidade: body.cidade || null, estado: body.estado || null,
    endereco: body.endereco || null, cep: body.cep || null,
    tax_id: body.tax_id || null, tipo_doc: body.tipo_doc || 'CNPJ',
    moeda: body.moeda || 'USD', incoterm: body.incoterm || 'FOB',
    condicao_pgto: body.condicao_pgto || '30 dias',
    limite_credito: body.limite_credito || 0,
    contato_nome: body.contato_nome || null, contato_email: body.contato_email || null,
    contato_tel: body.contato_tel || null, contato_cargo: body.contato_cargo || null,
    status: body.status || 'ativo', categoria: body.categoria || 'cliente',
    observacoes: body.observacoes || null,
    created_at: now, updated_at: now,
  }) } catch(e: any) { return c.json(err('Erro ao inserir: ' + (e?.message||e)), 500) }
  return c.json(ok({ id }))
})

app.put('/api/clientes/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const id = c.req.param('id')
  const body = await c.req.json() as any
  await ensureTables(db)
  const now = new Date().toISOString()
  try { await dbUpdate(db, 'exp_clientes', id, userId, {
    razao_social: body.razao_social, nome_fantasia: body.nome_fantasia,
    pais: body.pais, cidade: body.cidade, estado: body.estado,
    endereco: body.endereco, tax_id: body.tax_id, tipo_doc: body.tipo_doc,
    moeda: body.moeda, incoterm: body.incoterm, condicao_pgto: body.condicao_pgto,
    limite_credito: body.limite_credito, contato_nome: body.contato_nome,
    contato_email: body.contato_email, contato_tel: body.contato_tel,
    contato_cargo: body.contato_cargo, status: body.status, categoria: body.categoria,
    observacoes: body.observacoes, updated_at: now,
  }) } catch(e: any) { return c.json(err('Erro ao atualizar: ' + (e?.message||e)), 500) }
  return c.json(ok({}))
})

app.delete('/api/clientes/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  await ensureTables(db)
  try { await dbDelete(db, 'exp_clientes', c.req.param('id'), userId) } catch(e: any) { return c.json(err('Erro: ' + (e?.message||e)), 500) }
  return c.json(ok({}))
})

// ── APIs Invoices ─────────────────────────────────────────────────────────────
app.post('/api/invoices', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const body = await c.req.json() as any
  if (!body.numero || !body.cliente_id || !body.data_emissao) return c.json(err('Campos obrigatórios ausentes'), 400)
  await ensureTables(db)
  const now = new Date().toISOString()
  const id = genId('expinv')
  try { await dbInsert(db, 'exp_invoices', {
    id, user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
    numero: body.numero, cliente_id: body.cliente_id,
    data_emissao: body.data_emissao, data_embarque: body.data_embarque || null,
    data_vencimento: body.data_vencimento || null,
    incoterm: body.incoterm || 'FOB', porto_origem: body.porto_origem || null,
    porto_destino: body.porto_destino || null, modal: body.modal || 'maritimo',
    transportadora: body.transportadora || null, bl_awb: body.bl_awb || null,
    moeda: body.moeda || 'USD', subtotal: body.subtotal || 0,
    desconto: body.desconto || 0, frete: body.frete || 0, seguro: body.seguro || 0,
    total: body.total || 0, total_brl: body.total_brl || 0,
    taxa_cambio: body.taxa_cambio || 1,
    status: body.status || 'rascunho', status_pgto: body.status_pgto || 'pendente',
    documentos: '[]', observacoes: body.observacoes || null,
    created_at: now, updated_at: now,
  }) } catch(e: any) { return c.json(err('Erro ao inserir invoice: ' + (e?.message||e)), 500) }
  // Salvar itens
  if (Array.isArray(body.itens) && body.itens.length > 0) {
    for (const it of body.itens) {
      try {
        await dbInsert(db, 'exp_invoice_items', {
          id: genId('expitem'), user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
          invoice_id: id, produto_id: it.produto_id || null,
          codigo: it.codigo || '', descricao: it.descricao || it.nome_en || '',
          ncm: it.ncm || null, quantidade: it.quantidade || 1,
          unidade: it.unidade || 'PC', peso_unit: it.peso_unit || 0,
          peso_total: (it.peso_unit || 0) * (it.quantidade || 1),
          cbm_unit: it.cbm_unit || 0,
          preco_unit: it.preco_unit || 0, desconto_pct: it.desconto_pct || 0,
          preco_total: it.preco_total || 0,
          nome_en: it.nome_en || it.descricao || '',
          pais_origem: it.pais_origem || 'Brasil', created_at: now,
        })
      } catch {}
    }
  }
  return c.json(ok({ id }))
})

app.put('/api/invoices/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const id = c.req.param('id')
  const body = await c.req.json() as any
  await ensureTables(db)
  const now = new Date().toISOString()
  try { await dbUpdate(db, 'exp_invoices', id, userId, {
    numero: body.numero, cliente_id: body.cliente_id,
    data_emissao: body.data_emissao, data_embarque: body.data_embarque,
    data_vencimento: body.data_vencimento, incoterm: body.incoterm,
    porto_origem: body.porto_origem, porto_destino: body.porto_destino,
    modal: body.modal, transportadora: body.transportadora, bl_awb: body.bl_awb,
    moeda: body.moeda, subtotal: body.subtotal, desconto: body.desconto,
    frete: body.frete, seguro: body.seguro, total: body.total,
    total_brl: body.total_brl, taxa_cambio: body.taxa_cambio,
    status: body.status, status_pgto: body.status_pgto,
    observacoes: body.observacoes, updated_at: now,
  }) } catch(e: any) { return c.json(err('Erro ao atualizar invoice: ' + (e?.message||e)), 500) }
  // Regravar itens: apaga os existentes e insere novos
  if (Array.isArray(body.itens)) {
    try { await db.prepare('DELETE FROM exp_invoice_items WHERE invoice_id=? AND user_id=?').bind(id, userId).run() } catch {}
    for (const it of body.itens) {
      try {
        await dbInsert(db, 'exp_invoice_items', {
          id: genId('expitem'), user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
          invoice_id: id, produto_id: it.produto_id || null,
          codigo: it.codigo || '', descricao: it.descricao || it.nome_en || '',
          ncm: it.ncm || null, quantidade: it.quantidade || 1,
          unidade: it.unidade || 'PC', peso_unit: it.peso_unit || 0,
          peso_total: (it.peso_unit || 0) * (it.quantidade || 1),
          cbm_unit: it.cbm_unit || 0,
          preco_unit: it.preco_unit || 0, desconto_pct: it.desconto_pct || 0,
          preco_total: it.preco_total || 0,
          nome_en: it.nome_en || it.descricao || '',
          pais_origem: it.pais_origem || 'Brasil', created_at: now,
        })
      } catch {}
    }
  }
  return c.json(ok({}))
})

app.get('/api/invoices/:id/items', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(ok({ items: [] }))
  await ensureTables(db)
  try {
    const res = await db.prepare('SELECT * FROM exp_invoice_items WHERE invoice_id=? AND user_id=? ORDER BY rowid ASC').bind(c.req.param('id'), userId).all()
    return c.json(ok({ items: res.results || [] }))
  } catch { return c.json(ok({ items: [] })) }
})

app.delete('/api/invoices/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  await ensureTables(db)
  try { await dbDelete(db, 'exp_invoices', c.req.param('id'), userId) } catch(e: any) { return c.json(err('Erro: ' + (e?.message||e)), 500) }
  return c.json(ok({}))
})

// ── APIs Proformas ────────────────────────────────────────────────────────────
app.post('/api/proformas', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const body = await c.req.json() as any
  await ensureTables(db)
  const now = new Date().toISOString()
  const id = genId('exppf')
  try { await dbInsert(db, 'exp_proformas', {
    id, user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
    numero: body.numero, cliente_id: body.cliente_id,
    data_emissao: body.data_emissao, data_validade: body.data_validade || null,
    incoterm: body.incoterm || 'FOB', moeda: body.moeda || 'USD',
    total: body.total || 0, status: body.status || 'ativa',
    itens: '[]', observacoes: body.observacoes || null,
    created_at: now, updated_at: now,
  }) } catch(e: any) { return c.json(err('Erro ao inserir proforma: ' + (e?.message||e)), 500) }
  return c.json(ok({ id }))
})

app.put('/api/proformas/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const id = c.req.param('id')
  const body = await c.req.json() as any
  await ensureTables(db)
  try { await dbUpdate(db, 'exp_proformas', id, userId, {
    numero: body.numero, cliente_id: body.cliente_id,
    data_emissao: body.data_emissao, data_validade: body.data_validade,
    incoterm: body.incoterm, moeda: body.moeda, total: body.total,
    status: body.status, observacoes: body.observacoes,
    updated_at: new Date().toISOString(),
  }) } catch(e: any) { return c.json(err('Erro ao atualizar proforma: ' + (e?.message||e)), 500) }
  return c.json(ok({}))
})

app.post('/api/proformas/:id/convert', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const pfId = c.req.param('id')
  try { await ensureTables(db) } catch {}
  const pf = await db.prepare('SELECT * FROM exp_proformas WHERE id=? AND user_id=?').bind(pfId, userId).first() as any
  if (!pf) return c.json(err('Proforma não encontrada'), 404)
  const now = new Date().toISOString()
  const invId = genId('expinv')
  const num = 'INV-' + pf.numero.replace(/^PF-?/i, '')
  await dbInsert(db, 'exp_invoices', {
    id: invId, user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
    numero: num, cliente_id: pf.cliente_id,
    data_emissao: now.split('T')[0], incoterm: pf.incoterm,
    moeda: pf.moeda, subtotal: pf.total, desconto: 0, frete: 0, seguro: 0,
    total: pf.total, total_brl: 0, taxa_cambio: 1,
    status: 'rascunho', status_pgto: 'pendente',
    documentos: '[]', observacoes: 'Gerada a partir da Proforma ' + pf.numero,
    created_at: now, updated_at: now,
  })
  try { await dbUpdate(db, 'exp_proformas', pfId, userId, { status: 'convertida', invoice_id: invId, updated_at: now }) } catch {}
  return c.json(ok({ invoice_id: invId }))
})

// ── APIs Pagamentos ───────────────────────────────────────────────────────────
app.post('/api/pagamentos', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const body = await c.req.json() as any
  if (!body.invoice_id || !body.data_pgto || !body.valor) return c.json(err('Campos obrigatórios ausentes'), 400)
  await ensureTables(db)
  const now = new Date().toISOString()
  const id = genId('exppgto')
  try { await dbInsert(db, 'exp_pagamentos', {
    id, user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
    invoice_id: body.invoice_id, data_pgto: body.data_pgto,
    valor: body.valor, moeda: body.moeda || 'USD',
    valor_brl: body.valor_brl || 0, taxa_cambio: body.taxa_cambio || 1,
    forma_pgto: body.forma_pgto || 'wire',
    banco_origem: body.banco_origem || null, referencia: body.referencia || null,
    observacoes: body.observacoes || null, created_at: now,
  }) } catch(e: any) { return c.json(err('Erro ao registrar pagamento: ' + (e?.message||e)), 500) }
  // Atualizar status_pgto da invoice
  const existing = await db.prepare('SELECT SUM(valor) as total FROM exp_pagamentos WHERE invoice_id=? AND user_id=?').bind(body.invoice_id, userId).first() as any
  const inv = await db.prepare('SELECT total FROM exp_invoices WHERE id=? AND user_id=?').bind(body.invoice_id, userId).first() as any
  if (inv && existing) {
    const paid = existing.total || 0
    const newStatus = paid >= inv.total ? 'pago' : paid > 0 ? 'parcial' : 'pendente'
    await dbUpdate(db, 'exp_invoices', body.invoice_id, userId, { status_pgto: newStatus, updated_at: now })
  }
  return c.json(ok({ id }))
})

// ── APIs Produtos de Exportação ───────────────────────────────────────────────
app.post('/api/produtos', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const body = await c.req.json() as any
  if (!body.codigo || !body.nome_pt) return c.json(err('Código e nome em PT são obrigatórios'), 400)
  await ensureTables(db)
  const now = new Date().toISOString()
  const id = genId('expprod')
  try {
    await dbInsert(db, 'exp_produtos', {
      id, user_id: userId, empresa_id: getCtxEmpresaId(c) || '1',
      codigo: body.codigo, nome_pt: body.nome_pt, nome_en: body.nome_en || null,
      descricao_pt: body.descricao_pt || null, descricao_en: body.descricao_en || null,
      ncm: body.ncm || null, hs_code: body.hs_code || null,
      unidade: body.unidade || 'PC', pais_origem: body.pais_origem || 'Brasil',
      peso_bruto: body.peso_bruto || 0, peso_liquido: body.peso_liquido || 0, cbm: body.cbm || 0,
      preco_unit_usd: body.preco_unit_usd || 0, preco_unit_brl: body.preco_unit_brl || 0,
      categoria: body.categoria || null, marca: body.marca || null, modelo: body.modelo || null,
      status: body.status || 'ativo', observacoes: body.observacoes || null,
      created_at: now, updated_at: now,
    })
  } catch(e: any) { return c.json(err('Erro ao inserir produto: ' + (e?.message||e)), 500) }
  return c.json(ok({ id }))
})

app.put('/api/produtos/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const id = c.req.param('id')
  const body = await c.req.json() as any
  await ensureTables(db)
  try {
    await dbUpdate(db, 'exp_produtos', id, userId, {
      codigo: body.codigo, nome_pt: body.nome_pt, nome_en: body.nome_en,
      descricao_pt: body.descricao_pt, descricao_en: body.descricao_en,
      ncm: body.ncm, hs_code: body.hs_code,
      unidade: body.unidade, pais_origem: body.pais_origem,
      peso_bruto: body.peso_bruto, peso_liquido: body.peso_liquido, cbm: body.cbm,
      preco_unit_usd: body.preco_unit_usd, preco_unit_brl: body.preco_unit_brl,
      categoria: body.categoria, marca: body.marca, modelo: body.modelo,
      status: body.status, observacoes: body.observacoes,
      updated_at: new Date().toISOString(),
    })
  } catch(e: any) { return c.json(err('Erro ao atualizar produto: ' + (e?.message||e)), 500) }
  return c.json(ok({}))
})

app.delete('/api/produtos/:id', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  await ensureTables(db)
  try { await dbDelete(db, 'exp_produtos', c.req.param('id'), userId) } catch(e: any) { return c.json(err('Erro: ' + (e?.message||e)), 500) }
  return c.json(ok({}))
})

// ── API Import CSV de Produtos ────────────────────────────────────────────────
app.post('/api/produtos/import', async (c) => {
  const db = getCtxDB(c)
  const userId = getCtxUserId(c)
  if (!db) return c.json(err('DB indisponível'), 503)
  const body = await c.req.json() as any
  if (!Array.isArray(body.rows) || body.rows.length === 0) return c.json(err('Dados inválidos'), 400)
  await ensureTables(db)
  const empresaId = getCtxEmpresaId(c) || '1'
  const now = new Date().toISOString()
  let created = 0, skipped = 0
  const report: Array<{ code: string; name: string; action: string; message: string }> = []
  for (const row of body.rows as any[]) {
    const codigo = (row.codigo || '').trim()
    const nome_pt = (row.nome_pt || '').trim()
    if (!codigo || !nome_pt) { skipped++; report.push({ code: codigo, name: nome_pt, action: 'SKIPPED', message: 'Código e nome PT são obrigatórios' }); continue }
    // Verificar duplicata
    try {
      const existing = await db.prepare('SELECT id FROM exp_produtos WHERE user_id=? AND empresa_id=? AND codigo=?').bind(userId, empresaId, codigo).first()
      if (existing) { skipped++; report.push({ code: codigo, name: nome_pt, action: 'SKIPPED', message: 'Código já cadastrado' }); continue }
    } catch {}
    try {
      await dbInsert(db, 'exp_produtos', {
        id: genId('expprod'), user_id: userId, empresa_id: empresaId,
        codigo, nome_pt, nome_en: row.nome_en || null,
        descricao_pt: row.descricao_pt || null, descricao_en: row.descricao_en || null,
        ncm: row.ncm || null, hs_code: row.hs_code || null,
        unidade: row.unidade || 'PC', pais_origem: row.pais_origem || 'Brasil',
        peso_bruto: row.peso_bruto || 0, peso_liquido: row.peso_liquido || 0, cbm: row.cbm || 0,
        preco_unit_usd: row.preco_usd || 0, preco_unit_brl: row.preco_brl || 0,
        categoria: row.categoria || null, marca: row.marca || null, modelo: row.modelo || null,
        status: 'ativo', observacoes: null,
        created_at: now, updated_at: now,
      })
      created++
      report.push({ code: codigo, name: nome_pt, action: 'IMPORTED', message: 'Produto importado com sucesso' })
    } catch(e: any) {
      skipped++
      report.push({ code: codigo, name: nome_pt, action: 'SKIPPED', message: 'Erro: ' + (e?.message || String(e)) })
    }
  }
  return c.json(ok({ created, skipped, report }))
})

export default app
