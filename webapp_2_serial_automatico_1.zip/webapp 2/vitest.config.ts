import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    include: [
      'src/**/*.test.ts', // Unit tests
      'src/**/*.spec.ts', // Integration tests
    ],
    coverage: {
      reporter: ['text', 'json', 'html'],
      include: [
        'src/**/*.ts',
      ],
    },
  },
});